File Explorer for webOS Signage 1.01

History:

2015. 02.23
Ver 1.01
Modify read file code for SCAP v1.2
Support Video file play (MP4 Format Only)

2015. 02. 11
Ver 1.00
Modify some code and SCAP API code for SCAP API v1.2 and work correctly