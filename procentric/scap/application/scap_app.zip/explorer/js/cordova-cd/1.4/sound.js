/*
 * This is sound cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the sound API itself, and provides a global namespace for operating sound service.
 * @class
 */
cordova.define('cordova/plugin/sound', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    /**
     * sound interface
     */
    var Sound = function () {
    };
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    /**
     * 160318 iamjunyoug.park : Add function
     */
    var version = null;
    var platformInfoObj = {}; 
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }
    
    Sound.SoundMode = {    
    Standard : "standard",
    Cinema : "movie",
    ClearVoice : "news",
    Sports : "sports",
    Music : "music",
    Game : "game"
    };

    Sound.SpeakerType = {    
    SignageSpeaker : "tv_speaker",
    LGSoundSync : "bt_soundbar"
    };

    /**
     * Gets sound information
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>level</th><th>Number</th><th>volume level (0~100)</th></tr>
     *       <tr class="odd"><th>muted</th><th>Boolean</th><th>true: mute on / false: mute off </th></tr>
     *       <tr><th>externalSpeaker</th><th>Boolean</th><th>true : enabled / false : disabled </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSoundStatus () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("level : " + cbObject.level);
     *      console.log("muted : " + cbObject.muted);
     *      console.log("externalSpeaker : " + cbObject.externalSpeaker);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.getSoundStatus(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23setVolumeLevel.html">Sound.setVolumeLevel()</a>,  
     * <a href="Sound%23setExternalSpeaker.html">Sound.setExternalSpeaker()</a><br>
     */
    Sound.prototype.getSoundStatus = function(successCallback, errorCallback) {
        log("getSoundStatus: ");

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["tv.model.supportCommerSoundSetting"]
            },
            onSuccess: function(result) {
                log("getConfigs: On Success");

                if (result.returnValue === true) {
                    var supportCommerSoundSetting = result.configs["tv.model.supportCommerSoundSetting"];
                    if (supportCommerSoundSetting === true) {
                        service.Request("luna://com.webos.audio/", {
                            method: "getVolume",
                            onSuccess: function(result) {
                                log("getSoundStatus: On Success");

                                if (result.returnValue === true) {
                                    var cbObj = {};
                                    cbObj.level = result.volume;
                                    cbObj.muted = result.muted;

                                    service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                                        method: "get",
                                        parameters: {
                                            category: "commercial",
                                            keys: ["enableSpeaker"]
                                        },
                                        onSuccess: function(result) {
                                            log("getSoundStatus: On Success 2");

                                            if (result.returnValue === true) {
                                                cbObj.externalSpeaker = (result.settings.enableSpeaker === "on" ? true : false);

                                                if (typeof successCallback === 'function') {
                                                    successCallback(cbObj);
                                                }
                                            }
                                        },
                                        onFailure: function(result) {
                                            log("getSoundStatus: On Failure 2");
                                            delete result.returnValue;
                                            if (typeof errorCallback === 'function') {
                                                checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                                                errorCallback(result);
                                            }
                                        }
                                    });
                                }
                            },
                            onFailure: function(result) {
                                log("getSoundStatus: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    } else {
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "SGSS", "unsupported feature");
                            errorCallback(result);
                        }

                        return;
                    }

                    log("Sound.getSoundStatus Done");
                }
            },
            onFailure: function(result) {
                log("getConfigs: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.getSoundStatus Done");

    };

    /**
     * Sets volume level
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>level</th><th>Number</th><th>volume level (0~100)</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setVolumeLevel () {
     *   var options = {
     *      level : 15
     *   };   
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setVolumeLevel(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setVolumeLevel = function (successCallback, errorCallback, options) {
    
        log("setVolumeLevel: " + JSON.stringify(options));
        
        if (typeof options.level !== 'number' || isNaN(options.level) ||
            options.level < 0 || options.level > 100) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSVL", "Sound.setVolumeLevel returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }
            
            return;
        }


        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["tv.model.supportCommerSoundSetting"]
            },
            onSuccess: function(result) {
                log("getConfigs: On Success");

                if (result.returnValue === true) {
                    var supportCommerSoundSetting = result.configs["tv.model.supportCommerSoundSetting"];
                    if (supportCommerSoundSetting === true) {
                        service.Request("luna://com.webos.audio/", {
                            method: "setVolume",
                            parameters: {
                                volume: options.level
                            },
                            onSuccess: function(result) {
                                log("setVolumeLevel: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("setVolumeLevel: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SSVL", "Sound.setVolumeLevel returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    } else {
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "SSVL", "unsupported feature");
                            errorCallback(result);
                        }

                        return;
                    }                    
                }
            },
            onFailure: function(result) {
                log("getConfigs: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSVL", "Sound.setVolumeLevel returns failure");
                    errorCallback(result);
                }
            }
        });        
        
        log("Sound.setVolumeLevel Done");
    };
    
    /**
     * Enable or disable external speaker.
     * If this method is successfully executed, change the external speaker status.
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <th>externalSpeaker</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setExternalSpeaker () {
     *   var options = {
     *      externalSpeaker : true
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setExternalSpeaker(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setExternalSpeaker = function (successCallback, errorCallback, options) {
    
        log("setExternalSpeaker: " + JSON.stringify(options));
        
        if (typeof options.externalSpeaker !== 'boolean') {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSVL", "Sound.setExternalSpeaker returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }
            
            return;
        }
        
        var enable = null;
        switch (options.externalSpeaker) {
            case true :
                enable = "on";
                break;
            case false :
                enable = "off";
                break;
        }
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "set",
                parameters : {
                    category : "commercial",
                    settings : {"enableSpeaker":enable}
                },
                onSuccess : function() {
                    log("setExternalSpeaker: On Success");
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                },
                onFailure : function(result) {
                    log("setExternalSpeaker: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SSES", "Sound.setExternalSpeaker returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Sound.setExternalSpeaker Done");
            
    };
    
    /**
     * mute on/off
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>muted</th><th>Boolean</th><th>true: mute on / false: mute off </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setMuted () {
     *   var options = {
     *      muted : true
     *   };   
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setMuted(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setMuted = function (successCallback, errorCallback, options) {
    
        log("setMuted: " + JSON.stringify(options));
        
        if (typeof options.muted !== 'boolean') {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSVL", "Sound.setMuted returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }
            
            return;
        }

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["tv.model.supportCommerSoundSetting"]
            },
            onSuccess: function(result) {
                log("getConfigs: On Success");

                if (result.returnValue === true) {
                    var supportCommerSoundSetting = result.configs["tv.model.supportCommerSoundSetting"];
                    if (supportCommerSoundSetting === true) {
                        service.Request("luna://com.webos.audio/", {
                            method: "setMuted",
                            parameters: {
                                muted: options.muted
                            },
                            onSuccess: function(result) {
                                log("setMuted: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("setMuted: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    } else {
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "SSM", "unsupported feature");
                            errorCallback(result);
                        }

                        return;
                    }                    
                }
            },
            onFailure: function(result) {
                log("getConfigs: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure");
                    errorCallback(result);
                }
            }
        });     
        
        log("Sound.setMuted Done");
    
    };

    Sound.prototype.setSoundMode = function (successCallback, errorCallback, options) {
        var mode = null;
        
        switch (options.mode) {
            case Sound.SoundMode.Standard :
                mode = "standard";
                break;
            case Sound.SoundMode.Cinema :
                mode = "movie";
                break;
            case Sound.SoundMode.ClearVoice :
                mode = "news";
                break;
            case Sound.SoundMode.Sports :
                mode = "sports";
                break;
            case Sound.SoundMode.Music :
                mode = "music";
                break;
            case Sound.SoundMode.Game :
                mode = "game";
                break;
        }

        if (((options.balance < -50) || (options.balance > 50)) && isNumber(options.balance)) {
            var result = {};
            checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure. Out of range.");
            errorCallback(result);
            log("Sound.setSoundMode invalid range");
        }
        
        log("setSoundMode: " + mode);
        
        if (mode === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure. command was not defined.");
            errorCallback(result);
            log("Sound.setSoundMode invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "sound",
                settings : {
                    "soundMode" : mode,
                    "audioBalance" : options.balance
                }
            },
            onSuccess : function(result) {
                log("setSoundMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setSoundMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Sound.setSoundMode Done");
    };

    Sound.prototype.getSoundMode = function (successCallback, errorCallback) {
        
        log("getSoundMode: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "sound",
                keys: ["soundMode", "audioBalance"]
            },
            onSuccess: function(result) {
                log("getSoundMode: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    cbObj.mode = result.settings.soundMode;
                    cbObj.balance = result.settings.audioBalance;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getSoundMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SGSM", "Sound.getSoundMode returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.getSoundMode Done");
    };

    Sound.prototype.setSoundOut = function (successCallback, errorCallback, options) {
        checkPlatformVersion(function(platformInfo){
            if (platformInfo.webOSVer !== 3) {
                // only webOS Signage 3.0 support setSoundOut API
                var result = {};
                checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. Only webOS 3.0 support setSoundOut API.");
                errorCallback(result);
                log("not support setSoundOut");
                return;
            }

            service.Request("luna://com.webos.service.config/", {
                method: "getConfigs",
                parameters: {
                    configNames: ["system.supportBluetoothFeatures"]
                },
                onSuccess: function(result) {
                    log("getConfigs: On Success");

                    if (result.returnValue === true) {

                        var bluetoothFeatures = result.configs["system.supportBluetoothFeatures"];
                        if (bluetoothFeatures.indexOf('btsound') === -1) //not supported btsound
                        {
                            if (options.speakerType === Sound.SpeakerType.LGSoundSync) {
                                var result = {};
                                checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. bluetooth soundsync is not supported.");
                                errorCallback(result);
                                return;
                            }
                        }

                        var speakerType = null;

                        switch (options.speakerType) {
                            case Sound.SpeakerType.SignageSpeaker:
                                speakerType = "tv_speaker";
                                break;
                            case Sound.SpeakerType.LGSoundSync:
                                speakerType = "bt_soundbar";
                                break;
                        }

                        log("setSoundOut: " + speakerType);

                        if (speakerType === null && typeof errorCallback === 'function') {
                            var result = {};
                            checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. command was not defined.");
                            errorCallback(result);
                            log("Sound.setSoundOut invalid ");
                            return;
                        }

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                category: "sound",
                                settings: {
                                    "soundOutput": speakerType
                                }
                            },
                            onSuccess: function(result) {
                                log("setSoundOut: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("setSoundOut: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });

                        log("Sound.setSoundOut Done");  

                    }
                },
                onFailure: function(result) {
                    log("getConfigs: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SSSO", "unsupported feature");
                        errorCallback(result);
                    }
                }
            });                      
        });        
    };

    Sound.prototype.getSoundOut = function(successCallback, errorCallback) {
        checkPlatformVersion(function(platformInfo) {
            if (platformInfo.webOSVer !== 3) {
                // only webOS Signage 3.0 support getSoundOut API
                var result = {};
                checkErrorCodeNText(result, "SGSO", "Sound.getSoundOut returns failure. Only webOS 3.0 support getSoundOut API.");
                errorCallback(result);
                log("not support getSoundOut");
                return;
            }

            log("getSoundOut: ");

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method: "get",
                parameters: {
                    category: "sound",
                    keys: ["soundOutput"]
                },
                onSuccess: function(result) {
                    log("getSoundOut: On Success");

                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.speakerType = result.settings.soundOutput;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure: function(result) {
                    log("getSoundOut: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SGSO", "Sound.getSoundOut returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Sound.getSoundOut Done");
        });
    };

    module.exports = Sound;
});

Sound = cordova.require('cordova/plugin/sound'); // jshint ignore:line

