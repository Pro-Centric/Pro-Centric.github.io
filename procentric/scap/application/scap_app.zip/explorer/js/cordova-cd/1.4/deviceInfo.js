/*
 * This is sound cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the deviceInfo API itself, and provides a global namespace for operating deviceInfo service.
 * @class
 */
cordova.define('cordova/plugin/deviceInfo', function (require, exports, module) { // jshint ignore:line
    
    var service;
    if (window.PalmSystem){ // jshint ignore:line
        console.log("Window.PalmSystem Available"); // jshint ignore:line
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
               console.log(uri + " invoked. But I am a dummy because PalmSystem is not available"); // jshint ignore:line
                        
               if (typeof params.onFailure === 'function') {
                  params.onFailure({ returnValue:false,
                     errorText:"PalmSystem Not Available. Cordova is not installed?"});
               }
        }};
    }

    /**
     * deviceInfo interface
     */
    var DeviceInfo = function () {
    };
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText === undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

	
    /**
     * @namespace DeviceInfo.EddystoneFrame
     */
    DeviceInfo.EddystoneFrame = {
    /**
     * UUID
     * @since 1.4
     * @constant
     */
        UUID: "uid",
    /**
     * URL
     * @since 1.4
     * @constant
     */
        URL: "url"
    };

    /**
     * Gets network information. Network information includes IP address assigned to wireless / wired LAN, gateway address, netmask and DNS address.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>isInternetConnectionAvailable</th><th>Boolean</th><th>Internet connection true: connected, false: not connected</th></tr>
     *       <tr class="odd"><th>wired</th><th>Object</th><th>Wired network information object. </th></tr>
     *       <tr><th>wired.state</th><th>String</th><th>Wired network connection "connected": connected "disconnected": not connected</th></tr>     
     *       <tr class="odd"><th>wired.interfaceName</th><th>String</th><th>Wired network interface name. </th></tr>
     *       <tr><th>wired.ipAddress</th><th>String</th><th>IP address assigned to the wired network interface. </th></tr>
     *       <tr class="odd"><th>wired.netmask</th><th>String</th><th>Netmask assigned to the wired network interface. </th></tr>
     *       <tr><th>wired.gateway</th><th>String</th><th>Gateway address assigned to the wired network interface</th></tr>
     *       <tr class="odd"><th>wired.onInternet</th><th>String</th><th>Internet connection to the wired network "yes": connected "no": not connected. </th></tr>     
     *       <tr><th>wired.method</th><th>String</th><th>IP allocation "manual": fixed allocation "dhcp": dynamic allocation</th></tr>
     *       <tr class="odd"><th>wired.dns1</th><th>String</th><th>DNS address assigned to the wired network interface. </th></tr>     
     *       <tr><th>wired.dns2</th><th>String</th><th>Secondary DNS address assigned to the wired network interface. </th></tr>     
     *       <tr class="odd"><th>wifi</th><th>Object</th><th>Wireless network information object. </th></tr>     
     *       <tr><th>wifi.state</th><th>String</th><th>Wireless network connection "connected": connected "disconnected": not connected</th></tr>     
     *       <tr class="odd"><th>wifi.interfaceName</th><th>String</th><th>Wireless network interface name. </th></tr>
     *       <tr><th>wifi.ipAddress</th><th>String</th><th>IP address assigned to the wireless network interface. </th></tr>
     *       <tr class="odd"><th>wifi.netmask</th><th>String</th><th>Netmask assigned to the wireless network interface. </th></tr>
     *       <tr><th>wifi.gateway</th><th>String</th><th>Gateway address assigned to the wireless network interface</th></tr>
     *       <tr class="odd"><th>wifi.onInternet</th><th>String</th><th>Internet connection to the wireless network "yes": connected "no": not connected. </th></tr>
     *       <tr><th>wifi.method</th><th>String</th><th>IP allocation "manual": fixed allocation "dhcp": dynamic allocation</th></tr>
     *       <tr class="odd"><th>wifi.dns1</th><th>String</th><th>DNS address assigned to the wireless network interface. </th></tr>
     *       <tr><th>wifi.dns2</th><th>String</th><th>Secondary DNS address assigned to the wireless network interface. </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getNetworkInformation () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("isInternetConnectionAvailable : " + cbObject.isInternetConnectionAvailable);
     *      console.log("wired.state : " + cbObject.wired.state);
     *      console.log("wired.method : " + cbObject.wired.method);
     *      console.log("wired.ipAddress : " + cbObject.wired.ipAddress);
     *      console.log("wired.netmask : " + cbObject.wired.netmask);
     *      console.log("wired.dns1 : " + cbObject.wired.dns1);
     *      console.log("wired.dns2 : " + cbObject.wired.dns2);
     *      console.log("wifi.state : " + cbObject.wifi.state);
     *      console.log("wifi.method : " + cbObject.wifi.method);
     *      console.log("wifi.ipAddress : " + cbObject.wifi.ipAddress);
     *      console.log("wifi.netmask : " + cbObject.wifi.netmask);
     *      console.log("wifi.dns1 : " + cbObject.wifi.dns1);
     *      console.log("wifi.dns2 : " + cbObject.wifi.dns2);
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getNetworkInfo(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="DeviceInfo%23getNetworkMacInfo.html">DeviceInfo.getNetworkMacInfo()</a><br>, 
     * <a href="DeviceInfo%23setNetworkInfo.html">DeviceInfo.setNetworkInfo()</a><br>
     */
    DeviceInfo.prototype.getNetworkInfo = function (successCallback, errorCallback) {
    
        log("getNetworkInfo: ");
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'getNetworkInfo',
            parameters: {},
            onSuccess: function (result) {
                if (typeof successCallback === 'function') {
                    delete result.returnValue;
                    successCallback(result);
                }
            },
            onFailure: function (error) {
                log("getNetworkInfo: onFailure");
                if (error.errorText.indexOf('Unknown method') !== -1) {
                    // Call old method
                    service.Request('luna://com.palm.connectionmanager', {
                        method: 'getstatus',
                        parameters: {},
                        onSuccess: function (result) {
                            log("getNetworkInfo: onSuccess");
                            delete result.returnValue;
                            if (typeof successCallback === 'function') {
                                successCallback(result);
                            }
                        },
                        onFailure: function (error) {
                            log("getNetworkInfo: onFailure");
                            delete error.returnValue;
                            if (typeof errorCallback === 'function') {
                                errorCallback(error);
                            }
                        }
                    });
                }
                else {
                    delete error.returnValue;
                    if (typeof errorCallback === 'function') {
                        errorCallback(error);
                    }
                }
            }
        });
    /*
        service.Request('luna://com.palm.connectionmanager', {
            method: 'getstatus',
            parameters: {},
            onSuccess: function(result) {
                log("getNetworkInfo: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getNetworkInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
      */  
        log("DeviceInfo.getNetworkInfo Done");
    };
    
    /**
     * Sets network information. Network information includes IP address assigned to wireless / wired LAN, gateway address, netmask and DNS address.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>wired</th><th>Object</th><th>Wired network information object. </th><th>required</th></tr>
     *       <tr class="odd"><th>wired.enabled</th><th>Boolean</th><th>Wired network connection true : enabled false : disabled </th><th>required</th></tr>
     *       <tr><th>wired.method</th><th>String</th><th>IP allocation "manual": fixed allocation "dhcp": dynamic allocation, If DHCP is enabled then ipAddress, gateway, netmask and DNS settings are ignored.</th><th>required</th></tr>
     *       <tr class="odd"><th>wired.ipAddress</th><th>String</th><th>IP address assigned to the wired network interface. </th><th>required</th></tr>
     *       <tr><th>wired.netmask</th><th>String</th><th>Netmask assigned to the wired network interface. </th><th>required</th></tr>
     *       <tr class="odd"><th>wired.gateway</th><th>String</th><th>Gateway address assigned to the wired network interface</th><th>required</th></tr>
     *       <tr><th>wired.dns1</th><th>String</th><th>DNS address assigned to the wired network interface. </th><th>required</th></tr>     
     *       <tr class="odd"><th>wired.dns2</th><th>String</th><th>Secondary DNS address assigned to the wired network interface. </th><th>required</th></tr>     
     *       <tr><th>wifi</th><th>Object</th><th>Wireless network information object. </th><th>required</th></tr>     
     *       <tr class="odd"><th>wifi.method</th><th>String</th><th>IP allocation "manual": fixed allocation "dhcp": dynamic allocation, If DHCP is enabled then ipAddress, gateway, netmask and DNS settings are ignored.</th><th>required</th></tr>
     *       <tr><th>wifi.enabled</th><th>Boolean</th><th>Wireless network connection true : enabled false : disabled </th><th>required</th></tr>     
     *       <tr class="odd"><th>wifi.ipAddress</th><th>String</th><th>IP address assigned to the wireless network interface. </th><th>required</th></tr>
     *       <tr><th>wifi.netmask</th><th>String</th><th>Netmask assigned to the wireless network interface. </th><th>required</th></tr>
     *       <tr class="odd"><th>wifi.gateway</th><th>String</th><th>Gateway address assigned to the wireless network interface</th><th>required</th></tr>
     *       <tr><th>wifi.dns1</th><th>String</th><th>DNS address assigned to the wireless network interface. </th><th>required</th></tr>
     *       <tr class="odd"><th>wifi.dns2</th><th>String</th><th>Secondary DNS address assigned to the wireless network interface. </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function setNetworkInformation () {
     *   function successCb() {
     *      console.log("successCb");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   var wired = {
     *      enabled : true,
     *      method : "manual",
     *      ipAddress : "192.168.0.2",
     *      netmask : "255.255.255.0",
     *      gateway : "192.168.0.1",
     *      dns1 : "156.147.135.180",
     *      dns2 : "156.147.135.181"
     *   };
     *   var wifi = {
     *      enabled : true,
     *      method : "manual",
     *      ipAddress : "192.168.0.2",
     *      netmask : "255.255.255.0",
     *      gateway : "192.168.0.1",
     *      dns1 : "156.147.135.180",
     *      dns2 : "156.147.135.181"
     *   };
     *   var options = {
     *      wired : wired,
     *      wifi : wifi
     *   };
     *   deviceInfo.setNetworkInfo(successCb, failureCb, options);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23getNetworkInfo.html">DeviceInfo.getNetworkInfo()</a><br>
     */
    DeviceInfo.prototype.setNetworkInfo = function (successCallback, errorCallback, options) {
        
        log("setNetworkInfo: ");
        
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'setNetworkInfo',
            parameters: options,
            onSuccess: function(result) {
                log("setNetworkInfo: onSuccess");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function(error) {
                log("setNetworkInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.setNetworkInfo Done");
    };
    
    /**
     * Gets beacon information.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Beacon is enabled true: enabled, false: disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>uuid</th><th>String</th><th>UUID of beacon, 32 hexadecimal digits. Only valid when 'enabled' is true.</th><th>required</th></tr>
     *       <tr><th>major</th><th>Number</th><th>Major number of beacon.(0 ~ 65535) Only valid when 'enabled' is true.</th><th>required</th></tr>     
     *       <tr class="odd"><th>minor</th><th>Number</th><th>Minor number of beacon.(0 ~ 65535) Only valid when 'enabled' is true.</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getBeaconInfo () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("enabled : " + cbObject.enabled);
     *      console.log("uuid : " + cbObject.uuid);
     *      console.log("major : " + cbObject.major);
     *      console.log("minor : " + cbObject.minor);
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getBeaconInfo(successCb, failureCb);
     * }
     * 
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23setBeaconInfo.html">DeviceInfo.setBeaconInfo()</a><br>, 
     */
    DeviceInfo.prototype.getBeaconInfo = function (successCallback, errorCallback) {
    
        log("getBeaconInfo: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/network/", {
            method: 'getBeaconInfo',
            parameters: {},
            onSuccess: function(result) {
                log("getBeaconInfo: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getBeaconInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.getBeaconInfo Done");
    };
    
    
    /**
     * Sets beacon information.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Beacon is enabled true: enabled, false: disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>uuid</th><th>String</th><th>UUID of beacon, 32 hexadecimal digits. Only valid when 'enabled' is true.</th><th>required</th></tr>
     *       <tr><th>major</th><th>Number</th><th>Major number of beacon.(0 ~ 65535) Only valid when 'enabled' is true.</th><th>required</th></tr>     
     *       <tr class="odd"><th>minor</th><th>Number</th><th>Minor number of beacon.(0 ~ 65535) Only valid when 'enabled' is true.</th><th>required</th></tr>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function setBeaconInfo () {
     *   function successCb() {
     *      console.log("successCb");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   var options = {
     *      enabled : true,
     *      uuid : "1A2B3C4D5E1A2B3C4D5E1A2B3C4D5EFF",
     *      major :1234,
     *      minor :4321
     *   };
     *   
     *   deviceInfo.setBeaconInfo(successCb, failureCb, options);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23getBeaconInfo.html">DeviceInfo.getBeaconInfo()</a><br>
     */
    DeviceInfo.prototype.setBeaconInfo = function (successCallback, errorCallback, options) {
        
        log("setBeaconInfo: ");
        
        var regex = function(uuid) {

            if (typeof uuid === "undefined" || uuid === null || uuid.length != 32) {
                return false;
            }

            var reg = new RegExp(/^[a-fA-F0-9]*$/g);
            return reg.exec(uuid) !== null ? true : false;

        };
        
        if (options.enabled === true && (regex(options.uuid) === false ||
            isNaN(options.major) || options.major < 0 || options.major > 65535 ||
            isNaN(options.minor) || options.minor < 0 || options.minor > 65535) ){
            
            log("setBeaconInfo: options are invalid.");
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "DSBI", "DeviceInfo.setBeaconInfo. Invalid options.");
                errorCallback(result);
            }
            
            return;
        }
            
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'setBeaconInfo',
            parameters: options,
            onSuccess: function(result) {
                log("setBeaconInfo: onSuccess");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function(error) {
                log("setBeaconInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.setBeaconInfo Done");
    };
    
    /**
     * Gets Soft AP information.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Soft AP is enabled true: enabled, false: disabled</th></tr>
     *       <tr class="odd"><th>ssid</th><th>String</th><th>SSID of Soft AP (Maximum length is 32). Only valid when 'enabled' is true.</th></tr>
     *       <tr><th>securityKey</th><th>String</th><th>Security key(6 characters). It is automatically prefixed with "LG". Only valid when 'enabled' is true.</th></tr>     
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSoftApInfo () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("enabled : " + cbObject.enabled);
     *      console.log("ssid : " + cbObject.ssid);
     *      console.log("securityKey : " + cbObject.securityKey);
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getSoftApInfo(successCb, failureCb);
     * }
     * 
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23setSoftApInfo.html">DeviceInfo.setSoftApInfo()</a><br>, 
     */
    DeviceInfo.prototype.getSoftApInfo = function (successCallback, errorCallback) {
    
        log("getSoftApInfo: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/network/", {
            method: 'getSoftApInfo',
            parameters: {},
            onSuccess: function(result) {
                log("getSoftApInfo: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getSoftApInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.getSoftApInfo Done");
    };
    
    /**
     * Sets Soft AP information.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Soft AP is enabled true: enabled, false: disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>ssid</th><th>String</th><th>SSID of Soft AP (Maximum length is 32). Only valid when 'enabled' is true.</th><th>required</th></tr>
     *       <tr><th>securityKey</th><th>String</th><th>Security key(6 characters). It is automatically prefixed with "LG". Only valid when 'enabled' is true.</th><th>required</th></tr>     
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function setSoftApInfo () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("enabled : " + cbObject.enabled);
     *      console.log("ssid : " + cbObject.ssid);
     *      console.log("securityKey : " + cbObject.securityKey);
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   var options = {
     *      enabled : true,
     *      ssid : "LG SIGNAGE",
     *      securityKey : "404571"
     *   };
     *   
     *   deviceInfo.setSoftApInfo(successCb, failureCb, options);
     * }
     * 
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23getSoftApInfo.html">DeviceInfo.getSoftApInfo()</a><br>, 
     */
    DeviceInfo.prototype.setSoftApInfo = function (successCallback, errorCallback, options) {
    
        log("setSoftApInfo: ");
        /**
         * 160128 iamjunyoung.park : Add condition 
         *                          - If turn off SoftAP, ssid and securityKey is not neccesary.
         *                            So check these values only if enable is true (turn of SoftAP)
         */
        if (options.enabled === true && ( // Add condition
            (options.ssid !== null && options.ssid.length > 32) || 
            (options.securityKey !== null && options.securityKey.length !== 6))) {
            
            log("setSoftApInfo: options are invalid.");
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "DSSI", "DeviceInfo.setSoftApInfo. Invalid options.");
                errorCallback(result);
            }
            
            return;
        }
            
            
        service.Request("luna://com.webos.service.commercial.signage.storageservice/network/", {
            method: 'setSoftApInfo',
            parameters: options,
            onSuccess: function(result) {
                log("setSoftApInfo: onSuccess");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function(error) {
                log("setSoftApInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.setSoftApInfo Done");
    };
    
    /**
     * Gets list of detected wifi networks.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>networkInfo</th><th>Array</th><th>Array of Wifi network information objects</th></tr>
     *       <tr class="odd"><th>networkInfo.signalLevel</th><th>Number</th><th>Signal level (0 ~ 100)</th></tr>
     *       <tr><th>networkInfo.ssid</th><th>String</th><th>SSID</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getWifiList () {
     *   function successCb(cbObject) {
     *   
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      for(var i=0; i < cbObject.networkInfo.length; i++) {
     *          console.log("network info : ssid " + cbObject.networkInfo[i].ssid);
     *          console.log("network info : signalLevel " + cbObject.networkInfo[i].signalLevel);
     *      }
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getWifiList(successCb, failureCb);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23connectWifi.html">DeviceInfo.connectWifi()</a><br>
     */
    DeviceInfo.prototype.getWifiList = function (successCallback, errorCallback) {
        
        log("getWifiList: ");
    
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'getWifiList',
            parameters: {},
            onSuccess: function(result) {
                log("getWifiList: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getWifiList: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.getWifiList Done");
    };
    
    /**
     * Connects wifi network using SSID and password.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>ssid</th><th>String</th><th>SSID (Maximum length is 32)</th><th>required</th></tr>
     *       <tr class="odd"><th>password</th><th>String</th><th>password</th><th>required</th></tr>
     *       <tr><th>hidden</th><th>Boolean</th><th>true : hidden AP. false : open AP(default)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function connectWifi () {
     *   function successCb() {
     *      console.log("successCb");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   var options = {
     *      ssid : "AP_NAME",
     *      password : "12341234"
     *   };
     *   
     *   deviceInfo.connectWifi(successCb, failureCb, options);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23getWifiList.html">DeviceInfo.getWifiList()</a><br>
     */
    DeviceInfo.prototype.connectWifi = function (successCallback, errorCallback, options) {
        
        log("connectWifi: ");
    
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'connectWifi',
            parameters: options,
            onSuccess: function(result) {
                log("connectWifi: onSuccess");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function(error) {
                log("connectWifi: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.connectWifi Done");
    };
    
    /**
     * Starts WPS (Wifi Protected Setup) using PBC (Push Button Configuration) or PIN.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>method</th><th>String</th><th>PBC : Push WPS button on your wireless router after the call with this parameter.<br>PIN : Enter the PIN which is returned with the success callback in your router's setting menu.</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>pin</th><th>String</th><th>If PIN method is used, this is returned in success callback. </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function startWpsbyPBC () {
     *   function successCb() {
     *      console.log("successCb");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   var options = {
     *   	method : "PBC"
     *   };
     *   
     *   deviceInfo.startWps(successCb, failureCb, options);
     * }
     * 
     * // Javascript code
     * function startWpsbyPIN () {
     *   function successCb(cbObject) {
     *      console.log("successCb PIN : " + cbObject.pin);
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   var options = {
     *   	method : "PIN"
     *   };
     *   
     *   deviceInfo.startWps(successCb, failureCb, options);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23stopWps.html">DeviceInfo.stopWps()</a><br>
     */
    DeviceInfo.prototype.startWps = function (successCallback, errorCallback, options) {
        
        log("startWps: ");
    
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'startWps',
            parameters: options,
            onSuccess: function(result) {
                log("startWps: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("startWps: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.startWps Done");
    };
    
    /**
     * Stops WPS (Wifi Protected Setup) operation.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * 
     * @example
     * // Javascript code
     * function stopWps () {
     *   function successCb() {
     *      console.log("successCb");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   
     *   deviceInfo.stopWps(successCb, failureCb);
     * }
     * @since 1.3
     * @see
     * <a href="DeviceInfo%23startWps.html">DeviceInfo.startWps()</a><br>
     */
    DeviceInfo.prototype.stopWps = function (successCallback, errorCallback) {
        
        log("stopWps: ");
    
        service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
            method: 'stopWps',
            parameters: {},
            onSuccess: function(result) {
                log("stopWps: onSuccess");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function(error) {
                log("stopWPS: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.stopWps Done");
    };
    
    /**
     * Gets network MAC information.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>wiredInfo</th><th>Object</th><th>An object that has MAC address of the wired network interface. </th></tr>     
     *       <tr class="odd"><th>wiredInfo.macAddress</th><th>String</th><th>MAC address of the wired network interface. </th></tr>
     *       <tr><th>wifiInfo</th><th>Object</th><th>An object that has MAC address of the wireless network interface. </th></tr>
     *       <tr class="odd"><th>wifiInfo.macAddress</th><th>String</th><th>MAC address of the wireless network interface. </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getNetworkMacInformation () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("wiredInfo.macAddress : " + cbObject.wiredInfo.macAddress);
     *      console.log("wifiInfo.macAddress : " + cbObject.wifiInfo.macAddress);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getNetworkMacInfo(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="DeviceInfo%23getNetworkInfo.html">DeviceInfo.getNetworkInfo()</a><br>
     */
    DeviceInfo.prototype.getNetworkMacInfo = function (successCallback, errorCallback) {
    
        log("getNetworkMacInfo: ");
        
        service.Request('luna://com.webos.service.tv.signage', {
            method: 'getinfo',
            parameters: {},
            onSuccess: function(result) {
                log("getNetworkMacInfo: onSuccess");
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getNetworkMacInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.getNetworkMacInfo Done");
    };
    
    /**
     * Gets device platform information. Platform information includes manufacturer, model name, software version, hardware version and product serial number.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>hardwareVersion</th><th>String</th><th>hardware version of signage monitor. </th></tr>     
     *       <tr class="odd"><th>manufacturer</th><th>String</th><th>manufacturer of signage monitor. </th></tr>
     *       <tr><th>modelName</th><th>String</th><th>signage monitor model name. </th></tr>     
     *       <tr class="odd"><th>sdkVersion</th><th>String</th><th>SDK version of signage monitor. </th></tr>
     *       <tr><th>serialNumber</th><th>String</th><th>signage monitor serial number. </th></tr>
     *       <tr class="odd"><th>firmwareVersion</th><th>String</th><th>firmware version of signage monitor. </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getPlatformInfo () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("hardwareVersion : " + cbObject.hardwareVersion);
     *      console.log("modelName : " + cbObject.modelName);
     *      console.log("sdkVersion : " + cbObject.sdkVersion);
     *      console.log("serialNumber : " + cbObject.serialNumber);
     *      console.log("firmwareVersion : " + cbObject.firmwareVersion);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   deviceInfo.getPlatformInfo(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="DeviceInfo%23getNetworkMacInfo.html">DeviceInfo.getNetworkMacInfo()</a><br>
     */
    DeviceInfo.prototype.getPlatformInfo = function (successCallback, errorCallback) {
    
        log("getPlatformInfo: ");
        
        service.Request('luna://com.webos.service.tv.systemproperty', {
            method: 'getSystemInfo',
            parameters: {
                keys: ["modelName", "serialNumber", "firmwareVersion", "hardwareVersion", "sdkVersion"]
            },
            onSuccess: function(result) {
                log("getPlatformInfo: onSuccess");
                result.manufacturer = "LGE";
                result.sdkVersion = "$SCAP_JS_REVISION";    // 160127 iamjunyoung.park : Constat value is assigned, why sdkVersion get from Luna API?
                delete result.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure: function(error) {
                log("getPlatformInfo: onFailure");
                delete error.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(error);
                }
            }
        });
        
        log("DeviceInfo.getPlatformInfo Done");
    };

    /**
     * Gets device usage information. Usage information includes cpu and memory status.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>cpus</th><th>Boolean</th><th>true to get CPU information, false otherwise.</th><th>optional</th></tr>
     *       <tr class="odd"><th>memory</th><th>Boolean</th><th>true to get memory information, false otherwise.</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Available</th></tr></thead>
     *   <tbody>
     *       <tr><th>cpus</th><th>Array</th><th>Array of objects containing information about each CPU/core installed: model, and times <br>(an object containing the number of milliseconds the CPU/core spent in: user, nice, sys, idle, and irq).</th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>memory</th><th>Object</th><th>Object containing total and free member fields. <br>'total' is total amount of system memory in bytes and 'free' is amount of free memory in bytes.</th><th>optional</th></tr>     
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSystemUsageInfo() {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("memory.total : " + cbObject.memory.total);
     *      console.log("memory.free : " + cbObject.memory.free);
     *
     *      for (var i in cbObject.cpus) {
     *         console.log("cpu.model " +  cbObject.cpus[i].model);
     *         console.log("cpu.times.user " +  cbObject.cpus[i].times.user);
     *         console.log("cpu.times.nice " +  cbObject.cpus[i].times.nice);
     *         console.log("cpu.times.sys " +  cbObject.cpus[i].times.sys);
     *         console.log("cpu.times.idle " +  cbObject.cpus[i].times.idle);
     *         console.log("cpu.times.irq " +  cbObject.cpus[i].times.irq);
     *      } 
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var deviceInfo = new DeviceInfo();
     *   var options = {cpus : true, memory : true};
     *   deviceInfo.getSystemUsageInfo(successCb, failureCb, options);
     * }
     * @since 1.2
     * @see
     * <a href="DeviceInfo%23getPlatformInfo.html">DeviceInfo.getPlatformInfo()</a><br>
     */
    DeviceInfo.prototype.getSystemUsageInfo = function (successCallback, errorCallback, options) {
        
        log("getSystemUsageInfo: ");
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method : "getSystemUsageInfo",
            parameters : {
                cpus : options.cpus,
                memory : options.memory
            },
            onSuccess : function(result) {
                if (result.returnValue === true) {
                    var ret = {};
                    if (typeof result.memory !== 'undefined' ) {
                    	ret.memory = result.memory;
                    }
                    if (typeof result.cpus !== 'undefined' ) {
                        ret.cpus = result.cpus;
                    }
                    if (typeof successCallback === 'function') {
                        successCallback(ret);
                    }
                } else {
                    if (typeof errorCallback === 'function') {
                        errorCallback({
                            errorCode:result.errorCode,
                            errorText:result.errorText
                        });
                    }
                }
            },
            onFailure : function (result) {
                if (typeof errorCallback === 'function') {
                    errorCallback({
                        errorCode:result.errorCode,
                        errorText:result.errorText
                    });
                }
            }
        });
        
        log("DeviceInfo.getSystemUsageInfo Done");
    };
    
    /**
     * Sets Proxy Info
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>proxy is enabled true : enabled, false : disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>ipAddress</th><th>String</th><th>proxy server ip (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *       <tr><th>port</th><th>Number</th><th>proxy server port (0 ~ 65535) (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *       <tr class="odd"><th>userName</th><th>String</th><th>proxy server username (when 'enabled' is true and authentication is used by proxy server, it is required)</th><th>optional</th></tr>
     *       <tr><th>password</th><th>String</th><th>proxy server password (when 'enabled' is true and authentication is used by proxy server, it is required)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * 
     * @example
     * // Javascript code
     * function setProxyInfo () {
     *		var options = {
     *			enabled : true,
     *			ipAddress : "163.231.22.43",
     *			password : "35792234",
     *			port : 5000,
     *			userName : "example"
	 *		};
	 *		function successCb(cbObject) {
	 *			console.log("sucess");
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.setProxyInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23getProxyInfo.html">DeviceInfo.getProxyInfo()</a><br>
     */
    DeviceInfo.prototype.setProxyInfo = function(successCallback, errorCallback, options) {
        var proxyInfo = {};

        log("setProxyInfo: " + options.enabled);

        if ((options.enabled === null || options.enabled === undefined || typeof options.enabled !== 'boolean') && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "DSPI", "DeviceInfo.setProxyInfo returns failure. enabled is required.");
            errorCallback(result);
            log("DeviceInfo.setProxyInfo invalid ");
            return;
        }

        if (options.enabled == false) {
            proxyInfo.proxyEnable = "off";
        } else {
            if ((options.ipAddress === null || options.ipAddress === undefined || options.ipAddress === "" || 
                options.port === null || options.port === undefined || isNaN(options.port)) && typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "DSPI", "DeviceInfo.setProxyInfo returns failure. ipAddress and port are required.");
                errorCallback(result);
                log("DeviceInfo.setProxyInfo invalid ");
                return;
            }

            proxyInfo.proxyEnable        = "on";
            proxyInfo.proxySingleAddress = options.ipAddress;
            proxyInfo.proxySinglePort    = options.port.toString();

            if (typeof options.userName === 'string' && options.userName !== undefined && options.userName !== null &&
                typeof options.password === 'string' && options.password !== undefined && options.password !== null) {
                proxyInfo.proxySingleUsername = options.userName;
                proxyInfo.proxySinglePassword = options.password;
            }
        }

        log("proxyInfo : " + JSON.stringify(proxyInfo));

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "set",
            parameters: {
                category: "commercial",
                settings: proxyInfo                    
            },
            onSuccess: function(result) {
                log("setProxyInfo: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure: function(result) {
                log("setSoundOut: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DSPI", "DeviceInfo.setProxyInfo returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("DeviceInfo.setProxyInfo Done");
    };

	/**
     * Gets Proxy Info
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>proxy is enabled true : enabled, false : disabled</th></tr>
     *       <tr class="odd"><th>ipAddress</th><th>String</th><th>proxy server ip (when 'enabled' is true, it is required)</th></tr>
     *       <tr><th>port</th><th>Number</th><th>proxy server port (0 ~ 65535) (when 'enabled' is true, it is required)</th></tr>
     *       <tr class="odd"><th>userName</th><th>String</th><th>proxy server username (when 'enabled' is true and authentication is used by proxy server, it is required)</th></tr>
     *       <tr><th>password</th><th>String</th><th>proxy server password (when 'enabled' is true and authentication is used by proxy server, it is required)</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
	 * @example
     * // Javascript code
     * function getProxyInfo () {
	 *		function successCb(cbObject) {
	 *			console.log("cbObject : " + JSON.stringify(cbObject));
	 *			console.log("enabled : " + cbObject.enabled);
	 *	 		console.log("ipAddress : " + cbObject.ipAddress);
	 *			console.log("port : " + cbObject.port);
	 *			console.log("userName : " + cbObject.userName);
	 *			console.log("password : " + cbObject.password);
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.getProxyInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23setProxyInfo.html">DeviceInfo.setProxyInfo()</a><br>
     */
    DeviceInfo.prototype.getProxyInfo = function (successCallback, errorCallback) {
        
        log("getProxyInfo: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["proxyEnable", "proxySingleAddress", "proxySinglePort", "proxySingleUsername", "proxySinglePassword"]
            },
            onSuccess: function(result) {
                log("getProxyInfo: On Success");

                if (result.returnValue === true) {
                    var cbObj       = {};
                    cbObj.enabled   = (result.settings.proxyEnable === "on") ? true : false;
                    cbObj.ipAddress = result.settings.proxySingleAddress;
                    cbObj.port      = parseInt(result.settings.proxySinglePort);
                    cbObj.userName  = result.settings.proxySingleUsername;
                    cbObj.password  = result.settings.proxySinglePassword;              

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getProxyInfo: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DGPI", "DeviceInfo.getProxyInfo returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("DeviceInfo.getProxyInfo Done");
    };

		/**
     * Sets iBeacon Info
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>iBeacon is enabled true : enabled, false : disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>uuid</th><th>String</th><th>UUID of iBeacon, 32 hexadecimal digits. (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *       <tr><th>major</th><th>Number</th><th>major (0 ~ 65535) (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *       <tr class="odd"><th>minor</th><th>Number</th><th>minor (0 ~ 65535) (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * 
     * @example
     * // Javascript code
     * function setiBeaconInfo () {
     *		var options = {
     *			enabled : true,
     *			uuid : "f7826da64fa24e988024bc5b71e0893e",
	 * 			major : 5000,
	 * 			minor : 3000
	 *		};
	 *		function successCb(cbObject) {
	 *			console.log("sucess");
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.setiBeaconInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23getiBeaconInfo.html">DeviceInfo.getiBeaconInfo()</a><br>
     */
    DeviceInfo.prototype.setiBeaconInfo = function(successCallback, errorCallback, options) {
        var regex = function(uuid) {
            if (typeof uuid === "undefined" || uuid === null || uuid.length != 32) {
                return false;
            }

            var reg = new RegExp(/^[a-fA-F0-9]*$/g);
            return reg.exec(uuid) !== null ? true : false;
        };

        var iBeaconInfo = {};

        if ((options.enabled === null || options.enabled === undefined || typeof options.enabled !== 'boolean') && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "DSIB", "DeviceInfo.setiBeaconInfo returns failure. enabled is required.");
            errorCallback(result);
            log("DeviceInfo.setiBeaconInfo invalid ");
            return;
        }
    
        if (options.enabled == false) {
            iBeaconInfo.beaconMode = "off";
        } else {
            if ((options.uuid === null || options.uuid === undefined || regex(options.uuid) === false) && typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "DSIB", "DeviceInfo.setiBeaconInfo returns failure. uuid is not valid.");
                errorCallback(result);
                log("DeviceInfo.setiBeaconInfo invalid ");
                return;
            }

            if ((options.major === null || options.major === undefined || isNaN(options.major) || options.major < 0 || options.major > 65535 ||
                    options.minor === null || options.minor === undefined || isNaN(options.minor) || options.minor < 0 || options.minor > 65535) &&
                typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "DSIB", "DeviceInfo.setiBeaconInfo returns failure. major and minor are not valid.");
                errorCallback(result);
                log("DeviceInfo.setiBeaconInfo invalid ");
                return;
            }

            iBeaconInfo.beaconMode = "on";
            iBeaconInfo.beaconType = "iBeacon";
            iBeaconInfo.iBeaconUuid = options.uuid;
            iBeaconInfo.iBeaconMajor = options.major.toString();
            iBeaconInfo.iBeaconMinor = options.minor.toString();
        }

        log("iBeaconInfo: " + JSON.stringify(iBeaconInfo));

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "set",
            parameters: {
                category: "commercial",
                settings: iBeaconInfo                    
            },
            onSuccess: function(result) {
                log("setiBeaconInfo: On Success");

                if (result.returnValue === true) {
                    service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
                        method: 'notifyUpdatingBeaconInfo',
                        parameters: {},
                        onSuccess: function(result) {
                            log("notifyUpdatingBeaconInfo: onSuccess");
                            delete result.returnValue;
                            if (typeof successCallback === 'function') {
                                successCallback(result);
                            }
                        },
                        onFailure: function(error) {
                            log("notifyUpdatingBeaconInfo: onFailure");
                            delete error.returnValue;
                            if (typeof errorCallback === 'function') {
                                errorCallback(error);
                            }
                        }
                    });
                }
            },
            onFailure: function(result) {
                log("setiBeaconInfo: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DSIB", "DeviceInfo.setiBeaconInfo returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("DeviceInfo.setiBeaconInfo Done");
    };

		/**
     * Gets iBeacon Info
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>iBeacon is enabled true : enabled, false : disabled</th></tr>
     *       <tr class="odd"><th>uuid</th><th>String</th><th>UUID of iBeacon, 32 hexadecimal digits. (when 'enabled' is true, it is required)</th></tr>
     *       <tr><th>major</th><th>Number</th><th>major (0 ~ 65535) (when 'enabled' is true, it is required)</th></tr>
     *       <tr class="odd"><th>minor</th><th>Number</th><th>minor (0 ~ 65535) (when 'enabled' is true, it is required)</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
	 * @example
     * // Javascript code
     * function getiBeaconInfo () {
	 *		function successCb(cbObject) {
	 *			console.log("cbObject : " + JSON.stringify(cbObject));
	 *			console.log("enabled : " + cbObject.enabled);
	 *			console.log("uuid : " + cbObject.uuid);
	 *			console.log("major : " + cbObject.major);
	 *			console.log("minor : " + cbObject.minor);
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.getiBeaconInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23setiBeaconInfo.html">DeviceInfo.setiBeaconInfo()</a><br>
     */
    DeviceInfo.prototype.getiBeaconInfo = function (successCallback, errorCallback) {
        
        log("getiBeaconInfo: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["beaconMode", "iBeaconUuid", "iBeaconMajor", "iBeaconMinor"]
            },
            onSuccess: function(result) {
                log("getiBeaconInfo: On Success");

                if (result.returnValue === true) {
                    var cbObj       = {};
                    cbObj.enabled = (result.settings.beaconMode === "on") ? true : false;
                    cbObj.uuid    = result.settings.iBeaconUuid;
                    cbObj.major   = parseInt(result.settings.iBeaconMajor);
                    cbObj.minor   = parseInt(result.settings.iBeaconMinor);

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getiBeaconInfo: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DGIB", "DeviceInfo.getiBeaconInfo returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("DeviceInfo.getiBeaconInfo Done");
    };

	/**
     * Sets Eddystone Info, Each <a href="DeviceInfo.EddystoneFrame.html#constructor">EddystoneFrame</a> has a set of predefined frame properties.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Eddystone is enabled true : enabled, false : disabled</th><th>required</th></tr>
     *       <tr class="odd"><th>frame</th><th>String</th><th><a href="DeviceInfo.EddystoneFrame.html#constructor">EddystoneFrame</a></th><th>optional</th></tr>
     *       <tr><th>frameData</th><th>String</th><th>UUID of beacon, 32 hexadecimal digits. Only valid when 'enabled' is true and 'frame' is DeviceInfo.EddystoneFrame.UUID<br>
	 *       URL of beacon. Only valid when 'enabled' is true and 'frame' is DeviceInfo.EddystoneFrame.URL<br>
	 *       (when 'enabled' is true, it is required)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * 
     * @example
     * // Javascript code
     * function setEddystoneInfo () {
     *		var options = {
     *			enabled : true,
     *			uuid : "f7826da64fa24e988024bc5b71e0893e",
	 * 			major : 5000,
	 * 			minor : 3000
	 *		};
	 *		function successCb(cbObject) {
	 *			console.log("sucess");
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.setEddystoneInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23getEddystoneInfo.html">DeviceInfo.getEddystoneInfo()</a><br>
     */
    DeviceInfo.prototype.setEddystoneInfo = function(successCallback, errorCallback, options) {
        var chkuuid = function(uuid) {
            if (typeof uuid === "undefined" || uuid === null || uuid.length != 32) {
                return false;
            }

            var reg = new RegExp(/^[a-fA-F0-9]*$/g);
            return reg.exec(uuid) !== null ? true : false;
        };

        var eddystoneInfo = {};

        log("setEddystoneInfo: " + options.enabled);

        if ((options.enabled === null || options.enabled === undefined || typeof options.enabled !== 'boolean') && typeof errorCallback === 'function') 
        {
            var result = {};
            checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure. enabled is required.");
            errorCallback(result);
            log("DeviceInfo.setEddystoneInfo invalid ");
            return;
        }

        if (options.enabled === false) 
        {
            eddystoneInfo.beaconMode = "off";
        } 
        else 
        {
            eddystoneInfo.beaconMode = "on";
            eddystoneInfo.beaconType = "eddystone";

            if (options.frame === DeviceInfo.EddystoneFrame.UUID) 
            {
                if (chkuuid(options.frameData) === false && typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure. frameData is not valid.");
                    errorCallback(result);
                    log("DeviceInfo.setEddystoneInfo invalid ");
                    return;
                }

                eddystoneInfo.eddyStoneFrame = options.frame;
                eddystoneInfo.eddyStoneUuid  = options.frameData;

            } 
            else if (options.frame === DeviceInfo.EddystoneFrame.URL) 
            {
                if ((options.frameData === null || options.frameData === undefined || typeof options.frameData !== 'string' ||
                    options.frameData.search("://") < 0 || options.frameData.substring(0, 4).toUpperCase() !== "HTTP") && typeof errorCallback === 'function') 
                {
                    var result = {};
                    checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure. frameData is not valid.");
                    errorCallback(result);
                    log("DeviceInfo.setEddystoneInfo invalid ");
                    return;
                }               

                eddystoneInfo.eddyStoneFrame     = options.frame;
                eddystoneInfo.eddyStoneUrlPrefix = options.frameData.substring(0, options.frameData.search("://"));
                if (options.frameData.substring(options.frameData.search("://") + 3, 3).toUpperCase() === "WWW") {
                    eddystoneInfo.eddyStoneUrlPrefix = eddystoneInfo.eddyStoneUrlPrefix + "Ex";
                }

                var lengthPrefix = 0;
                if(eddystoneInfo.eddyStoneUrlPrefix.toUpperCase() === "HTTP"){
                    lengthPrefix = 7;//http://
                } else if(eddystoneInfo.eddyStoneUrlPrefix.toUpperCase() === "HTTPEX"){
                    lengthPrefix = 11;//http://www.
                } else if(eddystoneInfo.eddyStoneUrlPrefix.toUpperCase() === "HTTPS"){
                    lengthPrefix = 8;//https://
                } else if(eddystoneInfo.eddyStoneUrlPrefix.toUpperCase() === "HTTPSEX"){
                    lengthPrefix = 12;//https://www.
                }

                if (options.frameData.length - lengthPrefix > 17) 
                {
                    var result = {};
                    checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure. url size is over.");
                    errorCallback(result);
                    log("DeviceInfo.setEddystoneInfo invalid ");
                    return;
                } 

                eddystoneInfo.eddyStoneUrl       = options.frameData.substring(lengthPrefix, options.frameData.length);
                eddystoneInfo.eddyStoneUrlExCode = "noneValue";                
            } 
            else 
            {
                var result = {};
                checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure. frame is not valid.");
                errorCallback(result);
                log("DeviceInfo.setEddystoneInfo invalid ");
                return;
            }
        }

        log("eddystoneInfo : " + JSON.stringify(eddystoneInfo));

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "set",
            parameters: {
                category: "commercial",
                settings: eddystoneInfo
            },
            onSuccess: function(result) {
                log("setEddystoneInfo: On Success");

                if (result.returnValue === true) {
                    service.Request('luna://com.webos.service.commercial.signage.storageservice/network/', {
                        method: 'notifyUpdatingBeaconInfo',
                        parameters: {},
                        onSuccess: function(result) {
                            log("notifyUpdatingBeaconInfo: onSuccess");
                            delete result.returnValue;
                            if (typeof successCallback === 'function') {
                                successCallback(result);
                            }
                        },
                        onFailure: function(error) {
                            log("notifyUpdatingBeaconInfo: onFailure");
                            delete error.returnValue;
                            if (typeof errorCallback === 'function') {
                                errorCallback(error);
                            }
                        }
                    });
                }
            },
            onFailure: function(result) {
                log("setEddystoneInfo: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DSEI", "DeviceInfo.setEddystoneInfo returns failure.");
                    errorCallback(result);
                }
            }
        });
    };
        
    /**
     * Gets Eddystone Info, Each <a href="DeviceInfo.EddystoneFrame.html#constructor">EddystoneFrame</a> has a set of predefined frame properties.
     * @class DeviceInfo
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Eddystone is enabled true : enabled, false : disabled</th></tr>
     *       <tr class="odd"><th>frame</th><th>String</th><th><a href="DeviceInfo.EddystoneFrame.html#constructor">EddystoneFrame</a></th></tr>
     *       <tr><th>frameData</th><th>String</th><th>UUID of beacon, 32 hexadecimal digits. Only valid when 'enabled' is true and 'frame' is DeviceInfo.EddystoneFrame.UUID<br>
	 *       URL of beacon. Only valid when 'enabled' is true and 'frame' is DeviceInfo.EddystoneFrame.URL<br>
	 *       (when 'enabled' is true, it is required)</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
	 * @example
     * // Javascript code
     * function getEddystoneInfo () {
	 *		function successCb(cbObject) {
	 *			console.log("cbObject : " + JSON.stringify(cbObject));
	 *			console.log("enabled : " + cbObject.enabled);
	 *			console.log("frame : " + cbObject.uuid);
	 *			console.log("frameData : " + cbObject.major);
	 *			// Do something
	 *		}
	 *		function failureCb(cbObject) {
	 *			var errorCode = cbObject.errorCode;
	 *			var errorText = cbObject.errorText;
	 *			console.log ("Error Code [" + errorCode + "]: " + errorText);
	 *			}
	 *		var deviceinfo = new DeviceInfo();
	 *		deviceinfo.getEddystoneInfo(successCb, failureCb);
	 * }
     * @since 1.4
     * @see
     * <a href="DeviceInfo%23setEddystoneInfo.html">DeviceInfo.setEddystoneInfo()</a><br>
     */    
    DeviceInfo.prototype.getEddystoneInfo = function (successCallback, errorCallback) {
        
        log("getEddystoneInfo: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["beaconMode", "eddyStoneFrame", "eddyStoneUuid", "eddyStoneUrlPrefix", "eddyStoneUrl", "eddyStoneUrlExCode"]
            },
            onSuccess: function(result) {
                log("getEddystoneInfo: On Success");

                if (result.returnValue === true) {
                    var cbObj     = {};
                    cbObj.enabled = (result.settings.beaconMode === "on") ? true : false;
                    cbObj.frame   = result.settings.eddyStoneFrame;

                    if (result.settings.eddyStoneFrame === DeviceInfo.EddystoneFrame.UUID) {
                        cbObj.frameData = result.settings.eddyStoneUuid;
                    } else {
                        if(result.settings.eddyStoneUrlPrefix === "http") {
                            cbObj.frameData = "http://" + result.settings.eddyStoneUrl;
                        } else if (result.settings.eddyStoneUrlPrefix === "httpEx") {
                            cbObj.frameData = "http://www." + result.settings.eddyStoneUrl;
                        } else if (result.settings.eddyStoneUrlPrefix === "https") {
                            cbObj.frameData = "https://" + result.settings.eddyStoneUrl;
                        } else {
                            cbObj.frameData = "https://www." + result.settings.eddyStoneUrl;
                        }                        
                    }

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getEddystoneInfo: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "DGEI", "DeviceInfo.getEddystoneInfo returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("DeviceInfo.getEddystoneInfo Done");
    };

    module.exports = DeviceInfo;
});

DeviceInfo = cordova.require('cordova/plugin/deviceInfo'); // jshint ignore:line

