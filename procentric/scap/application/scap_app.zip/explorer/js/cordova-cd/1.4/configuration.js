/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the configuration API itself, and provides a global namespace for operating configuration service.
 * @class
 */
cordova.define('cordova/plugin/configuration', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function (uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
               if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
                }
        }};
    }
    
    /**
     * configuration interface
     */
    var Configuration = function () {
    };
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText === undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }
    
    /**
     * @namespace Configuration.PictureMode
     */
    Configuration.PictureMode = {
    /**
     * vivid
     * @since 1.0
     * @constant
     */
    VIVID : "vivid",
    /**
     * standard
     * @since 1.0
     * @constant
     */
    STANDARD : "normal",
    /**
     * APS (Auto Power Saving)
     * @since 1.0
     * @constant
     */
    APS : "eco",
    /**
     * cinema
     * @since 1.0
     * @constant
     */
    CINEMA : "cinema",
    /**
     * game
     * @since 1.0
     * @constant
     */
    GAME : "game",
    /**
     * sports
     * @since 1.0
     * @constant
     */
    SPORTS : "sports",
    /**
     * expert1
     * @since 1.0
     * @constant
     */
    EXPERT1 : "expert1",
    /**
     * expert2 (calibration)
     * @since 1.0
     * @constant
     */
    EXPERT2 : "expert2"
    };
    
    
    /**
     * @namespace Configuration.AppMode
     */
    Configuration.AppMode = {
    /**
     * local
     * @since 1.1
     * @constant
     */
    LOCAL : "local",
    /**
     * usb
     * @since 1.1
     * @constant
     */
    USB : "usb",
    /**
     * remote
     * @since 1.1
     * @constant
     */
    REMOTE : "remote"
    };

    Configuration.LocaleList =
        [{
            'language': 'čeština',
            'languageCode': 'cs',
            'countries': [{
                'name': '',
                'specifier': 'cs-CZ'
            }]
        }, {
            'language': 'dansk',
            'languageCode': 'da',
            'countries': [{
                'name': '',
                'specifier': 'da-DK'
            }]
        }, {
            'language': 'Deutsch',
            'languageCode': 'de',
            'countries': [{
                'name': '',
                'specifier': 'de-DE'
            }]
        }, {
            'language': 'English',
            'languageCode': 'en',
            'countries': [{
                'name': '',
                'specifier': 'en-US'
            }]
        }, {
            'language': 'Español',
            'languageCode': 'es',
            'countries': [{
                'name': '',
                'specifier': 'es-ES'
            }]
        }, {
            'language': 'ελληνική γλώσσα',
            'languageCode': 'el',
            'countries': [{
                'name': '',
                'specifier': 'el-GR'
            }]
        }, {
            'language': 'Français',
            'languageCode': 'fr',
            'countries': [{
                'name': '',
                'specifier': 'fr-FR'
            }]
        }, {
            'language': 'italiano',
            'languageCode': 'it',
            'countries': [{
                'name': '',
                'specifier': 'it-IT'
            }]
        }, {
            'language': 'Nederlands',
            'languageCode': 'nl',
            'countries': [{
                'name': '',
                'specifier': 'nl-NL'
            }]
        }, {
            'language': 'norsk',
            'languageCode': 'nb',
            'countries': [{
                'name': '',
                'specifier': 'nb-NO'
            }]
        }, {
            'language': 'português',
            'languageCode': 'pt',
            'countries': [{
                'name': 'Portugal',
                'specifier': 'pt-PT'
            }, {
                'name': 'Brasil',
                'specifier': 'pt-BR'
            }]
        }, {
            'language': 'русский',
            'languageCode': 'ru',
            'countries': [{
                'name': '',
                'specifier': 'ru-RU'
            }]
        }, {
            'language': 'suomi',
            'languageCode': 'fi',
            'countries': [{
                'name': '',
                'specifier': 'fi-FI'
            }]
        }, {
            'language': 'svenska',
            'languageCode': 'sv',
            'countries': [{
                'name': '',
                'specifier': 'sv-SE'
            }]
        }, {
            'language': '한국어',
            'languageCode': 'ko',
            'countries': [{
                'name': '',
                'specifier': 'ko-KR'
            }]
        }, {
            'language': '中文',
            'languageCode': 'zh-Hans',
            'countries': [{
                'name': '中国',
                'specifier': 'zh-Hans-CN'
            }]
        }, {
            'language': '日本語',
            'languageCode': 'ja',
            'countries': [{
                'name': '',
                'specifier': 'ja-JP'
            }]
        }, {
            'language': '中文',
            'languageCode': 'zh',
            'countries': [{
                'name': '香港',
                'specifier': 'zh-Hant-HK'
            }]
        }];


    function isValidSpecifier(value) {
        var arr = Configuration.LocaleList;

        for (var i=0; i<arr.length; i++) {
            var countries = arr[i].countries;

            for(var j=0; j<countries.length; j++)
            {
                if (countries[j].specifier === value) {
                    return true;
                }
            }            
        }

        return false;        
    }

    function isValidLanguageCode(value) {
        var arr = Configuration.LocaleList;
        
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].languageCode === value) {
                return true;
            }
        }

        return false      
    }
    
    var version = null;
    function checkPlatformVersion(cb) {
        
        if (version === null) {
            
            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    
                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        version = 1;
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        version = 2;
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        version = 3;
                    } else {
                        version = 0;
                    }
                    
                    delete result.returnValue;
                    
                    cb(version);
                    
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    delete error.returnValue;
                    version = 0;
                    
                    cb(version);
                }
            });
            
        } else {
            cb(version);
        }
    }
    
    /**
     * Sets picture mode. Each <a href="Configuration.PictureMode.html#constructor">PictureMode</a> has a set of predefined picture properties. And each picture properties can be changed with setPictureProperty(). 
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>mode</th><th>String</th><th><a href="Configuration.PictureMode.html#constructor">Configuration.PictureMode</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function setPictureMode () {
     *   var options = {
     *      mode : Configuration.PictureMode.VIVID
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *     
     *   var configuration = new Configuration();
     *   configuration.setPictureMode(successCb, failureCb, options);
     * }
     * @since 1.0
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @see
     * <a href="Configuration%23getPictureMode.html">Configuration.getPictureMode()</a><br>
     */
    Configuration.prototype.setPictureMode = function (successCallback, errorCallback, options) {
    
        log("setPictureMode: " + JSON.stringify(options));
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "picture",
                settings : {
                    "pictureMode" : options.mode 
                }
            },
            onSuccess : function(result) {
                log("setPictureMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setPictureMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSPM", "Configuration.setPictureMode returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.setPictureMode Done");
    };
    
    /**
     * Gets picture mode. Each <a href="Configuration.PictureMode.html#constructor">PictureMode</a> has a set of predefined picture properties.
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>mode</th><th>String</th><th><a href="Configuration.PictureMode.html#constructor">Configuration.PictureMode</a></th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getPictureMode () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("mode : " + cbObject.mode);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *     
     *   var configuration = new Configuration();
     *   configuration.getPictureMode(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Configuration%23setPictureMode.html">Configuration.setPictureMode()</a><br>
     */
    Configuration.prototype.getPictureMode = function (successCallback, errorCallback) {
    
        log("getPictureMode: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "picture",
                keys : ["pictureMode"]
            },
            onSuccess : function(result) {
                log("getPictureMode: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var cbObj = {};
                        cbObj.mode = result.settings.pictureMode;
                        
                        successCallback(cbObj);
                    }
                }
            },
            onFailure : function(result) {
                log("getPictureMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGPM", "Configuration.getPictureMode returns failure.");
                    errorCallback(result);
                }
            }
        });
                
    log("Configuration.getPictureMode Done");
    
    };
    
    /**
     * Sets picture property. Each picture mode has a set of picture properties. 
     * If picture mode is changed, picture properties of that mode will be set accordingly.
     *  
     *
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>VIVID</th><th>STANDARD</th><th>APS</th><th>CINEMA</th><th>SPORTS</th><th>GAME</th><th>EXPERTS1</th><th>EXPERTS2</th></tr></thead>
     *   <tbody>
     *                   <tr><th>backlight</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>contrast</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>brightness</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>sharpness</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> X </th><th> X </th></tr>
     *                   <tr><th>hSharpness</th><th> X </th><th> X </th><th> X </th><th> X </th><th> X </th><th> X </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>vSharpness</th><th> X </th><th> X </th><th> X </th><th> X </th><th> X </th><th> X </th><th> O </th><th> O </th></tr>
     *                   <tr><th>color</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>tint</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>colorTemperature</th><th> O </th><th> O </th><th> O </th><th> X </th><th> O </th><th> O </th><th> X </th><th> X </th></tr>
     *       <tr class="odd"><th>dynamicContrast</th><th> X </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>superResolution</th><th> X </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>colorGamut</th><th> X </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>dynamicColor</th><th> X </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>noiseReduction</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>mpegNoiseReduction</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *       <tr class="odd"><th>blackLevel</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *                   <tr><th>gamma</th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th><th> O </th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>backlight</th><th>Number</th><th>backlight of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>contrast</th><th>Number</th><th>contrast of display (0~100) </th><th>optional</th></tr>
     *                   <tr><th>brightness</th><th>Number</th><th>brightness of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>sharpness</th><th>Number</th><th>sharpness of display (0~50) </th><th>optional</th></tr>
     *                   <tr><th>hSharpness</th><th>Number</th><th>hSharpness of display (0~50)</th><th>optional</th></tr>
     *       <tr class="odd"><th>vSharpness</th><th>Number</th><th>vSharpness of display (0~50) </th><th>optional</th></tr>
     *                   <tr><th>color</th><th>Number</th><th>color of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>tint</th><th>Number</th><th>tint of display (0~100) R:0, G:100</th><th>optional</th></tr>
     *                   <tr><th>colorTemperature</th><th>Number</th><th>colorTemperature of display (0~100) W:0, C:100 </th><th>optional</th></tr>
     *       <tr class="odd"><th>dynamicContrast</th><th>String</th><th>dynamicContrast of display (off/low/medium/high) </th><th>optional</th></tr>
     *                   <tr><th>superResolution</th><th>String</th><th>superResolution of display (off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>colorGamut</th><th>String</th><th>colorGamut of display (wide/standard) </th><th>optional</th></tr>
     *                   <tr><th>dynamicColor</th><th>String</th><th>dynamicColor of display (off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>noiseReduction</th><th>String</th><th>noiseReduction of display (auto/off/low/medium/high) </th><th>optional</th></tr>
     *                   <tr><th>mpegNoiseReduction</th><th>String</th><th>mpegNoiseReduction of display (auto/off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>blackLevel</th><th>String</th><th>blackLevel of display (low/high) </th><th>optional</th></tr>
     *                   <tr><th>gamma</th><th>String</th><th>gamma of display (low/medium/high/high2) </th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
     * Note : 'high2' option is depends on platform.
     * @example
     * // Javascript code
     * function setPictureProperty () {
     *   var options = {
     *   // For example, expert1 mode.
     *      backlight : 50,
     *      contrast : 50,
     *      brightness : 50,
     *      hSharpness : 50,
     *      vSharpness : 50,
     *      color : 50,
     *      tint : 50,
     *      colorTemparature : 50,               
     *      dynamicContrast : "low",
     *      superResolution : "low",
     *      colorGamut : "wide",
     *      dynamicColor : "high",
     *      noiseReduction : "medium",
     *      mpegNoiseReduction : "low",
     *      blackLevel : "low",
     *      gamma : "medium"
     *   };
     *   
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.setPictureProperty(successCb, failureCb, options);
     * }
     * @since 1.0
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @see
     * <a href="Configuration%23getPictureProperty.html">Configuration.getPictureProperty()</a><br>
     */
    Configuration.prototype.setPictureProperty = function (successCallback, errorCallback, options) {
    
        log("setPictureProperty: " + JSON.stringify(options));
        
        checkPlatformVersion(function(ver){

            var sets = {};
            
            for (var key in options) {
                if (key !== undefined && key !== null) {
                    sets[key] = options[key];
                    if (key === 'tint' || key === 'colorTemperature') {
                        sets[key] -=50;
                    }
                    else if (key === 'blackLevel') {
                        sets[key] = {
                            "unknown": options[key]
                        };
                        if (options[key] !== "low" && options[key] !== "high" ) {
                            log("setPictureProperty: gamma value error " + JSON.stringify(options));
                            var result = {};
                            checkErrorCodeNText(result, "CSPP", "Configuration.setPictureProperty, There is No matched item : blackLevel.");
                            errorCallback(result);
                            return;
                        }
                    } else if (key === 'gamma' && (ver === 2  || ver === 3) && options[key] === "high") {
                        sets[key] = "high1";
                    }
                }
            }
            
            log(JSON.stringify(sets));
        
            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "set",
                parameters : {
                    category : "picture",
                    settings : sets
                },
                onSuccess : function(result) {
                    log("setPictureProperty: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure : function(result) {
                    log("setPictureProperty: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CSPP", "Configuration.setPictureProperty returns failure.");
                        errorCallback(result);
                    }
                }
            });            
            log("Configuration.setPictureProperty Done");            
        });
    };
    
    /**
     * Gets picture property. Each <a href="Configuration.PictureMode.html#constructor">PictureMode</a> has a set of predefined picture properties.
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Available</th></tr></thead>
     *   <tbody>
     *       <tr><th>backlight</th><th>Number</th><th>backlight of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>contrast</th><th>Number</th><th>contrast of display (0~100) </th><th>optional</th></tr>
     *                   <tr><th>brightness</th><th>Number</th><th>brightness of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>sharpness</th><th>Number</th><th>sharpness of display (0~50) </th><th>optional</th></tr>
     *                   <tr><th>hSharpness</th><th>Number</th><th>hSharpness of display (0~50)</th><th>optional</th></tr>
     *       <tr class="odd"><th>vSharpness</th><th>Number</th><th>vSharpness of display (0~50) </th><th>optional</th></tr>
     *                   <tr><th>color</th><th>Number</th><th>color of display (0~100) </th><th>optional</th></tr>
     *       <tr class="odd"><th>tint</th><th>Number</th><th>tint of display (0~100) R:0, G:100</th><th>optional</th></tr>
     *                   <tr><th>colorTemperature</th><th>Number</th><th>colorTemperature of display (0~100) W:0, C:100 </th><th>optional</th></tr>
     *       <tr class="odd"><th>dynamicContrast</th><th>String</th><th>dynamicContrast of display (off/low/medium/high) </th><th>optional</th></tr>
     *                   <tr><th>superResolution</th><th>String</th><th>superResolution of display (off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>colorGamut</th><th>String</th><th>colorGamut of display (wide/standard) </th><th>optional</th></tr>
     *                   <tr><th>dynamicColor</th><th>String</th><th>dynamicColor of display (off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>noiseReduction</th><th>String</th><th>noiseReduction of display (auto/off/low/medium/high) </th><th>optional</th></tr>
     *                   <tr><th>mpegNoiseReduction</th><th>String</th><th>mpegNoiseReduction of display (auto/off/low/medium/high) </th><th>optional</th></tr>
     *       <tr class="odd"><th>blackLevel</th><th>String</th><th>blackLevel of display (low/high) </th><th>optional</th></tr>
     *                   <tr><th>gamma</th><th>String</th><th>gamma of display (low/medium/high) </th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getPictureProperty () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      
     *      console.log("back light : " + cbObject.backlight);
     *      console.log("contrast : " + cbObject.contrast);
     *      console.log("brightness : " + cbObject.brightness);
     *      console.log("color : " + cbObject.color);
     *      console.log("tint : " + cbObject.tint);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getPictureProperty(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Configuration%23setPictureProperty.html">Configuration.setPictureProperty()</a><br>
     */
    Configuration.prototype.getPictureProperty = function (successCallback, errorCallback) {
    
        log("getPictureProperty: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "picture",
                keys : ["brightness", "contrast", "color", "tint", "backlight",
                        "sharpness", "hSharpness", "vSharpness", "colorTemperature",
                        "dynamicContrast", "superResolution", "colorGamut", "dynamicColor",
                        "noiseReduction", "mpegNoiseReduction", "blackLevel", "gamma" ]
            },
            onSuccess : function(result) {
                log("getPictureProperty: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var cbObj = {};
                        
                        for (var key in result.settings) {
                            if (key !== undefined && key !== null) {
                                cbObj[key] = (isNaN(result.settings[key]) ? result.settings[key] : Number(result.settings[key]) );
                                if (key === 'tint' || key === 'colorTemperature') {
                                    cbObj[key] += 50;
                                }
                                else if (key === 'blackLevel') {
                                    cbObj[key] = result.settings[key].unknown;
                                }
                                else if (key === 'gamma' && result.settings[key] === "high1") {
                                    cbObj[key] = "high";
                                }
                            }                            
                        }
                        
                        successCallback(cbObj);
                    }
                }
            },
            onFailure : function(result) {
                log("getPictureProperty: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGPP", "Configuration.getPictureProperty returns failure.");
                    errorCallback(result);
                }
            }
        });
                
        log("Configuration.getPictureProperty Done");
    
    };
    
    var mapTable = {
        "alias" : "signageName"
    };
    
    /**
     * Sets property.
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options string in JSON format. Refer to Configuration.getProperty for available keys of property(e.g. '{"alias":"display_1"}').
     *
     * @example
     * // Javascript code
     * function setProperty () {
     *   var options = '{"alias":"display_1"}';
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.setProperty(successCb, failureCb, options);
     * }
     *
     * @return 
     * <p>If the method is successfully executed, success callback function is called without a parameter.</br> 
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @since 1.0
     */
    Configuration.prototype.setProperty = function (successCallback, errorCallback, options) {
    
        log("setProperty: " + JSON.stringify(options));
        
        var ret    = JSON.parse(options);
        var sets   = {};
        var params = {};

        checkPlatformVersion(function(ver) {
            if (ver === 3) {
                mapTable.alias = "deviceName";
                params.category = "network";
            }
            else
            {
                mapTable.alias = "signageName";
                params.category = "commercial";
            }
            
            for (var key in ret) {
                if (mapTable[key] !== undefined) {
                    sets[(mapTable[key])] = ret[key];
                }
            }

            params.settings = sets;

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method: "set",
                parameters: params,
                onSuccess: function(result) {
                    log("setProperty: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure: function(result) {
                    log("setProperty: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CSP", "Configuration.setProperty returns failure.");
                        errorCallback(result);
                    }
                }
            });
        });

        log("Configuration.setProperty Done");            
    };
    
    /**
     * Gets the property of platform using key. This property can be either platform specific or user set value. 
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options string in JSON. It should have "keys" string in JSON which has an array of keys for the value. For example, '{"keys":["alias","key2"]}' .
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Key</th><th>Description</th><th>Format</th><th>Read/Write</th><th>Example</th></tr></thead>
     *   <tbody>
     *                   <tr><th>alias</th><th>Display alias name</th><th>String</th><th>read/write</th><th>display_1</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
     * @return {Object} String in JSON. For example, '{"alias":"display_1"}'.
     * 
     * @example
     * // Javascript code
     * function getProperty () {
     *   var options = '{"keys":["alias"]}';
     *     
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      var parsedString = JSON.parse(cbObject);
     *
     *      for(var key in parsedString) {
     *         var value = parsedString[key];
     *         console.log(key + ": " + value);
     *      }
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getProperty(successCb, failureCb, options);
     * }
     *
     * @since 1.0
     */
    Configuration.prototype.getProperty = function (successCallback, errorCallback, options) {
    
        log("getProperty: ");
        
        var ret       = JSON.parse(options);
        var keys      = ret.keys;
        var params    = {};
        var arrayKeys = [];

        checkPlatformVersion(function(ver) {
            
            if (ver === 3) {
                mapTable.alias = "deviceName";
                params.category = "network";
            }
            else
            {
                mapTable.alias = "signageName";
                params.category = "commercial";
            }

            for (var key in keys) {
                if (key !== null && key !== undefined) {
                    log("key" + keys[key]);
                    arrayKeys.push(mapTable[keys[key]]);
                }
            }

            params.keys = arrayKeys;

            log(arrayKeys);

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method: "get",
                parameters: params,
                onSuccess: function(result) {
                    log("getProperty: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            var cbObj = {};

                            for (var key in keys) {
                                if (key !== null || key !== undefined) {
                                    log("key" + keys[key]);
                                    if (result.settings[mapTable[keys[key]]] !== undefined || result.settings[mapTable[keys[key]]] !== null) {
                                        cbObj[keys[key]] = result.settings[mapTable[keys[key]]];
                                    }
                                }
                            }
                            successCallback(JSON.stringify(cbObj));

                        }
                    }
                },
                onFailure: function(result) {
                    log("getProperty: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CGP", "Configuration.getProperty returns failure.");
                        errorCallback(result);
                    }
                }
            });
        });

        log("Configuration.getProperty Done");
    };
    
    /**
     * Sets current time.
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>year</th><th>Number</th><th>year (2000~2037)</th><th>required</th></tr>
     *       <tr class="odd"><th>month</th><th>Number</th><th>month (1~12)</th><th>required</th></tr>
     *       <tr><th>day</th><th>Number</th><th>day (1~31)</th><th>required</th></tr>
     *       <tr class="odd"><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr class="odd"><th>sec</th><th>Number</th><th>sec (0~59)</th><th>required</th></tr>
     *       <tr><th>ntp</th><th>Boolean</th><th>NTP(Network Time Protocol) is enabled. If ntp is enabled, other setting values are ignored. true : enabled / false : disabled (default)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function setCurrentTime () {
     *   var options = {
     *      year : 2014,
     *      month : 1,
     *      day : 6,
     *      hour : 14,
     *      minute : 40,
     *      sec : 50
     *   };
     *      
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.setCurrentTime(successCb, failureCb, options);
     * }
     *
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br> 
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @since 1.0
     * @since 1.3 options.ntp
     * @see
     * <a href="Configuration%23getCurrentTime.html">Configuration.getCurrentTime()</a><br>
     */
    Configuration.prototype.setCurrentTime = function (successCallback, errorCallback, options) {
    
        log("setCurrentTime: " + JSON.stringify(options));
        var input = new Date(options.year, options.month-1, options.day, options.hour, options.minute, options.sec);
        
        if (options.year < 2000 || options.year > 2037 || options.month < 1 || options.month > 12 ||
            options.day < 1 || options.day > 31 || options.hour < 0 || options.hour > 23 ||
            options.minute < 0 || options.minute > 59 || options.sec < 0 || options.sec > 59 ||
            input.getFullYear() !== options.year || //for checking leap year (SCAP-221)
            input.getMonth() !== (options.month-1) ||
            input.getDate() !== options.day ||
            input.getHours() !== options.hour ||
            input.getMinutes() !== options.minute ||
            input.getSeconds() !== options.sec)
        {
            
            if (typeof errorCallback === 'function') {
                log("setCurrentTime: out of range or invalid parameter type");
                var result = {};
                checkErrorCodeNText(result, "CSCT", "Configuration.setCurrentTime returns failure for out of range.");
                errorCallback(result);
                return;
            }
        }
        
        log("setCurrentTime: " + JSON.stringify(options));
        
        //var utcSec = input.getTime()/1000; //removed timezone offset. it will calculate in storage service        

        var time    = {};
        time.year   = options.year;
        time.month  = options.month;
        time.day    = options.day;
        time.hour   = options.hour;
        time.minute = options.minute;
        time.sec    = options.sec;

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "setSystemTime",
                parameters : {
                    time : time,
                    ntp : options.ntp
                },
                onSuccess : function() {
                    log("setCurrentTime: On Success");
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                },
                onFailure : function(result) {
                    log("setCurrentTime: On Failure");
                    
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CSCT", "Configuration.setCurrentTime returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Configuration.setCurrentTime Done");
            
    };
    
    /**
     * Gets current time.
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>year</th><th>Number</th><th>year (2000~2037)</th><th>required</th></tr>
     *       <tr class="odd"><th>month</th><th>Number</th><th>month (1~12)</th><th>required</th></tr>
     *       <tr><th>day</th><th>Number</th><th>day (1~31)</th><th>required</th></tr>
     *       <tr class="odd"><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr class="odd"><th>sec</th><th>Number</th><th>sec (0~59)</th><th>required</th></tr>
     *       <tr><th>ntp</th><th>Boolean</th><th>NTP(Network Time Protocol) is enabled. true : enabled / false : disabled (default)</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getCurrentTime () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getCurrentTime(successCb, failureCb);
     * }
     *
     * @since 1.0
     * @since 1.3 returns.ntp
     * @see
     * <a href="Configuration%23setCurrentTime.html">Configuration.setCurrentTime()</a><br>
     */
    Configuration.prototype.getCurrentTime = function (successCallback, errorCallback) {
    
        log("getCurrentTime: ");
        
        service.Request("luna://com.palm.systemservice/time/", {
            method : "getEffectiveBroadcastTime",
            onSuccess : function(result) {
                log("getCurrentTime : On Success");
                
                if(result.returnValue === true) {
                    var cbObj = {};
                    var d = new Date(result.adjustedUtc * 1000);
                    cbObj.year = d.getFullYear();
                    cbObj.month = d.getMonth() + 1;
                    cbObj.day = d.getDate();
                    cbObj.hour = d.getHours();
                    cbObj.minute = d.getMinutes();
                    cbObj.sec = d.getSeconds();
                    
                    service.Request("luna://com.palm.systemservice/", {
                        method : "getPreferences",
                        parameters : {
                            keys : ["useNetworkTime"]
                        },
                        onSuccess : function(res) {
                            log("getPreferences : On Success");
                            
                            if(res.returnValue === true) {
                                
                                cbObj.ntp = res.useNetworkTime;
                                
                                if (typeof successCallback === 'function') {
                                    successCallback(cbObj);
                                }
                                
                            } else {
                                
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "CGCT", "Configuration.getCurrentTime returns failure.");
                                    errorCallback(result);
                                }
                            }
                        },
                        onFailure : function(result) {
                            log("getCurrentTime: On Failure");
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "CGCT", "Configuration.getCurrentTime returns failure.");
                                errorCallback(result);
                            }
                        }
                    });
                } else {
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CGCT", "Configuration.getCurrentTime returns failure.");
                        errorCallback(result);
                    }
                }
                
            },
            onFailure : function(result) {
                log("getCurrentTime: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGCT", "Configuration.getCurrentTime returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.getCurrentTime Done");

    };
    
    /**
     * Restarts the application. 
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     *
     * @example
     * // Javascript code
     * function restartApplication () {
     *   function successCb() {
     *      console.log("restart success : ");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.restartApplication(successCb, failureCb);
     * }
     *
     * @since 1.0
     */
    Configuration.prototype.restartApplication = function (successCallback, errorCallback) {
    
        log("restartApp: ");
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
                method : "restart_application",
                onSuccess : function(result) {
                    log("restartApp: On Success");
                    
                    if (typeof successCallback === 'function') {
                        successCallback(result);
                    }
                },
                onFailure : function(result) {
                    log("restartApp: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CRA", "Configuration.restartApp returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Configuration.restartApp Done");
    
    };
    
    
    /**
     * Gets server property. Server property has information about application mode and server settings for application upgrade and launch. 
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *                   <tr><th>serverIp</th><th>String</th><th>IP address (local, usb : to upgrade / remote : to launch )</th></tr>
     *       <tr class="odd"><th>serverPort</th><th>Number</th><th>Port number (local, usb : to upgrade / remote : to launch )</th></tr>
     *                   <tr><th>secureConnection</th><th>Boolean</th><th>true : https, false : http </th></tr>
     *       <tr class="odd"><th>appLaunchMode</th><th>String</th><th>launch mode <a href="Configuration.AppMode.html#constructor">Configuration.AppMode</th></tr>
     *                   <tr><th>fqdnMode</th><th>Boolean</th><th>true : use fqdn settings for application upgrade or launch, <br>false : use serverIp and serverPort settings for application upgrade or launch</th></tr>
     *       <tr class="odd"><th>fqdnAddr</th><th>String</th><th>FQDN url. for example, http://lge.com/index.html or https://lge.com/index.html </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getServerProperty () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("server IP : " + cbObject.serverIp);
     *      console.log("server Port : " + cbObject.serverPort);
     *      console.log("secure Connection : " + cbObject.secureConnection);
     *      console.log("applicationLaunchMode : " + cbObject.appLaunchMode);
     *      console.log("fully Qualified Domain Name Mode : " + cbObject.fqdnMode);
     *      console.log("fully Qualified Domain Name Address: " + cbObject.fqdnAddr);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getServerProperty(successCb, failureCb);
     * }
     * @since 1.1
     * @see
     * <a href="Configuration%23setServerProperty.html">Configuration.setServerProperty()</a><br>
     */
    Configuration.prototype.getServerProperty = function (successCallback, errorCallback) {
    
        log("getServerProperty: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["serverIpPort", "siServerIp", "secureConnection", "appLaunchMode", "fqdnAddr", "fqdnMode"]
            },
            
            onSuccess : function(result) {
                log("getPictureProperty: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var cbObj = {};
                        cbObj.serverIp = result.settings.siServerIp;
                        cbObj.serverPort = parseInt(result.settings.serverIpPort, 10);
                        cbObj.secureConnection = (result.settings.secureConnection === "off" ? false : true );
                        cbObj.appLaunchMode  = result.settings.appLaunchMode;
                        cbObj.fqdnMode = (result.settings.fqdnMode === "off" ? false : true );
                        cbObj.fqdnAddr = result.settings.fqdnAddr;
                        
                        successCallback(cbObj);
                    }
                }
            },
            onFailure : function(result) {
                log("getServerProperty: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGSP", "Configuration.getServerProperty returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.getServerProperty Done");
    
    };
    
    /**
     * Sets the server property.
     * <br>
     * <hr>
     * <b>scap_installation.json</b><br>
     * If scap_installation.json file exists under root directory of usb memory and 'Auto Set' is enabled in server settings menu, 
     * server properties will be set as described in scap_installation.json and 'Auto Set' will be disabled automatically.
     * Factory default setting of 'Auto Set' is 'enabled'.</br>
     * scap_installation.json schema is as below.
     *       
     * <div><pre class="code prettyprint">     
{
  "$schema": "http://json-schema.org/draft-04/schema#",
  "id": "",
  "type": "object",
  "properties": {
    "serverIp": {
      "id": "serverIp",
      "type": "string"
    },
    "serverPort": {
      "id": "serverPort",
      "type": "integer"
    },
    "secureConnection": {
      "id": "secureConnection",
      "type": "boolean"
    },
    "appLaunchMode": {
      "id": "appLaunchMode",
      "type": "string",
      "enum": [
        "local",
        "usb",
        "remote"
      ]
    },
    "fqdnMode": {
      "id": "fqdnMode",
      "type": "boolean"
    },
    "fqdnAddr": {
      "id": "fqdnAddr",
      "type": "string"
    },
    "required": [
      "serverIp",
      "serverPort",
      "secureConnection",
      "appLaunchMode",
      "fqdnMode",
      "fqdnAddr"
    ]
  }
}
     * </pre></div>
     * scap_installation.json example is as below. <br>
     *  {<br>
     *    "serverIp":"10.177.211.51", <br>
     *    "serverPort":80, <br>
     *    "secureConnection":false, <br>
     *    "appLaunchMode":"local",<br>
     *    "fqdnMode":true,<br>
     *    "fqdnAddr":"http://192.168.0.1:2000/lgapp.zip"<br>
     *  }<br>
     * <hr>
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *                   <tr><th>serverIp</th><th>String</th><th>IP address (local, usb : to upgrade / remote : to launch )</th><th>required</th></tr>
     *       <tr class="odd"><th>serverPort</th><th>Number</th><th>Port number (local, usb : to upgrade / remote : to launch )</th><th>required</th></tr>
     *                   <tr><th>secureConnection</th><th>Boolean</th><th>true : https, false : http </th><th>required</th></tr>
     *       <tr class="odd"><th>appLaunchMode</th><th>String</th><th>launch mode <a href="Configuration.AppMode.html#constructor">Configuration.AppMode</th><th>required</th></tr>
     *                   <tr><th>fqdnMode</th><th>Boolean</th><th>true : use fqdn settings when an application upgrades or launches, 
     *                   <br>false : use serverIp and serverPort settings when an application upgrades or launches</th><th>required</th></tr>
     *       <tr class="odd"><th>fqdnAddr</th><th>String</th><th>FQDN url. for example, http://lge.com/index.html or https://lge.com/index.html </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *    
     * @example
     * // Javascript code
     * function setServerProperty () {
     *   var options = {
     *      serverIp : "192.168.0.2",
     *      serverPort : 80,
     *      secureConnection : false,
     *      appLaunchMode : Configuration.AppMode.REMOTE,     
     *      fqdnMode : false,
     *      fqdnAddr : "http://signage.domain.com/index.html"
     *   };
     *      
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.setServerProperty(successCb, failureCb, options);
     * }
     * @since 1.1
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br> 
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @see
     * <a href="Configuration%23getServerProperty.html">Configuration.getServerProperty()</a><br>
     */
    Configuration.prototype.setServerProperty = function (successCallback, errorCallback, options) {
    
        log("setServerProperty: " + JSON.stringify(options));
        
        
        if(options === undefined || 
                typeof options.serverIp !== 'string'|| /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(options.serverIp) === false ||
                isNaN(options.serverPort) || options.serverPort < 0 || options.serverPort > 65535 || typeof options.serverPort !== 'number' ||
                typeof options.secureConnection !== 'boolean' || typeof options.appLaunchMode !== 'string' ||
                (options.appLaunchMode !== Configuration.AppMode.USB && options.appLaunchMode !== Configuration.AppMode.LOCAL && options.appLaunchMode !== Configuration.AppMode.REMOTE) || 
                typeof options.fqdnMode !== 'boolean' || typeof options.fqdnAddr !== 'string') {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "CSSP", "Configuration.setServerProperty, Invalid parameters.");
                log ("options.serverIp : " + typeof options.serverIp + " options.serverPort : " + typeof options.serverPort + " options.secureConnection : " + typeof options.secureConnection + 
                        " options.appLaunchMode : " + typeof options.appLaunchMode + " options.fqdnMode : " + typeof options.fqdnMode + " options.fqdnAddr : " + options.fqdnAddr);
                
                errorCallback(result);
                return;
            }
            
        }
        
        var sets = {};
        
        sets.siServerIp = options.serverIp;
        sets.serverIpPort = options.serverPort + '';
        sets.secureConnection = ( options.secureConnection === true ? "on" : "off");
        sets.appLaunchMode = options.appLaunchMode;
        sets.fqdnMode = ( options.fqdnMode === true ? "on" : "off" );
        sets.fqdnAddr = options.fqdnAddr;
        
        log(JSON.stringify(sets));
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : sets
            },
            onSuccess : function(result) {
                log("setServerProperty: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setServerProperty: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSSP", "Configuration.setServerProperty returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.setServerProperty Done");
    };
    
    /**
     * Clears the cache data on signage monitor. 
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     *
     * @example
     * // Javascript code
     * function clearCache () {
     *   function successCb() {
     *      console.log("clearCache success : ");
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.clearCache(successCb, failureCb);
     * }
     *
     * @since 1.3
     */
    Configuration.prototype.clearCache = function (successCallback, errorCallback) {
    
        log("clearCache: ");
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
                method : "clearCache",
                onSuccess : function(result) {
                    log("clearCache: On Success");
                    
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                },
                onFailure : function(result) {
                    log("clearCache: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CCC", "Configuration.clearCache returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Configuration.clearCache Done");
    
    };
    
    /**
     * Gets list of time zone supported on signage monitor.
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>timeZone[]</th><th>Array</th><th> </th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone[].continent</th><th>String</th><th>continent</th><th>required</th></tr>
     *                   <tr><th>timeZone[].country</th><th>String</th><th>country</th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone[].city</th><th>String</th><th>city</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getTimeZoneList () {
     *   function successCb(cbObject) {
     *      
     *      for (var i = cbObject.timeZone.length-1; i>=0; i--) {
     *          console.log("timeZone [" + i + "].continent : " + cbObject.timeZone[i].continent);
     *          console.log("timeZone [" + i + "].country : " + cbObject.timeZone[i].country);
     *          console.log("timeZone [" + i + "].city : " + cbObject.timeZone[i].city);
     *                
     *      }
     *
     *      // Do something
     *      
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getTimeZoneList(successCb, failureCb);
     * }
     * @since 1.3
     * @see
     * <a href="Configuration%23setTimeZone.html">Configuration.setTimeZone()</a><br>
     * <a href="Configuration%23getTimeZone.html">Configuration.getTimeZone()</a><br>
     */
    Configuration.prototype.getTimeZoneList = function (successCallback, errorCallback) {
    
        log("getTimeZoneList: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "getTimeZoneList",
            onSuccess : function(result) {
                log("getTimeZoneList: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        delete result.returnValue;
                        successCallback(result);
                    }
                }
            },
            onFailure : function(result) {
                log("getTimeZoneList: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGTL", "Configuration.getTimeZoneList returns failure.");
                    errorCallback(result);
                }
            }
        });
                
        log("Configuration.getTimeZoneList Done");
    
    };
    
    /**
     * Gets time zone.
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>timeZone</th><th>Object</th><th> </th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone.continent</th><th>String</th><th>continent</th><th>required</th></tr>
     *                   <tr><th>timeZone.country</th><th>String</th><th>country</th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone.city</th><th>String</th><th>city</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getTimeZone () {
     *   function successCb(cbObject) {
     *      
     *      console.log("timeZone.continent : " + cbObject.timeZone.continent);
     *      console.log("timeZone.country : " + cbObject.timeZone.country);
     *      console.log("timeZone.city : " + cbObject.timeZone.city);
     *      
     *
     *      // Do something
     *      
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   configuration.getTimeZone(successCb, failureCb);
     * }
     * @since 1.3
     * @see
     * <a href="Configuration%23setTimeZone.html">Configuration.setTimeZone()</a><br>
     * <a href="Configuration%23getTimeZoneList.html">Configuration.getTimeZoneList()</a><br>
     */
    Configuration.prototype.getTimeZone = function (successCallback, errorCallback) {
    
        log("getTimeZone: ");
    
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "getTimeZone",
            onSuccess : function(result) {
                log("getTimeZone: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        delete result.returnValue;
                        successCallback(result);
                    }
                }
            },
            onFailure : function(result) {
                log("getTimeZone: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGTZ", "Configuration.getTimeZone returns failure.");
                    errorCallback(result);
                }
            }
        });
                
        log("Configuration.getTimeZone Done");
    
    };
    
    
    /**
     * Sets time zone which should be one of the list from getTimeZoneList.
     *
     * @class Configuration
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>timeZone</th><th>Object</th><th> </th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone.continent</th><th>String</th><th>continent</th><th>required</th></tr>
     *                   <tr><th>timeZone.country</th><th>String</th><th>country</th><th>required</th></tr>
     *       <tr class="odd"><th>timeZone.city</th><th>String</th><th>city</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
     * @example
     * // Javascript code
     * function setTimeZone () {
     *   function successCb(cbObject) {
     *      
     *      // Do something
     *      
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var configuration = new Configuration();
     *   var timeZone = {
     *       continent : "Asia",
     *       country : "South Korea",
     *       city : "Seoul"
     *   };
     *   var options = { timeZone : timeZone };
     *   
     *   configuration.setTimeZone(successCb, failureCb, options);
     * }
     * 
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br> 
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * 
     * @since 1.3
     * @see
     * <a href="Configuration%23getTimeZone.html">Configuration.getTimeZone()</a><br>
     * <a href="Configuration%23getTimeZoneList.html">Configuration.getTimeZoneList()</a><br>
     */
    Configuration.prototype.setTimeZone = function (successCallback, errorCallback, options) {
    
        log("setTimeZone: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "time",
                keys : ["autoClock"]
            },
            onSuccess : function(result) {                
                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') { 
                        if(result.settings.autoClock === "off") {
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "CSTZ", "Configuration.setTimeZone returns failure. autoClock is off");
                                errorCallback(result);
                            }
                        } else {
                            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                                method: "setTimeZone",
                                parameters: options,
                                onSuccess: function(result) {
                                    log("setTimeZone: On Success");
                                    if (result.returnValue === true) {
                                        if (typeof successCallback === 'function') {
                                            delete result.returnValue;
                                            successCallback(result);
                                        }
                                    }
                                },
                                onFailure: function(result) {
                                    log("setTimeZone: On Failure");
                                    delete result.returnValue;
                                    if (typeof errorCallback === 'function') {
                                        checkErrorCodeNText(result, "CSTZ", "Configuration.setTimeZone returns failure.");
                                        errorCallback(result);
                                    }
                                }
                            });
                        }                        
                    }
                }
            },
            onFailure : function(result) {
                log("setTimeZone: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSTZ", "Configuration.setTimeZone returns failure.");
                    errorCallback(result);
                }
            }
        });
                
        log("Configuration.setTimeZone Done");
    
    };
    
    // hidden for debug
    Configuration.prototype.debug = function (successCallback, errorCallback, options) {
    
    // options.enabled = true / false;
    
    log("debug: " + options.enabled);
    
    service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
            method : "debug",
            parameters : {
                    enabled : options.enabled
                },
            onSuccess : function(result) {
                log("debug: On Success");
                
                if (typeof successCallback === 'function') {
                    successCallback(result);
                }
            },
            onFailure : function(result) {
                log("debug: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CD", "Configuration.debug returns failure.");
                    errorCallback(result);
                }
            }
        });
    
        log("Configuration.debug Done");
    
    };

    Configuration.prototype.setUSBLock = function (successCallback, errorCallback, options) {        
        log("setUSBLock: " + options.enabled);
        
        if (options.enabled === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "CSUL", "Configuration.setUSBLock returns failure. command was not defined.");
            errorCallback(result);
            log("Configuration.setUSBLock invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",        
                settings : {
                    "enableUsb" : (options.enabled === true ) ? "off" : "on" 
                }
            },
            onSuccess : function(result) {
                log("setUSBLock: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setUSBLock: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSUL", "Configuration.setUSBLock returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.setUSBLock Done");
    };

    Configuration.prototype.getUSBLock = function (successCallback, errorCallback) {
        
        log("getUSBLock: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["enableUsb"]
            },
            onSuccess: function(result) {
                log("getUSBLock: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    cbObj.enabled = (result.settings.enableUsb === "off") ? true : false;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getUSBLock: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGUL", "Configuration.getUSBLock returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Configuration.getUSBLock Done");
    };

    Configuration.prototype.setOSDLock = function (successCallback, errorCallback, options) {        
        log("setOSDLock: " + options.enabled);
        
        if (options.enabled === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLock returns failure. command was not defined.");
            errorCallback(result);
            log("Configuration.setOSDLock invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "hotelMode",
                notifySelf : false,        
                settings : {
                    "enableMrcu" : (options.enabled === true ) ? "off" : "on",
                    "enableOsdVisibility" : (options.enabled === true ) ? "off" : "on"
                }
            },
            onSuccess : function(result) {
                log("setOSDLock: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setOSDLock: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLock returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Configuration.setOSDLock Done");
    };

    Configuration.prototype.getOSDLock = function (successCallback, errorCallback) {
        
        log("getOSDLock: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "hotelMode",
                keys: ["enableMrcu", "enableOsdVisibility"]
            },
            onSuccess: function(result) {
                log("getOSDLock: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    cbObj.enabled = (result.settings.enableMrcu === "on" && result.settings.enableOsdVisibility === "on") ? false : true;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getOSDLock: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGOL", "Configuration.getOSDLock returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Configuration.getOSDLock Done");
    };

    Configuration.prototype.getLocaleList = function (successCallback, errorCallback) {
        
        log("getLocaleList: ");

        //it will get localelist from system after SCAP v1.5
        var cbObj = {};
        cbObj.localeList = Configuration.LocaleList;

        if (typeof successCallback === 'function') {
            successCallback(cbObj);
        }
        
        log("Configuration.getLocaleList Done");
    };

    Configuration.prototype.setOSDLanguage = function (successCallback, errorCallback, options) {       
        log("setOSDLanguage: " + options.specifier);
        
        if ((options.specifier === null || typeof options.specifier !== 'string') && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLanguage returns failure. command was not defined.");
            errorCallback(result);
            log("Configuration.setOSDLanguage invalid ");
            return;
        }  

        if (isValidSpecifier(options.specifier) === true) {            
            log("Specifier is valid");

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method: "get",
                parameters: {
                    keys: ["localeInfo"]
                },
                onSuccess: function(result) {                    
                    if (result.returnValue === true) {
                        var localeInfo = {};
                        localeInfo             = result.settings.localeInfo;
                        localeInfo.locales.UI  = options.specifier;
                        localeInfo.locales.FMT = options.specifier;
                        localeInfo.locales.TV  = options.specifier;
                        
                        log("localeInfo : " + JSON.stringify(localeInfo));

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                settings: {
                                    localeInfo: localeInfo
                                }
                            },
                            onSuccess: function(result) {
                                log("setOSDLanguage: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("setOSDLanguage: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLanguage returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });                
                    }
                },
                onFailure: function(result) {                    
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLanguage returns failure.");
                        errorCallback(result);
                    }
                }
            });            
        }else {
            var result = {};
            checkErrorCodeNText(result, "CSOL", "Configuration.setOSDLanguage returns failure. specifier is not valid.");
            errorCallback(result);
            log("Configuration.setOSDLanguage invalid ");
            return;
        }
                
        log("Configuration.setOSDLanguage Done");
    };

    Configuration.prototype.getOSDLanguage = function (successCallback, errorCallback) {
        
        log("getOSDLanguage: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {                
                keys: ["localeInfo"]
            },
            onSuccess: function(result) {
                log("getOSDLanguage: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    log("localeInfo : " + JSON.stringify(result.settings.localeInfo));
                    cbObj.specifier = result.settings.localeInfo.locales.UI;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getOSDLanguage: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGOL", "Configuration.getOSDLanguage returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Configuration.getOSDLanguage Done");
    };

    Configuration.prototype.setVirtualKeyboardLanguage = function (successCallback, errorCallback, options) {       
        log("setVirtualKeyboardLanguage: " + options.languageCodeList);
        
        if (options.languageCodeList === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "CSKL", "Configuration.setVirtualKeyboardLanguage returns failure. command was not defined.");
            errorCallback(result);
            log("Configuration.setVirtualKeyboardLanguage invalid ");
            return;
        }

        for(var i=0; i<options.languageCodeList.length; i++){
            if(isValidLanguageCode(options.languageCodeList[i]) === false) {
                var result = {};
                checkErrorCodeNText(result, "CSKL", "Configuration.setVirtualKeyboardLanguage returns failure. language code is not valid.");
                errorCallback(result);
                log("Configuration.setVirtualKeyboardLanguage invalid ");
                return;
            }
        }

        log("languageCodeList is valid");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                keys: ["localeInfo"]
            },
            onSuccess: function(result) {
                if (result.returnValue === true) {
                    var localeInfo = result.settings.localeInfo;

                    localeInfo.keyboards = [];

                    //pushed when "en" does not exist in params
                    if (options.languageCodeList.indexOf("en") === -1) {
                        localeInfo.keyboards.push("en"); //"en" is mandatory
                    }

                    for (var i = 0; i < options.languageCodeList.length; i++) {
                        localeInfo.keyboards.push(options.languageCodeList[i]);
                    }

                    log("localeInfo : " + JSON.stringify(localeInfo));

                    service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                        method: "set",
                        parameters: {
                            settings: {
                                localeInfo: localeInfo
                            }
                        },
                        onSuccess: function(result) {
                            log("setVirtualKeyboardLanguage: On Success");

                            if (result.returnValue === true) {
                                if (typeof successCallback === 'function') {
                                    successCallback();
                                }
                            }
                        },
                        onFailure: function(result) {
                            log("setVirtualKeyboardLanguage: On Failure");
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "CSKL", "Configuration.setVirtualKeyboardLanguage returns failure.");
                                errorCallback(result);
                            }
                        }
                    });
                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CSKL", "Configuration.setVirtualKeyboardLanguage returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Configuration.setVirtualKeyboardLanguage Done");
    };

    Configuration.prototype.getVirtualKeyboardLanguage = function (successCallback, errorCallback) {
        
        log("getVirtualKeyboardLanguage: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {                
                keys: ["localeInfo"]
            },
            onSuccess: function(result) {
                log("getVirtualKeyboardLanguage: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    log("localeInfo.keyboards : " + JSON.stringify(result.settings.localeInfo.keyboards));
                    cbObj.languageCodeList = result.settings.localeInfo.keyboards;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getVirtualKeyboardLanguage: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "CGKL", "Configuration.getVirtualKeyboardLanguage returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Configuration.getVirtualKeyboardLanguage Done");
    };

    module.exports = Configuration;
});

Configuration = cordova.require('cordova/plugin/configuration'); // jshint ignore:line

