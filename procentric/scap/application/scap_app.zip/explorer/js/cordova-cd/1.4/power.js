/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the power API itself, and provides a global namespace for operating power service.
 * @class
 */
cordova.define('cordova/plugin/power', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if(window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
               log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
               if (typeof params.onFailure === 'function') {
                  params.onFailure({ returnValue:false,
                     errorText:"PalmSystem Not Available. Cordova is not installed?"});
               }
        }};
    }

    /**
     * power interface
     */
    var Power = function () {
    };
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }
    
    /**
     * 160125 iamjunyoug.park : checkPlatformVersion now return chipset
     *                          such as M14, LM15U, H15, etc.
     */
    var version = null;
    var platformInfoObj = {}; 
    function checkPlatformVersion(cb) {
        
        if (version === null) {
            
            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);
                    
                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer : 1,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer : 2,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer : 3,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer : 0,
                            chipset : ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    
                    delete result.returnValue;
                    
                    cb(platformInfoObj);
                    
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    delete error.returnValue;
                    platformInfoObj = {
                        webOSVer : 0,
                        chipset : ""
                    }
                    
                    cb(platformInfoObj);
                }
            });
            
        } else {
            cb(platformInfoObj);
        }
    }
    
    /**
     * 160125 iamjunyoung.park : Add H15 case
     */
    function convertExternal(extStr) {
        if (platformInfoObj.chipset == 'H15') {
            switch (extStr) { // H15 only
                case "ext://hdmi:1":
                    return "HDMI1";
                case "ext://hdmi:2":
                    return "HDMI2";
                case "ext://hdmi:3":
                    return "OPS/HDMI3/DVI";
                case "ext://dvi:1":
                    return "OPS/HDMI3/DVI";
                case "ext://dp:1":
                    return "DISPLAYPORT";
                case "ext://rgb:1":
                    return "RGB";
                case "ext://ops:1":
                    return "OPS/HDMI3/DVI";
                    
                case "HDMI1":
                    return "ext://hdmi:1";
                /*
                case "HDMI": // Not used
                    return "ext://hdmi:1";
                */
                case "HDMI2":
                    return "ext://hdmi:2";
                case "HDMI3":
                    return "ext://hdmi:3";
                case "DVI":
                    return "ext://dvi:1";
                case "DISPLAYPORT":
                    return "ext://dp:1";
                case "RGB":
                    return "ext://rgb:1";
                case "OPS":
                    return "ext://ops:1";
                case "OPS/HDMI3/DVI":
                    return "ext://hdmi:3"
            }
        }
        else { // M14 and LM15U
            switch (extStr) {
                case "ext://hdmi:1":
                    if (platformInfoObj.webOSVer === 1)
                        return "HDMI1";
                    else 
                        return "HDMI";
                case "ext://hdmi:2":
                    return "HDMI2";
                case "ext://hdmi:3":
                    return "HDMI3";
                case "ext://dvi:1":
                    return "DVI";
                case "ext://dp:1":
                    return "DISPLAYPORT";
                case "ext://rgb:1":
                    return "RGB";
                case "ext://ops:1":
                    return "OPS";
                    
                case "HDMI1":
                    return "ext://hdmi:1";
                case "HDMI":
                    return "ext://hdmi:1";
                case "HDMI2":
                    return "ext://hdmi:2";
                case "HDMI3":
                    return "ext://hdmi:3";
                case "DVI":
                    return "ext://dvi:1";
                case "DISPLAYPORT":
                    return "ext://dp:1";
                case "RGB":
                    return "ext://rgb:1";
                case "OPS":
                    return "ext://ops:1";
                case "OPS/HDMI3/DVI":
                    return "ext://hdmi:3"
            }
        }
        return null;
    }
    
    /*
    function convertWeekToStr(week) {
        
        var str = "";
        week *= 1;
        
        if ( (week & Power.TimerWeek.EVERYDAY) === Power.TimerWeek.EVERYDAY ) { // jshint ignore:line
            return "Everyday";
        }
        if ( (week & Power.TimerWeek.MONDAY) === Power.TimerWeek.MONDAY ) { // jshint ignore:line
            str += "Mon ";
            week -= Power.TimerWeek.MONDAY;
        }
        if ( (week & Power.TimerWeek.TUESDAY) === Power.TimerWeek.TUESDAY ) { // jshint ignore:line
            str += "Tue ";
            week -= Power.TimerWeek.TUESDAY;
        }
        if ( (week & Power.TimerWeek.WEDNESDAY) === Power.TimerWeek.WEDNESDAY ) { // jshint ignore:line
            str += "Wed ";
            week -= Power.TimerWeek.WEDNESDAY;
        }
        if ( (week & Power.TimerWeek.THURSDAY) === Power.TimerWeek.THURSDAY ) { // jshint ignore:line
            str += "Thu ";
            week -= Power.TimerWeek.THURSDAY;
        }
        if ( (week & Power.TimerWeek.FRIDAY) === Power.TimerWeek.FRIDAY ) { // jshint ignore:line
            str += "Fri ";
            week -= Power.TimerWeek.FRIDAY;
        }
        if ( (week & Power.TimerWeek.SATURDAY) === Power.TimerWeek.SATURDAY ) { // jshint ignore:line
            str += "Sat ";
            week -= Power.TimerWeek.SATURDAY;
        }
        if ( (week & Power.TimerWeek.SUNDAY) === Power.TimerWeek.SUNDAY ) { // jshint ignore:line
            str += "Sun ";
            week -= Power.TimerWeek.SUNDAY;
        }
        
        if (str === "")  {
            str = "None";
        }


        return str;
    }
    */
    
    
    /*
    function padZero(num, size) {
        var s = num+"";
        while (s.length < size) s = "0" + s;
        return s;
    }
    */
    
    /**
     * @namespace Power.PowerMode
     */
    Power.PowerCommand = {
    /**
     * shutdown
     * @since 1.0
     * @constant
     */
    SHUTDOWN : "powerOff",
    /**
     * reboot
     * @since 1.0
     * @constant
     */
    REBOOT : "reboot"
    };
    
    /**
     * @namespace Power.DisplayMode
     */
    Power.DisplayMode = {
    /**
     * display off
     * @since 1.0
     * @constant
     */
    DISPLAY_OFF : "Screen Off",
    /**
     * display on
     * @since 1.0
     * @constant
     */
    DISPLAY_ON : "Active"
    };
    
    /**
     * @namespace Power.TimerWeek
     */
    Power.TimerWeek = {
    /**
     * Monday
     * @since 1.0
     * @constant
     */
    MONDAY : 1,
    /**
     * Tuesday
     * @since 1.0
     * @constant
     */
    TUESDAY : 2,
    /**
     * Wednesday
     * @since 1.0
     * @constant
     */
    WEDNESDAY : 4,
    /**
     * Thursday
     * @since 1.0
     * @constant
     */
    THURSDAY : 8,
    /**
     * Friday
     * @since 1.0
     * @constant
     */
    FRIDAY : 16,
    /**
     * Saturday
     * @since 1.0
     * @constant
     */
    SATURDAY : 32,
    /**
     * Sunday
     * @since 1.0
     * @constant
     */
    SUNDAY : 64,
    /**
     * Everyday
     * @since 1.0
     * @constant
     */
    EVERYDAY : 127
    };

    /**
     * @namespace Power.dpmSignalType
     */
    Power.dpmSignalType = {
    /**
     * CLOCK
     * @since 1.0
     * @constant
     */
    CLOCK : "clock",
    /**
     * CLOCK_WITH_DATA
     * @since 1.0
     * @constant
     */
    CLOCK_WITH_DATA : "clockAndData"
    };

	 /**
     * @namespace Power.PMMode
     */
    Power.PMMode = {
    PowerOff : "powerOff",
    SustainAspectRatio : "sustainAspectRatio",
    ScreenOff : "screenOff",
    ScreenOffAlways : "screenOffAlways"
    };
    
    /**
     * Gets power status 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return <p>{Object} </p>
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>wakeOnLan</th><th>Boolean</th><th>true : enabled / false : disabled </th></tr>
     *       <tr class="odd"><th>displayMode</th><th>String</th><th><a href="Power.DisplayMode.html#.DISPLAY_ON">Power.DisplayMode.DISPLAY_ON</a> | <a href="Power.DisplayMode.html#.DISPLAY_OFF">Power.DisplayMode.DISPLAY_OFF</a> </th></tr>
     *       <tr><th>allOnTimer</th><th>Boolean</th><th>true : enabled / false : disabled </th></tr>
     *       <tr class="odd"><th>allOffTimer</th><th>Boolean</th><th>true : enabled / false : disabled </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getPowerStatus () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("wakeOnLan : " + cbObject.wakeOnLan);
     *      console.log("displayMode : " + cbObject.displayMode);
     *      console.log("allOnTimer : " + cbObject.allOnTimer);
     *      console.log("allOffTimer : " + cbObject.allOffTimer);         
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.getPowerStatus(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23setWakeOnLan.html">Power.setWakeOnLan()</a>, 
     * <a href="Power%23setDisplayMode.html">Power.setDisplayMode()</a><br>
     */
    Power.prototype.getPowerStatus = function (successCallback, errorCallback) {
         
        log("getPowerStatus: ");
        
        /*
        service.Request("luna://com.webos.service.tvpower/power/", {
        */
        service.Request("luna://com.webos.service.tv.signage/", {
            method : "getPowerState",
                onSuccess : function(result) {
                    log("getPowerStatus: On Success");
                    var cbObj = {};
                    
                    if(result.returnValue === true) {
                        cbObj.displayMode = result.state;
                    }
                    
                    service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                        method : "get",
                        parameters : {
                            category : "commercial",
                            keys : ["wolEnable"]
                        },
                        onSuccess : function(result) {
                            log("getPowerStatus: On Success 2");
                            
                            if(result.returnValue === true) {
                                cbObj.wakeOnLan = (result.settings.wolEnable === "1" ? true : false );
                            }
                            
                            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                                method : "get",
                                parameters : {
                                    category : "time",
                                    keys : ["onTimerEnable", "offTimerEnable"]
                                },
                                onSuccess : function(result) {
                                    log("getPowerStatus: On Success 3");
                                    
                                    if(result.returnValue === true) {
                                        cbObj.allOnTimer = (result.settings.onTimerEnable === "on" ? true : false );
                                        cbObj.allOffTimer = (result.settings.offTimerEnable === "on" ? true : false );
                                    
                                        if(typeof successCallback === 'function') {
                                            successCallback(cbObj);
                                        }
                                    }
                                },
                                onFailure : function(result) {
                                    log("getPowerStatus: On Failure 3");
                                    delete result.returnValue;
                                    if(typeof errorCallback === 'function') {
                                        checkErrorCodeNText(result, "PGPS", "Power.getPowerStatus returns failure.");
                                        errorCallback(result);
                                    }
                                }
                            });
                        },
                        onFailure : function(result) {
                            log("getPowerStatus: On Failure 2");
                            delete result.returnValue;
                            if(typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "PGPS", "Power.getPowerStatus returns failure.");
                                errorCallback(result);
                            }
                        }
                    });
                },
                onFailure : function(result) {
                    log("getPowerStatus: On Failure");
                    delete result.returnValue;
                    //TODO; Is this an error case?
                    if(typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PGPS", "Power.getPowerStatus returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.getPowerStatus Done");
        
    };
    
    /**
     * Controls all "on timer". This API enables/disables all "on timer" at once. Values of each "on timer" which was set by Power.addOnTimer() are not changed when option.clearOnTimer is false.
     * 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>allOnTimer</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *       <tr class="odd"><th>clearOnTimer</th><th>Boolean</th><th>true : removes all "on Timer" / false : do nothing. (default) </th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function enableAllOnTimer () {
     *   var options = {
     *      allOnTimer : true
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.enableAllOnTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @since 1.3 optons.clearOnTimer
     * @see
     * <a href="Power%23getPowerStatus.html">Power.getPowerStatus()</a><br>
     */
    Power.prototype.enableAllOnTimer = function (successCallback, errorCallback, options) {
    
        log("enableAllOnTimer: " + JSON.stringify(options));
        
        var op = null;
        switch(options.allOnTimer) {
            case true :
                op = "on";
                break;
            case false :
                op = "off";
                break;
            // 160127 iamjunyoung.park : Add exception start
            default:
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "PEAOT", "Power.enableAllOnTimer returns failure. Invalid option value.");
                    errorCallback(result);
                }
                return;
            // 160127 iamjunyoung.park : Add exception end
        }
          
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "set",
                parameters : {
                    category : "time",
                    settings : {
                        "onTimerEnable": op
                    }
                },
                onSuccess : function() {
                    
                    if (options.clearOnTimer === true) {
                        
                        var count = 0;
                        var hour = ["0","0","0","0","0","0","0"],
                            min = ["0","0","0","0","0","0","0"],
                            week = ["0","0","0","0","0","0","0"],
                            source = ["0","0","0","0","0","0","0"],
                            schedule = [];
                        
                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method : "set",
                            parameters : {
                                category : "commercial",
                                settings : {
                                "multiOnTimerHour":hour,
                                "multiOnTimerMinute":min,
                                "multiOnTimerWeekday":week,
                                "multiOnTimerSource":source,
                                "onTimerCount":count,
                                "onTimerSchedule":schedule
                                }
                            },
                            onSuccess : function() {
                                log("enableAllOnTimer: On Success 2");
                                
                                if(typeof successCallback === 'function'){
                                    successCallback();
                                }
                            },
                            onFailure : function(result) {
                                log("enableAllOnTimer: On Failure 2");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "PEAOT", "Power.enableAllOnTimer returns failure. / clearOnTimer");
                                    errorCallback(result);
                                }
                                    
                            }
                        });
                        
                    } else {
                        
                        if(typeof successCallback === 'function') {
                            log("enableAllOnTimer: On Success");
                            successCallback();
                        }
                    }
                },
                onFailure : function(result) {
                    delete result.returnValue;
                    if(typeof errorCallback === 'function') {
                        log("enableAllOnTimer: On Failure");
                        checkErrorCodeNText(result, "PEAOT", "Power.enableAllOnTimer returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.enableAllOnTimer Done");
    
    };
        
    /**
     * Controls all "off timer". This API enables/disables all "off timer" at once. Values of each "off timer" which was set by Power.addOffTimer() are not changed when options.clearOffTimer is false.
     *   
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>allOffTimer</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *       <tr class="odd"><th>clearOffTimer</th><th>Boolean</th><th>true : removes all "off Timer" / false : do nothing. (default) </th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function enableAllOffTimer () {
     *   var options = {
     *      allOffTimer : true
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.enableAllOffTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @since 1.3 options.clearOffTimer
     * @see
     * <a href="Power%23getPowerStatus.html">Power.getPowerStatus()</a><br>
     */
    Power.prototype.enableAllOffTimer = function (successCallback, errorCallback, options) {
    
        log("enableAllOffTimer: " + JSON.stringify(options));
        var op = null;
        
        switch(options.allOffTimer) {
            case true :
                op = "on";
                break;
            case false :
                op = "off";
                break;
            // 160127 iamjunyoung.park : Add exception start
            default:
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "PEAOT", "Power.enableAllOffTimer returns failure. Invalid option value.");
                    errorCallback(result);
                }
                return;
            // 160127 iamjunyoung.park : Add exception end
        }
            
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "set",
                parameters : {
                    category : "time",
                    settings : {
                        "offTimerEnable": op
                    }
                },
                onSuccess : function() {
                    
                    if (options.clearOffTimer === true) {
                        
                        var count = 0;
                        var hour = ["0","0","0","0","0","0","0"],
                            min = ["0","0","0","0","0","0","0"],
                            week = ["0","0","0","0","0","0","0"],
                            schedule = [];
                        
                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method : "set",
                            parameters : {
                                category : "commercial",
                                settings : {
                                    "multiOffTimerHour": hour,
                                    "multiOffTimerMinute": min,
                                    "multiOffTimerWeekday": week,
                                    "offTimerCount": count,
                                    "offTimerSchedule": schedule
                                }
                            },
                            onSuccess : function() {
                                log("enableAllOffTimer: On Success 2");
                                
                                if(typeof successCallback === 'function'){
                                    successCallback();
                                }
                            },
                            onFailure : function(result) {
                                log("enableAllOffTimer: On Failure 2");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "PEAOT", "Power.enableAllOffTimer returns failure. / clearOffTimer");
                                    errorCallback(result);
                                }
                            }
                        });
                    } else {
                        if(typeof successCallback === 'function') {
                            log("enableAllOffTimer: On Success");
                            successCallback();
                        }
                    }
                },
                onFailure : function(result) {
                    delete result.returnValue;
                    if(typeof errorCallback === 'function') {
                        log("enableAllOffTimer: On Failure");
                        checkErrorCodeNText(result, "PEAOT", "Power.enableAllOffTimer returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.enableAllOffTimer Done");
    
    };
    
    /**
     * Enables or disables 'wake on LAN'. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>wakeOnLan</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function enableWakeOnLan () {
     *   var options = {
     *      wakeOnLan : true
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.enableWakeOnLan(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getPowerStatus.html">Power.getPowerStatus()</a><br>
     */
    Power.prototype.enableWakeOnLan = function (successCallback, errorCallback, options) {

        log("enableWakeOnLan: " + JSON.stringify(options));
        var op = null;
        
        switch(options.wakeOnLan) {
            case true :
                op = "1";
                break;
            case false :
                op = "0";
            break;
            // 160127 iamjunyoung.park : Add exception start
            default:
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "PSWOL", "Power.enableWakeOnLan returns failure. Invalid option value.");
                    errorCallback(result);
                }
                return;
            // 160127 iamjunyoung.park : Add exception end
        }
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "wolEnable": op
                }
            },
            onSuccess : function() {
                if(typeof successCallback === 'function') {
                    log("enableWakeOnLan: On Success");
                    successCallback();
                }
            },
            onFailure : function(result) {
                delete result.returnValue;
                if(typeof errorCallback === 'function') {                    
                    log("enableWakeOnLan: On Failure");
                    checkErrorCodeNText(result, "PSWOL", "Power.enableWakeOnLan returns failure.");
                    errorCallback(result);
                }
            }
        });
    
        log("Power.enableWakeOnLan Done");
    
    };
    
    
    /**
     * Adds 'on timer'. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr class="odd"><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr><th>week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> <br>To use it on multiple days of week, set the sum of week. <br>For example, 1 + 64 (Power.TimerWeek.Monday + Power.TimerWeek.Sunday) means that this timer works on every Monday and Sunday.</th><th>required</th></tr>
     *       <tr class="odd"><th>inputSource</th><th>String</th><th>Define the input source. ext://[externalInput]:[portNum]. (eg: "ext://hdmi:1")</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function addOnTimer () {
     *   var options = {
     *      hour : 9,
     *      minute : 0,
     *      week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY,
     *      inputSource : "ext://hdmi:1"
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.addOnTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getOnTimerList.html">Power.getOnTimerList()</a>, 
     * <a href="InputSource.%23getInputSourceStatus.html">InputSource.getInputSourceStatus()</a><br>
     */
    Power.prototype.addOnTimer = function (successCallback, errorCallback, options) {
    
        log("addOnTimer: " + JSON.stringify(options));
        
        // bound check
        /**
         * 160125 iamjunyoung.park : Fix week condition [week <= 0] to [week < 0] (Not repeat)
         */
        if (options.hour === undefined || isNaN(options.hour) || typeof options.hour !== 'number' || options.hour < 0 || options.hour > 23 ||
            options.minute === undefined || isNaN(options.minute) || typeof options.minute !== 'number' || options.minute < 0 || options.minute > 59 ||
            options.week === undefined || isNaN(options.week) || typeof options.week !== 'number' || options.week < 0 || options.week > 127 ||
            options.inputSource === undefined || typeof options.inputSource !== 'string' || options.inputSource.indexOf("ext://") !== 0) {
        
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "PAOT", "Power.addOnTimer returns failure. invalid parameters or out of range.");
                errorCallback(result);
            }            
            return;
        }
        
        checkPlatformVersion(function(info) {
            service.Request("luna://com.webos.service.eim/", {
                method: "getAllInputStatus",
                onSuccess: function(result) {
                    log("getInputSourceStatus: On Success");                    
                    if (result.returnValue === true) {
                        var hasInputSource = false;

                        for (var i = 0; i < result.totalCount; i++) {
                            var deviceName = result.devices[i].deviceName.toLowerCase();
                            var port = 1;
                            if (isNaN(deviceName.substring(deviceName.length - 1, deviceName.length)) === false) //number
                            {
                                deviceName = deviceName.substring(0, deviceName.length - 1);
                                port = result.devices[i].id.split("_")[1];
                            }

                            if (deviceName === "displayport")
                                deviceName = "dp";

                            if (('ext://' + deviceName.toLowerCase() + ':' + port) === options.inputSource) {
                                hasInputSource = true;
                                break;
                            }
                        }

                        if (hasInputSource === false) {
                            log("addOnTimer: On Failure");
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "PAOT", "Power.addOnTimer returns failure.");
                                errorCallback(result);
                            }
                            return;
                        }

                        //1. timer enable / disable
                        //2. set time information
                        //3. set the number of timer.
                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "get",
                            parameters: {
                                category: "commercial",
                                keys: ["multiOnTimerHour", "multiOnTimerMinute", "multiOnTimerWeekday", "multiOnTimerSource", "onTimerSchedule", "onTimerCount"]
                            },
                            onSuccess: function(result) {
                                //log("addOnTimer: get timer data " + JSON.stringify(result));
                                if (result.returnValue === true) {

                                    log("version : " + info.webOSVer);
                                    // in exceptional case of luna result error
                                    if (typeof result.settings.multiOnTimerHour === 'string') {
                                        result.settings.multiOnTimerHour = JSON.parse(result.settings.multiOnTimerHour);
                                    }

                                    if (typeof result.settings.multiOnTimerMinute === 'string') {
                                        result.settings.multiOnTimerMinute = JSON.parse(result.settings.multiOnTimerMinute);
                                    }

                                    if (typeof result.settings.multiOnTimerWeekday === 'string') {
                                        result.settings.multiOnTimerWeekday = JSON.parse(result.settings.multiOnTimerWeekday);
                                    }

                                    if (typeof result.settings.multiOnTimerSource === 'string') {
                                        result.settings.multiOnTimerSource = JSON.parse(result.settings.multiOnTimerSource);
                                    }

                                    if (typeof result.settings.onTimerSchedule === 'string') {
                                        result.settings.onTimerSchedule = JSON.parse(result.settings.onTimerSchedule);
                                    }
                                    // end of exceptional case

                                    var index = (result.settings.onTimerSchedule === null || result.settings.onTimerSchedule === undefined ? 0 : result.settings.onTimerSchedule.length);

                                    if (result.settings.multiOnTimerHour.length <= index) {
                                        // out of range
                                        if (typeof errorCallback === 'function') {
                                            checkErrorCodeNText(result, "PSOT", "Power.addOnTimer returns failure. No space to add timer.");
                                            errorCallback(result);
                                        }
                                        return;
                                    }

                                    if (info.webOSVer === 3) {
                                        //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                                        //WEBOS 2.0 Sun(), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)
                                        if (options.week >= 64) //in case of choosing days including sunday                        
                                            options.week = 1 + (options.week - 64) * 2;
                                        else
                                            options.week = options.week * 2;
                                    }

                                    result.settings.multiOnTimerHour[index] = options.hour;
                                    result.settings.multiOnTimerMinute[index] = options.minute;
                                    result.settings.multiOnTimerWeekday[index] = options.week;
                                    result.settings.multiOnTimerSource[index] = convertExternal(options.inputSource);
                                    //result.settings.onTimerSchedule[index] = "" + padZero(options.hour, 2) +":"+ padZero(options.minute, 2) +", "+ convertWeekToStr(options.week);

                                    var seed = 360;
                                    result.settings.onTimerSchedule[index] = {
                                        "_id": "" + seed++,
                                        "hour": options.hour,
                                        "input": convertExternal(options.inputSource),
                                        "minute": options.minute,
                                        "weekday": options.week
                                    };

                                    service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                                        method: "set",
                                        parameters: {
                                            category: "commercial",
                                            settings: {
                                                "multiOnTimerHour": result.settings.multiOnTimerHour,
                                                "multiOnTimerMinute": result.settings.multiOnTimerMinute,
                                                "multiOnTimerWeekday": result.settings.multiOnTimerWeekday,
                                                "multiOnTimerSource": result.settings.multiOnTimerSource,
                                                "onTimerCount": index + 1,
                                                "onTimerSchedule": result.settings.onTimerSchedule
                                            }
                                        },
                                        onSuccess: function() {
                                            log("addOnTimer: On Success 2");

                                            if (typeof successCallback === 'function') {
                                                successCallback();
                                            }
                                        },
                                        onFailure: function(result) {
                                            log("addOnTimer: On Failure 2");
                                            delete result.returnValue;
                                            if (typeof errorCallback === 'function') {
                                                checkErrorCodeNText(result, "PAOT", "Power.addOnTimer returns failure.");
                                                errorCallback(result);
                                            }
                                            return;
                                        }
                                    });
                                }
                            },
                            onFailure: function(result) {
                                log("addOnTimer: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "PAOT", "Power.addOnTimer returns failure.");
                                    errorCallback(result);
                                }
                                return;
                            }
                        });
                    } // if (result.returnValue === true) {
                },
                onFailure: function(result) {
                    log("getInputSourceStatus: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PAOT", "Power.addOnTimer returns failure on gathering input list.");
                        errorCallback(result);                        
                    }
                    return;
                }
            });
        }); // check version
 
        log("Power.addOnTimer Done");
    };
    
    /**
     * Deletes 'on timer'. The timer in the list that matches the parameter will be removed.
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr class="odd"><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr><th>week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> <br>To use it on multiple day of week, set the sum of week. <br>For example, 1 + 64 (Power.TimerWeek.Monday + Power.TimerWeek.Sunday) means that this timer works on every Monday and Sunday.</th><th>required</th></tr>
     *       <tr class="odd"><th>inputSource</th><th>String</th><th>Define the input source. ext://[externalInput]:[portNum]. (eg: "ext://hdmi:1")</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function deleteOnTimer () {
     *   var options = {
     *      hour : 9,
     *      minute : 0,
     *      week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY,
     *      inputSource : "ext://hdmi:1"
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.deleteOnTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getOnTimerList.html">Power.getOnTimerList()</a>, 
     * <a href="InputSource.%23getInputSourceStatus.html">InputSource.getInputSourceStatus()</a><br>
     */
    Power.prototype.deleteOnTimer = function (successCallback, errorCallback, options) {
    
        log("deleteOnTimer: " + JSON.stringify(options));
        
        /**
         * 160126 iamjunyoung.park : Fix week condition [week <= 0] to [week < 0] (Not repeat) 
         */
        // bound check
        if (options.hour === undefined || isNaN(options.hour) || typeof options.hour !== 'number' || options.hour < 0 || options.hour > 23 ||
            options.minute === undefined || isNaN(options.minute) || typeof options.minute !== 'number' || options.minute < 0 || options.minute > 59 ||
            options.week === undefined || isNaN(options.week) || typeof options.week !== 'number' || options.week < 0 || options.week > 127 ||
            options.inputSource === undefined || typeof options.inputSource !== 'string' || options.inputSource.indexOf("ext://") !== 0) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "PDOT", "Power.deleteOnTimer returns failure. invalid parameters or out of range.");
                errorCallback(result);
            }
            
            return;
        }
        
        //1. timer enable / disable
        //2. set time information
        //3. set the number of timer.
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["multiOnTimerHour", "multiOnTimerMinute", "multiOnTimerWeekday", "multiOnTimerSource", "onTimerSchedule", "onTimerCount" ]
            },
            onSuccess : function(result) {
                //log("deleteOnTimer: get timer data " + JSON.stringify(result));
                
                if (result.returnValue === true) {
                    checkPlatformVersion(function(info){
                        
                        log("version : " + info.webOSVer);
                        
                        // in exceptional case of luna result error
                        if ( typeof result.settings.multiOnTimerHour === 'string') {
                            result.settings.multiOnTimerHour = JSON.parse(result.settings.multiOnTimerHour);
                        }
                        
                        if ( typeof result.settings.multiOnTimerMinute === 'string') {
                            result.settings.multiOnTimerMinute = JSON.parse(result.settings.multiOnTimerMinute);
                        }
                        
                        if ( typeof result.settings.multiOnTimerWeekday === 'string') {
                            result.settings.multiOnTimerWeekday = JSON.parse(result.settings.multiOnTimerWeekday);
                        }
                        
                        if ( typeof result.settings.multiOnTimerSource === 'string') {
                            result.settings.multiOnTimerSource = JSON.parse(result.settings.multiOnTimerSource);
                        }
                        
                        if ( typeof result.settings.onTimerSchedule === 'string') {
                            result.settings.onTimerSchedule = JSON.parse(result.settings.onTimerSchedule);
                        }
                        // end of exceptional case
                        
                        var addIndex = 0,
                            count = (result.settings.onTimerSchedule === null || result.settings.onTimerSchedule === undefined ? 0 : result.settings.onTimerSchedule.length );
                        var hour = ["0","0","0","0","0","0","0"],
                            min = ["0","0","0","0","0","0","0"],
                            week = ["0","0","0","0","0","0","0"],
                            source = ["0","0","0","0","0","0","0"],
                            schedule = [];
                        var inputSource = convertExternal(options.inputSource);
                        var deleted = false;

                        if (info.webOSVer === 3) {
                            //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                            //WEBOS 2.0 Sun(), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)
                            if (options.week >= 64) //in case of choosing days including sunday                        
                                options.week = 1 + (options.week - 64) * 2;
                            else
                                options.week = options.week * 2;                            
                        }

                        for (var i=0; i<count; i++) {
                            
                            log("deleteOnTimer: " + inputSource);
                            
                            if (result.settings.onTimerSchedule[i] === null) {
                                continue;
                            }
                            
                            log("options.week : " + options.week + " result.settings.onTimerSchedule[" + i + "].weekday : " + result.settings.onTimerSchedule[i].weekday);

                            if (deleted === false &&
                                options.hour === result.settings.onTimerSchedule[i].hour &&
                                options.minute === result.settings.onTimerSchedule[i].minute &&
                                options.week === result.settings.onTimerSchedule[i].weekday &&
                                inputSource === result.settings.onTimerSchedule[i].input) {
                                // do nothing
                                    log("deleteOnTimer: index " + i);
                                    deleted = true;                                
                            } else {
                                hour[addIndex] = result.settings.multiOnTimerHour[i];
                                min[addIndex] = result.settings.multiOnTimerMinute[i];
                                week[addIndex] = result.settings.multiOnTimerWeekday[i];
                                source[addIndex] = result.settings.multiOnTimerSource[i];
                                schedule[addIndex] =  result.settings.onTimerSchedule[i];
                                addIndex++;
                            }
                        }
                        
                        if (deleted === true) {
                            count--;
                        }
                        
                        if (count === 0) {
                            schedule = [];
                        }
                        
                        if (result.settings.onTimerSchedule.length === count) {
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "PDOT", "Power.deleteOnTimer returns failure. There is no 'on timer' matched in the list.");
                                errorCallback(result);
                            }
                            return;
                        }
                                        
                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method : "set",
                            parameters : {
                                category : "commercial",
                                settings : {
                                    "multiOnTimerHour":hour,
                                    "multiOnTimerMinute":min,
                                    "multiOnTimerWeekday":week,
                                    "multiOnTimerSource":source,
                                    "onTimerCount":count,
                                    "onTimerSchedule":schedule
                                }
                            },
                            onSuccess : function() {
                                log("deleteOnTimer: On Success 2");
                                
                                if(typeof successCallback === 'function'){
                                    successCallback();
                                }
                            },
                            onFailure : function(result) {
                                log("deleteOnTimer: On Failure 2");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "PDOT", "Power.deleteOnTimer returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    });
                    
                }
            },
            onFailure : function(result) {
                log("deleteOnTimer: On Failure");
                delete result.returnValue;
                if(typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PDOT", "Power.deleteOnTimer returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.deleteOnTimer Done");
    };
    
    /**
     * Adds 'off timer'. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr class="odd"><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr><th>week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> <br>To use it on multiple days of week, set the sum of week. <br>For example, 1 + 64 (Power.TimerWeek.Monday + Power.TimerWeek.Sunday) means that this timer works on every Monday and Sunday.</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function addOffTimer () {
     *   var options = {
     *      hour : 9,
     *      minute : 0,
     *      week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.addOffTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getOffTimerList.html">Power.getOffTimerList()</a><br>
     */
    Power.prototype.addOffTimer = function (successCallback, errorCallback, options) {
        
        log("addOffTimer: " + JSON.stringify(options));
        
        /**
         * 160125 iamjunyoung.park : Fix week condition [week <= 0] to [week < 0] (Not repeat)
         */
        // bound check
        if (options.hour === undefined || isNaN(options.hour) || typeof options.hour !== 'number' || options.hour < 0 || options.hour > 23 ||
                options.minute === undefined || isNaN(options.minute) || typeof options.minute !== 'number' || options.minute < 0 || options.minute > 59 ||
                options.week === undefined || isNaN(options.week) || typeof options.week !== 'number' || options.week < 0 || options.week > 127 ) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "PAOT", "Power.addOffTimer returns failure. Invalid parameter.");
                errorCallback(result);
            }            
            return;
        }
        
        //1. timer enable / disable
        //2. set time information
        //3. set the number of timer.
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["multiOffTimerHour", "multiOffTimerMinute", "multiOffTimerWeekday", "offTimerSchedule", "offTimerCount" ]
            },
            onSuccess : function(result) {
                //log("addOffTimer: get timer data " + JSON.stringify(result));

                if (result.returnValue === true) {

                    // in exceptional case of luna result error
                    if (typeof result.settings.multiOffTimerHour === 'string') {
                        result.settings.multiOffTimerHour = JSON.parse(result.settings.multiOffTimerHour);
                    }

                    if (typeof result.settings.multiOffTimerMinute === 'string') {
                        result.settings.multiOffTimerMinute = JSON.parse(result.settings.multiOffTimerMinute);
                    }

                    if (typeof result.settings.multiOffTimerWeekday === 'string') {
                        result.settings.multiOffTimerWeekday = JSON.parse(result.settings.multiOffTimerWeekday);
                    }

                    if (typeof result.settings.offTimerSchedule === 'string') {
                        result.settings.offTimerSchedule = JSON.parse(result.settings.offTimerSchedule);
                    }
                    // end of exceptional case

                    var index = (result.settings.offTimerSchedule === null || result.settings.offTimerSchedule === undefined ? 0 : result.settings.offTimerSchedule.length);

                    if (result.settings.multiOffTimerHour.length <= index) {
                        // out of range
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "PAOT", "Power.addOffTimer returns failure. No space to add timer.");
                            errorCallback(result);
                        }
                        return;
                    }

                    checkPlatformVersion(function(info) {

                        log("version : " + info.webOSVer);

                        if (info.webOSVer === 3) {                        
                            //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                            //WEBOS 2.0 Sun(), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)
                            if (options.week >= 64) //in case of choosing days including sunday                        
                                options.week = 1 + (options.week - 64) * 2;
                            else
                                options.week = options.week * 2;
                        }
                    
                        result.settings.multiOffTimerHour[index] = options.hour;
                        result.settings.multiOffTimerMinute[index] = options.minute;
                        result.settings.multiOffTimerWeekday[index] = options.week;

                        log("add hour: " + options.hour + ", min : " + options.minute + ", week : " + options.week);
                        //result.settings.offTimerSchedule[index] = "" + padZero(options.hour, 2) +":"+ padZero(options.minute, 2) +", "+ convertWeekToStr(options.week);

                        var seed = 360;
                        result.settings.offTimerSchedule[index] = {
                            "_id": "" + seed++,
                            "hour": options.hour,
                            "minute": options.minute,
                            "weekday": options.week
                        };

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                category: "commercial",
                                settings: {
                                    "multiOffTimerHour": result.settings.multiOffTimerHour,
                                    "multiOffTimerMinute": result.settings.multiOffTimerMinute,
                                    "multiOffTimerWeekday": result.settings.multiOffTimerWeekday,
                                    "offTimerCount": index + 1,
                                    "offTimerSchedule": result.settings.offTimerSchedule
                                }
                            },
                            onSuccess: function() {
                                log("addOffTimer: On Success 2");
                                if (typeof successCallback === 'function') {
                                    successCallback();
                                }
                            },
                            onFailure: function(result) {
                                log("addOffTimer: On Failure 2");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "PAOT", "Power.addOffTimer returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });

                    });
                }
            },
            onFailure : function(result) {
                log("addOffTimer: On Failure");
                delete result.returnValue;
                if(typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PAOT", "Power.addOffTimer returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.addOffTimer Done");
    };
    
    /**
     * Deletes 'off timer'. The timer in the list that matches the parameter will be removed.
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>hour</th><th>Number</th><th>hour (0~23)</th><th>required</th></tr>
     *       <tr class="odd"><th>minute</th><th>Number</th><th>minute (0~59)</th><th>required</th></tr>
     *       <tr><th>week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> <br>To use it on multiple day of week, set the sum of week. <br>For example, 1 + 64 (Power.TimerWeek.Monday + Power.TimerWeek.Sunday) means that this timer works on every Monday and Sunday.</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function deleteOffTimer () {
     *   var options = {
     *      hour : 9,
     *      minute : 0,
     *      week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.deleteOffTimer(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getOffTimerList.html">Power.getOffTimerList()</a>, 
     * <a href="InputSource.%23getInputSourceStatus.html">InputSource.getInputSourceStatus()</a><br>
     */
    Power.prototype.deleteOffTimer = function (successCallback, errorCallback, options) {
    
        log("deleteOffTimer: " + JSON.stringify(options));
        
        // bound check
        /**
         * 160126 iamjunyoung.park : Fix week condition [week <= 0] to [week < 0] (Not repeat) 
         */
        if (options.hour === undefined || isNaN(options.hour) || typeof options.hour !== 'number' || options.hour < 0 || options.hour > 23 ||
            options.minute === undefined || isNaN(options.minute) || typeof options.minute !== 'number' || options.minute < 0 || options.minute > 59 ||
            options.week === undefined || isNaN(options.week) || typeof options.week !== 'number' || options.week < 0 || options.week > 127 ) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "PDOT", "Power.deleteOffTimer returns failure. invalid parameters or out of range.");
                errorCallback(result);
            }
            
            return;
        }
        
        //1. timer enable / disable
        //2. set time information
        //3. set the number of timer.
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["multiOffTimerHour", "multiOffTimerMinute", "multiOffTimerWeekday", "offTimerSchedule", "offTimerCount" ]
            },
            onSuccess : function(result) {
                //log("deleteOffTimer: get timer data " + JSON.stringify(result));
                
                if (result.returnValue === true) {
                    
                    // in exceptional case of luna result error
                    if ( typeof result.settings.multiOffTimerHour === 'string') {
                        result.settings.multiOffTimerHour = JSON.parse(result.settings.multiOffTimerHour);
                    }
                    
                    if ( typeof result.settings.multiOffTimerMinute === 'string') {
                        result.settings.multiOffTimerMinute = JSON.parse(result.settings.multiOffTimerMinute);
                    }
                    
                    if ( typeof result.settings.multiOffTimerWeekday === 'string') {
                        result.settings.multiOffTimerWeekday = JSON.parse(result.settings.multiOffTimerWeekday);
                    }
                    
                    if ( typeof result.settings.offTimerSchedule === 'string') {
                        result.settings.offTimerSchedule = JSON.parse(result.settings.offTimerSchedule);
                    }
                    // end of exceptional case
                    
                    var addIndex = 0,
                        count = (result.settings.offTimerSchedule === null || result.settings.offTimerSchedule === undefined ? 0 : result.settings.offTimerSchedule.length);
                    var hour = ["0","0","0","0","0","0","0"],
                        min = ["0","0","0","0","0","0","0"],
                        week = ["0","0","0","0","0","0","0"],
                        schedule = [];
                    
                    //console.log("result.settings.offTimerSchedule.length  in " + result.settings.offTimerSchedule.length);
                    var deleted = false;
                    

                    checkPlatformVersion(function(info) {

                        log("version : " + info.webOSVer);

                        if (info.webOSVer === 3) {
                            //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                            //WEBOS 2.0 Sun(), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)
                            if (options.week >= 64) //in case of choosing days including sunday                        
                                options.week = 1 + (options.week - 64) * 2;
                            else
                                options.week = options.week * 2;                            
                        }                        
                    });

                    for (var i = 0; i < count; i++) {

                        //console.log("result.settings.offTimerSchedule.length  in " + JSON.stringify(result.settings.offTimerSchedule[i]));
                        if (result.settings.offTimerSchedule[i] === null) {
                            continue;
                        }

                        log("options.week : " + options.week + " result.settings.offTimerSchedule[" + i + "].weekday : " + result.settings.offTimerSchedule[i].weekday);

                        if (deleted === false &&
                            options.hour === result.settings.offTimerSchedule[i].hour &&
                            options.minute === result.settings.offTimerSchedule[i].minute &&
                            options.week === result.settings.offTimerSchedule[i].weekday ) {
                            // do nothing
                            //log("deleteOffTimer: index " + i);
                            deleted = true;
                        } else {
                            hour[addIndex] = result.settings.multiOffTimerHour[i];
                            min[addIndex] = result.settings.multiOffTimerMinute[i];
                            week[addIndex] = result.settings.multiOffTimerWeekday[i];
                            schedule[addIndex] = result.settings.offTimerSchedule[i];
                            addIndex++;
                        }
                    }
                    
                    if (deleted === true) {
                        count--;
                    }
                    
                    if (count === 0) { 
                        schedule = [];
                    }
                    
                    if (result.settings.offTimerSchedule.length === count) {
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "PDOT", "Power.deleteOffTimer returns failure. There is no 'off timer' matched in the list.");
                            errorCallback(result);
                        }
                        return;
                    }
                                    
                    service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                        method : "set",
                        parameters : {
                            category : "commercial",
                            settings : {
                                "multiOffTimerHour":hour,
                                "multiOffTimerMinute":min,
                                "multiOffTimerWeekday":week,
                                "offTimerCount":count,
                                "offTimerSchedule":schedule
                            }
                        },
                        onSuccess : function() {
                            log("deleteOffTimer: On Success 2");
                            
                            if(typeof successCallback === 'function'){
                                successCallback();
                            }
                        },
                        onFailure : function(result) {
                            log("deleteOffTimer: On Failure 2");
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "PDOT", "Power.deleteOffTimer returns failure.");
                                errorCallback(result);
                            }
                                
                        }
                    });
                }
            },
            onFailure : function(result) {
                log("deleteOffTimer: On Failure");
                delete result.returnValue;
                if(typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PDOT", "Power.deleteOffTimer returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.deleteOffTimer Done");
    
    };
    
    /**
     * Gets 'on timer' list. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return <p>{Object} list of timer object.</p>
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>timerList[]</th><th>Array</th><th>An array with the timer information object as its elements. </th></tr>
     *       <tr class="odd"><th>timerList[].hour</th><th>Number</th><th>hour (0~23) </th></tr>
     *       <tr><th>timerList[].minute</th><th>Number</th><th>minute (0~59) </th></tr>
     *       <tr class="odd"><th>timerList[].week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> </th></tr>
     *       <tr><th>timerList[].inputSource</th><th>String</th><th>Input source</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getOnTimerList () {
     *   function successCb(cbObject) {
     *      var timerList = cbObject.timerList;
     *      for ( var i = 0; i < timerList.length; i++) {
     *         console.log("timerList[" + i + "] : " + JSON.stringify(timerList[i]));
     *         console.log("timerList[" + i + "].hour : " + timerList[i].hour);
     *         console.log("timerList[" + i + "].minute : " + timerList[i].minute);
     *         console.log("timerList[" + i + "].week : " + timerList[i].week);
     *         console.log("timerList[" + i + "].inputSource : " + timerList[i].inputSource);
     *      }
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.getOnTimerList(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23setOnTimer.html">Power.setOnTimer()</a><br>
     */
    Power.prototype.getOnTimerList = function(successCallback, errorCallback) {

        log("getOnTimerList: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["onTimerSchedule"]
            },
            onSuccess: function(result) {

                if (result.returnValue === true) {

                    checkPlatformVersion(function(info) {

                        log("version : " + info.webOSVer);

                        var cbObj = {};

                        if (typeof result.settings.onTimerSchedule === 'string') {
                            result.settings.onTimerSchedule = JSON.parse(result.settings.onTimerSchedule);
                        }

                        var timerList = new Array(result.settings.onTimerSchedule === null || result.settings.onTimerSchedule === undefined ? 0 : result.settings.onTimerSchedule.length);
                        //console.log("timerList " + timerList);
                        //console.log("timerList.length " + timerList.length);
                        for (var index = 0, i = 0; i < timerList.length; i++) {
                            if (result.settings.onTimerSchedule[i] === null || result.settings.onTimerSchedule[i] === undefined) {
                                continue;
                            }
                            timerList[index] = {
                                hour: 0,
                                minute: 0,
                                week: 0,
                                inputSource: 0
                            };

                            if (info.webOSVer === 3) {
                                //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                                //WEBOS 2.0 Sun(64), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)                                
                                var tempWeek = result.settings.onTimerSchedule[i].weekday;

                                if (tempWeek % 2) //in case of choosing days including sunday      
                                {
                                    var remainder = tempWeek % 2;
                                    tempWeek = 64 + ((tempWeek - remainder) / 2);
                                } else
                                    tempWeek = tempWeek / 2;
                            } else
                                result.settings.onTimerSchedule[i].weekday;

                            timerList[index].hour = result.settings.onTimerSchedule[i].hour;
                            timerList[index].minute = result.settings.onTimerSchedule[i].minute;
                            timerList[index].week = tempWeek;
                            timerList[index++].inputSource = convertExternal(result.settings.onTimerSchedule[i].input);
                        }

                        cbObj.timerList = timerList;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }

                    });
                }
            },
            onFailure: function(result) {
                log("getOnTimerList: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PGOTL", "Power.getOnTimerList returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Power.getOnTimerList Done");

    };
    
    /**
     * Gets 'off timer' list. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return <p>{Object} list of timer object.</p>
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>timerList[]</th><th>Array</th><th>An array with the timer information object as its elements. </th></tr>  
     *       <tr class="odd"><th>timerList[].hour</th><th>Number</th><th>hour (0~23) </th></tr>
     *       <tr><th>timerList[].minute</th><th>Number</th><th>minute (0~59) </th></tr>
     *       <tr class="odd"><th>timerList[].week</th><th>Number</th><th>week <a href="Power.TimerWeek.html#constructor">Power.TimerWeek</a> </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getOffTimerList () {
     *   function successCb(cbObject) {
     *      var timerList = cbObject.timerList;
     *      for ( var i = 0; i < timerList.length; i++) {
     *         console.log("timerList[" + i + "] : " + JSON.stringify(timerList[i]));
     *         console.log("timerList[" + i + "].hour : " + timerList[i].hour);
     *         console.log("timerList[" + i + "].minute : " + timerList[i].minute);
     *         console.log("timerList[" + i + "].week : " + timerList[i].week);
     *      }
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.getOffTimerList(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23setOffTimer.html">Power.setOffTimer()</a><br>
     */
    Power.prototype.getOffTimerList = function(successCallback, errorCallback) {

        log("getOffTimerList: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["offTimerSchedule"]
            },
            onSuccess: function(result) {
                log("getOffTimerList: On Success");

                checkPlatformVersion(function(info) {

                    log("version : " + info.webOSVer);

                    if (result.returnValue === true) {
                        var cbObj = {};

                        if (typeof result.settings.offTimerSchedule === 'string') {
                            result.settings.offTimerSchedule = JSON.parse(result.settings.offTimerSchedule);
                        }

                        var timerList = new Array(result.settings.offTimerSchedule === null || result.settings.offTimerSchedule === undefined ? 0 : result.settings.offTimerSchedule.length);

                        //console.log("timerList " + timerList);
                        //console.log("timerList.length " + timerList.length);

                        for (var index = 0, i = 0; i < timerList.length; i++) {
                            if (result.settings.offTimerSchedule[i] === null || result.settings.offTimerSchedule[i] === undefined) {
                                continue;
                            }
                            timerList[index] = {
                                hour: 0,
                                minute: 0,
                                week: 0
                            };

                            if (info.webOSVer === 3) {
                                //WEBOS 3.0 Sun(1), Mon(2), Thes(4), Wen(8), Thur(16), Fri(32). Sat(64)
                                //WEBOS 2.0 Sun(64), Mon(1), Thes(2), Wen(4), Thur(8), Fri(16). Sat(32)                                
                                var tempWeek = result.settings.offTimerSchedule[i].weekday;

                                if (tempWeek % 2) //in case of choosing days including sunday      
                                {
                                    var remainder = tempWeek % 2;
                                    tempWeek = 64 + ((tempWeek - remainder) / 2);
                                } else
                                    tempWeek = tempWeek / 2;
                            } else
                                tempWeek = result.settings.offTimerSchedule[i].weekday;

                            timerList[index].hour = result.settings.offTimerSchedule[i].hour;
                            timerList[index].minute = result.settings.offTimerSchedule[i].minute;
                            timerList[index++].week = tempWeek;                                            
                        }

                        cbObj.timerList = timerList;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                });
            },
            onFailure: function(result) {
                log("getOffTimerList: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PGOTL", "Power.getOffTimerList returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Power.getOffTimerList Done");
    };
    
    /**
     * Turns on/off the display panel. This will only affect the panel, not the main power. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>displayMode</th><th>String</th><th><a href="Power.DisplayMode.html#constructor">Power.DisplayMode</a> </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setDisplayMode () {
     *   var options = {
     *      displayMode : Power.DisplayMode.DISPLAY_OFF
     *   };
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.setDisplayMode(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getPowerStatus.html">Power.getPowerStatus()</a><br>
     */
    Power.prototype.setDisplayMode = function (successCallback, errorCallback, options) {
    
        log("setDisplayMode: " + JSON.stringify(options));
        
        var command = null;
        
        switch (options.displayMode) {
            case Power.DisplayMode.DISPLAY_OFF :
                command = "turnOffScreen";
                break;
            case Power.DisplayMode.DISPLAY_ON :
                command = "turnOnScreen";
                break;
            // 160127 iamjunyoung.park : Add exception start
            default:
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "PSDM", "Power.setDisplayMode returns failure. Invalid option value.");
                    errorCallback(result);
                }
                return;
            // 160127 iamjunyoung.park : Add exception end
        }
        
        log("setDisplayMode: " + command);
        
        if (command === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "PSDM", "Power.setDisplayMode returns failure. command was not defined.");
            errorCallback(result);
            log("Power.setDisplayMode invalid ");
            return;
        }
        
        /*
        service.Request("luna://com.webos.service.tvpower/power/", {
        */
        service.Request("luna://com.webos.service.tv.signage/", {
            method : "getPowerState",
            onSuccess : function(result) {
                log("setDisplayMode: On Success");
                
                if (result.returnValue === true && result.state === options.displayMode) {
                    // no need to do any action.
                    if (typeof successCallback === 'function') {
                        log("setDisplayMode: no need to do any action.");
                        successCallback();
                    }
                    return;
                }
                /*
                service.Request("luna://com.webos.service.tvpower/power/", {
                */
                service.Request("luna://com.webos.service.tv.signage/", {
                    method : command,
                    onSuccess : function(result) {
                        log("setDisplayMode: On Success");
                        
                        if (result.returnValue === true) {
                            if (typeof successCallback === 'function') {
                                successCallback();
                            }
                        }
                    },
                    onFailure : function(result) {
                        log("setDisplayMode: On Failure");
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "PSDM", "Power.setDisplayMode returns failure.");
                            errorCallback(result);
                        }
                    }
                });
            },
        
            onFailure : function(result) {
                log("setDisplayMode: On Failure 2");
                delete result.returnValue;
                if(typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PSDM", "Power.setDisplayMode returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.setDisplayMode Done");
    };
    
    /**
     * Executes power related command. 
     * @class Power
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.     
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>powerCommand</th><th>String</th><th><a href="Power.PowerCommand.html#constructor">Power.PowerCommand</a> </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function executePowerCommand () {
     *   var options = {
     *      powerCommand : Power.PowerCommand.REBOOT
     *   };   
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var power = new Power();
     *   power.executePowerCommand(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Power%23getPowerStatus.html">Power.getPowerStatus()</a><br>
     */
    Power.prototype.executePowerCommand = function (successCallback, errorCallback, options) {
    
        log("executePowerCommand: " + JSON.stringify(options));
        
        if ( options.powerCommand === undefined || typeof options.powerCommand !== 'string' || options.powerCommand === null || options.powerCommand.length <= 0) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "PEPM", "Power.executePowerCommand returns failure. invalid argument or out of range. ");
                errorCallback(result);
            }
            return;
        }
        
        // 160127 iamjunyoug.park : Add exception start
        if ((options.powerCommand !== Power.PowerCommand.REBOOT) && (options.powerCommand !== Power.PowerCommand.SHUTDOWN)) {
            var result = {};
            checkErrorCodeNText(result, "PEPM", "Power.executePowerCommand returns failure. invalid argument.");
            errorCallback(result);
            return;
        }
        // 160127 iamjunyoug.park : Add exception end
        
        /*
        service.Request("luna://com.webos.service.tvpower/power/", {
        */
        service.Request("luna://com.webos.service.tv.signage/", {
                method : options.powerCommand,
                parameters : {
                    reason : "unknown"
                },
                onSuccess : function(result) {
                    log("executePowerCommand: On Success");
                    
                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure : function(result) {
                    log("executePowerCommand: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PEPM", "Power.executePowerCommand returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.executePowerCommand Done");
        
    };


	Power.prototype.setDPMWakeup = function (successCallback, errorCallback, options) {
    	var signalType = null;
        
        switch (options.dpmSignalType) {
            case Power.dpmSignalType.CLOCK :
                signalType = "clock";
                break;
            case Power.dpmSignalType.CLOCK_WITH_DATA :
                signalType = "clockAndData";
                break;
        }
        
        log("setDPMWakeup: " + signalType);
        
        if (signalType === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "PSDW", "Power.setDPMWakeup returns failure. command was not defined.");
            errorCallback(result);
            log("Power.setDPMWakeup invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "dpmWakeUpControl" : signalType 
                }
            },
            onSuccess : function(result) {
                log("setDPMWakeup: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setDPMWakeup: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PSDW", "Power.setDPMWakeup returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.setDPMWakeup Done");
    };

	Power.prototype.getDPMWakeup = function (successCallback, errorCallback) {
        
        log("getDPMWakeup: ");
        
            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "get",
                parameters : {
                    category : "commercial",
                    keys : ["dpmWakeUpControl"]
                },
                onSuccess : function(result) {
                    log("getDPMWakeup: On Success");
                    
                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.dpmSignalType = result.settings.dpmWakeUpControl;
                    
                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure : function(result) {
                    log("getDPMWakeup: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PGDW", "Power.getDPMWakeup returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.getDPMWakeup Done");
    };

	Power.prototype.setPMMode = function (successCallback, errorCallback, options) {
    	var mode = null;
        
        switch (options.mode) {
            case Power.PMMode.PowerOff :
                mode = "powerOff";
                break;
            case Power.PMMode.SustainAspectRatio :
                mode = "sustainAspectRatio";
                break;
            case Power.PMMode.ScreenOff :
                mode = "screenOff";
                break;
            case Power.PMMode.ScreenOffAlways :
                mode = "screenOffAlways";
                break;
        }
        
        log("setPMMode: " + mode);
        
        if (mode === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "PSPM", "Power.setPMMode returns failure. command was not defined.");
            errorCallback(result);
            log("Power.setPMMode invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "pmMode" : mode 
                }
            },
            onSuccess : function(result) {
                log("setPMMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setPMMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PSPM", "Power.setPMMode returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.setPMMode Done");
    };

	Power.prototype.getPMMode = function (successCallback, errorCallback) {
        
        log("getPMMode: ");
        
            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "get",
                parameters : {
                    category : "commercial",
                    keys : ["pmMode"]
                },
                onSuccess : function(result) {
                    log("getPMMode: On Success");
                    
                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.mode = result.settings.pmMode;
                    
                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure : function(result) {
                    log("getPMMode: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PGPM", "Power.getPMMode returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.getPMMode Done");
    };
    
    Power.prototype.setPowerOnDelay = function (successCallback, errorCallback, options) {
        log("setPowerOnDelay: " + options.delayTime);
        
        if (options.delayTime === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "PSPD", "Power.setPowerOnDelay returns failure. command was not defined.");
            errorCallback(result);
            log("Power.setPowerOnDelay invalid ");
            return;
        }      
        
        if (typeof options.delayTime !== 'number') {
            var result = {};
            checkErrorCodeNText(result, "PSPD", "Power.setPowerOnDelay returns failure. delayTime is not a number.");
            errorCallback(result);
            log("Power.setPowerOnDelay invalid type");
            return;
        }
        
        if ((options.delayTime < 0) || (options.delayTime > 250)) {
            var result = {};
            checkErrorCodeNText(result, "PSPD", "Power.setPowerOnDelay returns failure. Out of range.");
            errorCallback(result);
            log("Power.setPowerOnDelay invalid range");
            return;
        }
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "powerOnDelay" : options.delayTime 
                }
            },
            onSuccess : function(result) {
                log("setPowerOnDelay: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setPowerOnDelay: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "PSPD", "Power.setPowerOnDelay returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Power.setPowerOnDelay Done");
    };

    Power.prototype.getPowerOnDelay = function (successCallback, errorCallback) {
        
        log("getPowerOnDelay: ");
        
            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "get",
                parameters : {
                    category : "commercial",
                    keys : ["powerOnDelay"]
                },
                onSuccess : function(result) {
                    log("getPowerOnDelay: On Success");
                    
                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.delayTime = result.settings.powerOnDelay;
                    
                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure : function(result) {
                    log("getPowerOnDelay: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "PGPD", "Power.getPowerOnDelay returns failure.");
                        errorCallback(result);
                    }
                }
            });
        
        log("Power.getPowerOnDelay Done");
    };


    module.exports = Power;
});

Power = cordova.require('cordova/plugin/power'); // jshint ignore:line

