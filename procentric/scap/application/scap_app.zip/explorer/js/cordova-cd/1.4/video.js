/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the video API itself, and provides a global namespace for operating video service.
 * @class
 */
cordova.define('cordova/plugin/video', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
               log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
               if (typeof params.onFailure === 'function') {
                  params.onFailure({
                      returnValue:false,
                      errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }
    
    /**
     * video interface
     */
    var Video = function () {
    };
    
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }
    
    /**
     * 160202 iamjunyoung.park : checkPlatform added
     */
    
    var platformInfoObj = {
        webOSVer : -1,
        chipset : 'undefined'
    }; 
    function checkPlatformVersion(cb) {
        
        if (platformInfoObj.webOSVer === -1) {  // Not defined yet
            
            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer : 1,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer : 2,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer : 3,
                            chipset : result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer : 0,
                            chipset : ""
                        };
                    }                    
                    cb(platformInfoObj);                    
                },
                onFailure: function(error) {
                    platformInfoObj = {
                        webOSVer : 0,
                        chipset : ""
                    }
                    cb(platformInfoObj);
                }
            });
            
        } else {
            cb(platformInfoObj);
        }
    }
    
    /**
     * Gets video position and size. 
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>source</th><th>Object</th><th>source rectangle of video. </th></tr>
     *       <tr><th>source.x</th><th>Number</th><th>The x coordinate of the upper-left corner of the rectangle. </th></tr>
     *       <tr class="odd"><th>source.y</th><th>Number</th><th>The y coordinate of the upper-left corner of the rectangle. </th></tr>
     *       <tr><th>source.width</th><th>Number</th><th>The width of the rectangle. </th></tr>
     *       <tr class="odd"><th>source.height</th><th>Number</th><th>The height of the rectangle. </th></tr>
     *   </tbody>
     * </table>
     *
     * @example
     * // Javascript code
     * function getVideoStatus () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject.source));
     *
     *      console.log("source.x : " + cbObject.source.x);
     *      console.log("source.y : " + cbObject.source.y);
     *      console.log("source.width : " + cbObject.source.width);
     *      console.log("source.height : " + cbObject.source.height);
     *      
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var video = new Video();
     *   video.getVideoStatus(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Video%23setVideoSize.html">Video.setVideoSize()</a><br>
     */
    Video.prototype.getVideoStatus = function (successCallback, errorCallback) {

        log("getVideoStatus: ");
        
        service.Request("luna://com.webos.service.tv.signage/", {
            method : "getVideoSize",
            onSuccess : function(result) {
                log("getVideoStatus: On Success");
                
                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var cbObj = {};
                        cbObj.source = result.videoSize.source;
                        successCallback(cbObj);
                    }
                }
            },
            onFailure : function(result) {
                log("getVideoStatus: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "VGVS", "Video.getVideoStatus returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Video.getVideoStatus Done");
    
    };

    Video.currentVideo = {
        uri : null, 
        source : null, 
        tagId : null
    };
    
    /**
     * Sets video size.<br>
     * Original video(source rectangle) will be adjusted to the full screen size. It can be resized or a zoom effect can be applied to the video.
     * <br>
     * Note : Using more than one video tag in an html page may not be supported due to hardware limitation.
     *   
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options source object vary depending on video resolution.  
     *                  And rectangle object has boundary value as : <br>
     *                  source.x + source.width <= width of video resolution , source.y + source.height <= height of video resolution <br>
     *                  x and y value of rectangle are upper than zero. 
     * <br><image src="./image/setVideoSize.png"><br>
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>source</th><th>Object</th><th>source rectangle of video. </th><th>required</th></tr>
     *       <tr><th>source.x</th><th>Number</th><th>The x coordinate of the upper-left corner of the rectangle. </th><th>required</th></tr>
     *       <tr class="odd"><th>source.y</th><th>Number</th><th>The y coordinate of the upper-left corner of the rectangle. </th><th>required</th></tr>
     *       <tr><th>source.width</th><th>Number</th><th>The width of the rectangle. </th><th>required</th></tr>
     *       <tr class="odd"><th>source.height</th><th>Number</th><th>The height of the rectangle. </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * 
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setVideoSize () {
     *   var options = {source: {x:10, y:10, width:900, height:600}};
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var video = new Video();
     *   video.setVideoSize(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Video%23getVideoStatus.html">Video.getVideoStatus()</a><br>
     * <a href="InputSource%23initialize.html#constructor">InputSource.initialize()</a><br>
     */
    Video.prototype.setVideoSize = function (successCallback, errorCallback, options) {
    
        log("setVideoSize: " + JSON.stringify(options));
        
        if (options.source === undefined ||
            typeof options.source.x !== 'number' || typeof options.source.y !== 'number' ||
            typeof options.source.width !== 'number' || typeof options.source.height !== 'number' ||
            isNaN(options.source.x) || isNaN(options.source.y) || isNaN(options.source.width) || isNaN(options.source.height) ||
            options.source.x < 0 || options.source.y < 0 || options.source.width <= 0 || options.source.height <= 0 ||
            options.source.width < 16 || options.source.height < 16) {
            
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure. out of range or type error.");
                errorCallback(result);
            }
            
            return;
        }
                
        service.Request("luna://com.webos.service.tv.signage/", {
            method : "getVideoSize",
            onSuccess : function(result) {
                log("setVideoSize: On Success");
                
                if (result.returnValue === true) {
                    
                    var cbObj = {};
                    cbObj.x = result.videoSize.destination.x;
                    cbObj.y = result.videoSize.destination.y;
                    cbObj.width = result.videoSize.destination.width;
                    cbObj.height = result.videoSize.destination.height;
                    
                    //console.log("current video size : " + JSON.stringify(result.videoSize.source));
                    //console.log("saved video : " + JSON.stringify(Video.currentVideo));
                
                    var videoTags = document.getElementsByTagName("video"); // jshint ignore:line
                    var findVideoTags = false;
                    for (var i=0; i<videoTags.length; i++) {
                        //console.log("video tag: " + videoTags[i]);
                        //console.log("video tag:id " + videoTags[i].id);
                        // video tag
                        if (videoTags[i].currentTime > 0) {
                            //console.log("video tag is working");
                            findVideoTags = true;
                            if (Video.currentVideo.uri !== videoTags[i].src || 
                                (videoTags[i].id !== null && 
                                 videoTags[i].id !== undefined && 
                                 Video.currentVideo.tagId !== null && 
                                 Video.currentVideo.tagId !== undefined && 
                                 Video.currentVideo.tagId !== videoTags[i].id) ) {
                                Video.currentVideo.uri = videoTags[i].src;
                                Video.currentVideo.source = result.videoSize.source;
                                Video.currentVideo.tagId = videoTags[i].id;
                                //console.log("saved new video : " + JSON.stringify(Video.currentVideo));
                            }
                            break;
                        }
                    }
                    if(findVideoTags === false) {
                        // external input
                        service.Request("luna://com.webos.service.eim/", {
                            method : "getCurrentInput",
                            parameters : {},
                            onSuccess : function(resultw) {
                                //console.log("current input " + JSON.stringify(resultw));
                                
                                if (resultw.returnValue === true && Video.currentVideo.uri !== resultw.mainInputSourceId ||
                                    (videoTags[0].id !== null && 
                                     videoTags[0].id !== undefined 
                                     && Video.currentVideo.tagId !== null 
                                     && Video.currentVideo.tagId !== undefined 
                                     && Video.currentVideo.tagId !== videoTags[0].id) ) {
                                    Video.currentVideo.uri = resultw.mainInputSourceId;
                                    Video.currentVideo.tagId = (videoTags[0] !== null && videoTags[0].id !== null && videoTags[0].id !== undefined ? videoTags[0].id : null);
                                    service.Request("luna://com.webos.service.tv.signage/", {
                                        method : "getVideoSize",
                                        onSuccess : function(resultx) {
                                            log("setVideoSize: On Success 1");
                                            
                                            if (resultx.returnValue === true) {
                                                
                                                Video.currentVideo.source = resultx.videoSize.source;
                                                //console.log("saved new video : " + JSON.stringify(Video.currentVideo));
                                                
                                                if (resultx.videoSize.source.width === 0 && resultx.videoSize.source.height === 0) {
                                                    
                                                    Video.currentVideo = {
                                                        uri : null,
                                                        source : null, 
                                                        tagId : null
                                                    };
                                                    
                                                    var resultCallBack = {};
                                                    checkErrorCodeNText(resultCallBack, "VSVS", "Video.setVideoSize returns failure. Not ready to setVideoSize." );
                                                    errorCallback(resultCallBack);
                                                    return;
                                                } else if ( Video.currentVideo.uri === null || Video.currentVideo.source === null || 
                                                        (options.source.width + options.source.x) > (Video.currentVideo.source.x + Video.currentVideo.source.width) ||
                                                        (options.source.height + options.source.y) > (Video.currentVideo.source.y + Video.currentVideo.source.height) ) {
                                                    
                                                    var resultCallBack2 = {};
                                                    checkErrorCodeNText(resultCallBack2, "VSVS", "Video.setVideoSize returns failure. out of range or type error."
                                                                                       + "(" + Video.currentVideo.source.width + " : " + Video.currentVideo.source.height + ")");
                                                    errorCallback(resultCallBack2);
                                                    return;
                                                    
                                                }
                                                
                                                service.Request("luna://com.webos.service.tv.signage/", {
                                                    method : "setVideoSize",
                                                    parameters : {
                                                        videoSize : {  
                                                            "source": {
                                                                "x": options.source.x,
                                                                "y": options.source.y,
                                                                "width": options.source.width,
                                                                "height": options.source.height
                                                            },
                                                            "destination": {
                                                                "x": cbObj.x,
                                                                "y": cbObj.y,
                                                                "width": cbObj.width,
                                                                "height": cbObj.height
                                                            }
                                                        }
                                                    },
                                                    onSuccess : function(result) {
                                                        log("setVideoSize: On Success 2");
                                                        
                                                        if (result.returnValue === true && typeof successCallback === 'function') {
                                                            successCallback();
                                                            return;
                                                        }
                                                    },
                                                    onFailure : function(result) {
                                                        log("setVideoSize: On Failure 2");
                                                        delete result.returnValue;
                                                        if (typeof errorCallback === 'function') {
                                                            checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure. Can't current video source size.");
                                                            errorCallback(result);
                                                            return;
                                                        }
                                                    }
                                                });
                                                
                                            }
                                        }
                                    });
                                } else {
                                    if ( Video.currentVideo.uri === null || Video.currentVideo.source === null ||
                                        (options.source.width + options.source.x) > (Video.currentVideo.source.x + Video.currentVideo.source.width) ||
                                        (options.source.height + options.source.y) > (Video.currentVideo.source.y + Video.currentVideo.source.height) ){
                                        
                                        var resultCallBack = {};
                                        checkErrorCodeNText(resultCallBack, "VSVS", "Video.setVideoSize returns failure. out of range or type error."
                                                                          + "(" + Video.currentVideo.source.width + " : " + Video.currentVideo.source.height + ")");
                                        errorCallback(resultCallBack);
                                        return;
                                    }
                                    
                                    service.Request("luna://com.webos.service.tv.signage/", {
                                        method : "setVideoSize",
                                        parameters : {
                                            videoSize : {  
                                                "source": {
                                                    "x": options.source.x,
                                                    "y": options.source.y,
                                                    "width": options.source.width,
                                                    "height": options.source.height
                                                },
                                                "destination": {
                                                    "x": cbObj.x,
                                                    "y": cbObj.y,
                                                    "width": cbObj.width,
                                                    "height": cbObj.height
                                                }
                                            }
                                        },
                                        onSuccess : function(result) {
                                            log("setVideoSize: On Success 3");
                                            
                                            if (result.returnValue === true && typeof successCallback === 'function') {
                                                successCallback();
                                                return;
                                            }
                                        },
                                        onFailure : function(result) {
                                            log("setVideoSize: On Failure 3");
                                            delete result.returnValue;
                                            if (typeof errorCallback === 'function') {
                                                checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure. Can't current video source size.");
                                                errorCallback(result);
                                                return;
                                            }
                                        }
                                    });
                                } 
                            },
                            // 160127 iamjunyoung.park : Why failure callback is empty??
                            onFailure : function(result) {
                                log("setVideoSize: On Failure 3");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure. Can't set current video source size.");
                                    errorCallback(result);
                                    return;
                                }
                            }
                            // onFailure : function() {}
                        });
                    } else {
                        
                        if ( Video.currentVideo.uri === null || Video.currentVideo.source === null ||
                                (options.source.width + options.source.x) > (Video.currentVideo.source.x + Video.currentVideo.source.width) ||
                                (options.source.height + options.source.y) > (Video.currentVideo.source.y + Video.currentVideo.source.height) ) {
                            
                            var resultCallBack = {};
                            checkErrorCodeNText(resultCallBack, "VSVS", "Video.setVideoSize returns failure. out of range or type error."
                                                              + "(" + Video.currentVideo.source.width + " : " + Video.currentVideo.source.height + ")");
                            errorCallback(resultCallBack);
                            return;
                        }
                        
                        service.Request("luna://com.webos.service.tv.signage/", {
                            method : "setVideoSize",
                            parameters : {
                                videoSize : {  
                                    "source": {
                                        "x": options.source.x,
                                        "y": options.source.y,
                                        "width": options.source.width,
                                        "height": options.source.height
                                    },
                                    "destination": {
                                        "x": cbObj.x,
                                        "y": cbObj.y,
                                        "width": cbObj.width,
                                        "height": cbObj.height
                                    }
                                }
                            },
                            onSuccess : function(result) {
                                log("setVideoSize: On Success 4");
                                
                                if (result.returnValue === true && typeof successCallback === 'function') {
                                    successCallback();
                                    return;
                                }
                            },
                            onFailure : function(result) {
                                log("setVideoSize: On Failure 4");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure. Can't current video source size.");
                                    errorCallback(result);
                                    return;
                                }
                            }
                        });
                    }
                    
                    
                }
            },
            onFailure : function(result) {
                log("setVideoSize: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "VSVS", "Video.setVideoSize returns failure.");
                    errorCallback(result);
                    return;
                }
            }
        });
        
        log("Video.setVideoSize Done");
    };
    

    /**
     * Sets content rotation.<br>
     * <br>
     * Note :Only full screen video rotation is supported.
     *   
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options 
     * 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>degree</th><th>String</th><th>"off", "90", or "270"</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>aspectRatio</th><th>String</th><th>"full" or "original" </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * 
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setContentRotation () {
     *   var options = {degree : "90", aspectRatio : "full"};
     *     
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var video = new Video();
     *   video.setContentRotation(successCb, failureCb, options);
     * }
     * @since 1.3
     * @see
     * <a href="Video%23getContentRotation.html">Video.getContentRotation()</a><br>
     */
    Video.prototype.setContentRotation = function(successCallback, errorCallback, options) {

        log("setContentRotation: ");

        checkPlatformVersion(function(platformInformation) {

            if (platformInformation.webOSVer === 3) {
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "VSCR", "Video.setContentRotation is not supported in WEBOS 3.0.");
                    errorCallback(result);

                    return;
                }            
            }

            if (typeof options === "undefined" || options === null ||
                (options.degree !== "off" && options.degree !== "90" && options.degree !== "270") ||
                (options.aspectRatio !== "full" && options.aspectRatio != "original")) {

                var result = {};
                checkErrorCodeNText(result, "VSCR", "Video.setContentRotation invlalid parameters.");
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/video/", {
                method: "setContentRotation",
                parameters: options,
                onSuccess: function(result) {
                    log("setContentRotation: On Success");

                    if (result.returnValue === true && typeof successCallback === 'function') {
                        successCallback();
                        return;
                    }
                },
                onFailure: function(result) {
                    log("setContentRotation: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "VSCR", "Video.setContentRotation returns failure.");
                        errorCallback(result);
                        return;
                    }
                }
            });

            log("Video.setContentRotation: Done ");
        });
    };
    
    /**
     * Gets content rotation status. 
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>degree</th><th>String</th><th>"off", "90", or "270"</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>aspectRatio</th><th>String</th><th>"full" or "original" </th><th>required</th></tr>
     *   </tbody>
     * </table>
     *
     * @example
     * // Javascript code
     * function getContentRotation () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject.source));
     *
     *      console.log("degree : " + cbObject.degree);
     *      console.log("aspectRatio : " + cbObject.aspectRatio);
     *      
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var video = new Video();
     *   video.getContentRotation(successCb, failureCb);
     * }
     * @since 1.3
     * @see
     * <a href="Video%23setContentRotation.html">Video.setContentRotation()</a><br>
     */
    Video.prototype.getContentRotation = function(successCallback, errorCallback) {

        log("getContentRotation: ");

        checkPlatformVersion(function(platformInformation) {

            if (platformInformation.webOSVer === 3) {
                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "VSCR", "Video.getContentRotation is not supported in WEBOS 3.0.");
                    errorCallback(result);

                    return;
                }
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/video/", {
                method: "getContentRotation",
                onSuccess: function(result) {
                    log("getContentRotation: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            delete result.returnValue;
                            successCallback(result);
                        }
                    }
                },
                onFailure: function(result) {
                    log("getContentRotation: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "VGCR", "Video.getContentRotation returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Video.getContentRotation Done");
        });
    };
    
    /*
     * 160125 iamjunyoung.park : setVideoViewTransform added
     * 
     *                    Screen
     *    +-------------------------------------+
     *    |           |                         |
     *    |           | y                       |
     *    |      x    |                         |
     *    | <-------> +-------------+           |
     *    |           |#############|           |
     *    |           |### Video ###| height    |
     *    |           |#############|           |
     *    |           +-------------+           |
     *    |                width                |
     *    +-------------------------------------+
     */
    
    /**
     * Sets output size and position for 86BH5C model.<br>
     * <br>
     * Note : This feature is only for 86BH5C ultra strech webOS Signage model.
     *   
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options 
     * 
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>x</th><th>String</th><th>Postion of x-axis in video</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>y</th><th>String</th><th>Postion of y-axis in video</th><th>required</th></tr>
     *       <tr><th>width</th><th>String</th><th>Width of size in video</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>height</th><th>String</th><th>Height of size in video</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * 
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setVideoViewTransform() {
     * 
     *     var successCb = function (){
     *         // Do Something
     *     }
     * 
     *     var failureCb = function(){
     *         var errorCode = cbObject.errorCode;
     *         var errorText = cbObject.errorText;
     *         console.log ("Error Code [" + errorCode + "]: " + errorText);
     *     }
     * 	
     *     var video = new Video();

     *     video.setVideoViewTransform(successCb, failureCb, {
     *         //Portrait Standard
     *         x: 0, 
     *         y: 0,
     *         width: 1920,
     *         height: 600
     *     });    
     * }
     * @since 1.3
     * @see
     * <a href="Video%23setContentRotation.html">Video.setContentRotation()</a><br>
     */
    Video.prototype.setVideoViewTransform = function(successCallback, failureCallback, options) {
        if (typeof options.x !== 'number' || typeof options.y !== 'number' ||
            typeof options.width !== 'number'|| typeof options.height !== 'number') {
            failureCallback({
                errorCode : "VSVVT",
                errorText : "Invalid Parameter type."
            });
        }
        
        /**
         * 160201 iamjunyoung.park:
         *   TODO: Implement model if else case
         *       86BH5C (maybe UHD model) must be width x height = 3840 x 2160
         *       Else   (maybe FHD model) must be width x height = 1920 x 1080
         * 160202 iamjunyoung.park:
         *   Check plaform added
         */
        checkPlatformVersion(function(platformInformation) {
            var BROWSER_WINDOW_WIDTH, BROWSER_WINDOW_HEIGHT;
            if (platformInformation.webOSVer === 3) {
                if (typeof failureCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "VSVT", "Video.setVideoViewTransform is not supported in WEBOS 3.0.");
                    failureCallback(result);

                    return;
                }            
            }
            
            if (platformInformation.webOSVer === 2 && platformInformation.chipset === 'H15') {
                BROWSER_WINDOW_WIDTH = 3840;
                BROWSER_WINDOW_HEIGHT = 2160;
            }
            else {
                BROWSER_WINDOW_WIDTH = 1920;
                BROWSER_WINDOW_HEIGHT = 1080;
            }
            
            service.Request("luna://com.webos.service.commercial.signage.storageservice/video/", {
                method: "getMediaID",
                onSuccess: function(ret) {
                    if (ret.returnValue === true) {
                        var mediaID = ret.id;
                        service.Request("luna://com.webos.service.tv.display/", {
                            method: "setCustomDisplayWindow",
                            parameters: {
                                context : mediaID, 
                                sourceInput : {
                                    positionX : 0, 
                                    positionY : 0, 
                                    width : BROWSER_WINDOW_WIDTH, 
                                    height : BROWSER_WINDOW_HEIGHT
                                }, 
                                displayOutput : {
                                    positionX : options.x, 
                                    positionY : options.y, 
                                    width : options.width, 
                                    height : options.height
                                }  
                            },
                            onSuccess: function(ret) {
                                if (ret.returnValue === true) {
                                    if (typeof successCallback === "function") {
                                        successCallback()
                                    }
                                }
                                else {
                                    delete ret.returnValue;
                                    if (typeof failureCallback === "function") {
                                        failureCallback({
                                            errorCode : "VSVT", 
                                            errorText : "Failed to set video transition"
                                        });
                                        
                                    }   
                                }
                            },
                            onFailure: function(ret) {
                                delete ret.returnValue;
                                if (typeof failureCallback === "function") {
                                    failureCallback({
                                        errorCode : "VSVVT", 
                                        errorText : "Failed to set video transition"
                                    });
                                }
                            }
                        });
                    }
                },
                onFailure: function(ret) {
                    delete ret.returnValue;
                    if (typeof failureCallback === "function") {
                        failureCallback({
                            errorCode : "VSVVT", 
                            errorText : "Cannot found video area"
                        });
                    }
                }
            });
        });
        
    };
    
    /*
     * 160125 iamjunyoung.park : setRotatedVideoTransform added
     */
    
    /**
     * Sets position and size of rotated video.<br>
     * <br>
     * Note :<br>
     * This feature is supported after setting of rotated video by setContentRotation.<br>
     * This API should be called after start of video playing and 2 sec delay to get mediaId of HTML video element.
     *   
     * @class Video
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options 
     * <br><image src="./image/setRoatedVideoTransform.png"><br>
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>x</th><th>String</th><th>Postion of x-axis in video</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>y</th><th>String</th><th>Postion of y-axis in video</th><th>required</th></tr>
     *       <tr><th>width</th><th>String</th><th>Width of size in video</th><th>required</th></tr>
     *       <tr class="odd"><tr><th>height</th><th>String</th><th>Height of size in video</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * 
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setRotatedVideoTransform() {
     *     var successCb = function (){
     *     // Do Something
     *     }
     * 
     *     var failureCb = function(cbObject){
     *         var errorCode = cbObject.errorCode;
     *         var errorText = cbObject.errorText;
     *         console.log ("Error Code [" + errorCode + "]: " + errorText);
     *     }
     * 	
     *     var video = new Video();
     * 
     *     video.setRotatedVideoTransform(successCb, failureCb, {
     *         //Portrait Standard
     *         x: 100,
     *         y: 120,
     *         width: 900,
     *         height: 600
     *     });
     * }
     * @since 1.0
     * @see
     * <a href="Video%23setContentRotation.html">Video.setContentRotation()</a><br>
     */
    Video.prototype.setRotatedVideoTransform = function(successCallback, failureCallback, options) {
        /**
         * 160202 iamjunyoung.park:
         *   Check plaform added
         */
        checkPlatformVersion(function(platformInformation) {
            var BROWSER_WINDOW_WIDTH, BROWSER_WINDOW_HEIGHT;
            if (platformInformation.webOSVer === 3) {
                if (typeof failureCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "VSRT", "Video.setRotatedVideoTransform is not supported in WEBOS 3.0.");
                    failureCallback(result);

                    return;
                }            
            }
            
            if (platformInformation.webOSVer === 2 && platformInformation.chipset === 'H15') {
                BROWSER_WINDOW_WIDTH = 3840;
                BROWSER_WINDOW_HEIGHT = 2160;
            }
            else {
                BROWSER_WINDOW_WIDTH = 1920;
                BROWSER_WINDOW_HEIGHT = 1080;
            }
        
            if (typeof options.x !== 'number' ||
                typeof options.y !== 'number' ||
                typeof options.width !== 'number' ||
                typeof options.height !== 'number' ) {
                failureCallback({
                    errorCode : "VSRVT",
                    errorText : "Invalid Parameter type."
                });
            }
            

            service.Request("luna://com.webos.service.commercial.signage.storageservice/video/", {
                method: "getContentRotation",
                onSuccess: function(rotated) {
                    var _x, _y, _w, _h;
                    
                    if (rotated.degree === "off") {
                        failureCallback({
                            errorCode : "VSRVT", 
                            errorText : "Content must be applied content rotation first."
                        });
                        return;
                    }
                    /**
                     *  Convert to portrait origin (1080 x 1920)
                     *      (0, 1920)                (0, 0) 
                     *           +-------------------+
                     *           |                   |
                     *           |    Degree = 90    |
                     *           |                   |
                     *           +-------------------+
                     *   (1080, 1920)              (1080, 0)
                     */
                    
                    else if (rotated.degree === "90") {
                        _x = BROWSER_WINDOW_WIDTH - (options.y + options.height),
                        _y = options.x,
                        _w = options.height,
                        _h = options.width;
                    }
                    /**
                     *       (0, 1080)           (1920, 1080) 
                     *           +-------------------+
                     *           |                   |
                     *           |    Degree = 270   |
                     *           |                   |
                     *           +-------------------+
                     *        (0, 0)              (0, 1920)
                     */
                    else if (rotated.degree === "270") {
                        _x = options.y,
                        _y = BROWSER_WINDOW_HEIGHT - (options.x + options.width),
                        _w = options.height,
                        _h = options.width;
                    }
                
                    service.Request("luna://com.webos.service.commercial.signage.storageservice/video/", {
                        method: "getMediaID",
                        onSuccess: function(ret) {
                            if (ret.returnValue === true) {
                                var mediaID = ret.id;
                                
                                /**
                                 * 160217 iamjunyoung.park : Add H15 case
                                 *                           Call setDisplayWindow instead of setRotateDisplayWindow
                                 */
                                if (platformInformation.webOSVer === 2 && platformInformation.chipset === 'H15') {
                                    service.Request("luna://com.webos.service.tv.display/", {
                                        method: "setDisplayWindow",
                                        parameters: {
                                            context : mediaID, 
                                            fullScreen: false,
                                            displayOutput : {
                                                positionX : _x, 
                                                positionY : _y, 
                                                width : _w, 
                                                height : _h
                                            }  
                                        },
                                        onSuccess: function(ret) {
                                            if (ret.returnValue === true) {
                                                if (typeof successCallback === "function") {
                                                    successCallback();
                                                }
                                            }
                                            else {
                                                delete ret.returnValue;
                                                if (typeof failureCallback === "function") {
                                                    failureCallback({
                                                        errorCode : "VSRVT", 
                                                        errorText : "Failed to set video transition"
                                                    });
                                                    
                                                }   
                                            }
                                        },
                                        onFailure: function(ret) {
                                            delete ret.returnValue;
                                            if (typeof failureCallback === "function") {
                                                failureCallback({
                                                    errorCode : "VSRVT", 
                                                    errorText : "Failed to set video transition: " + ret.errorText
                                                });
                                            }
                                        }
                                    });
                                }
                                else {
                                    service.Request("luna://com.webos.service.tv.display/", {
                                        method: "setRotateDisplayWindow",
                                        parameters: {
                                            context : mediaID, 
                                            fullScreen: false,
                                            displayOutput : {
                                                positionX : _x, 
                                                positionY : _y, 
                                                width : _w, 
                                                height : _h
                                            }  
                                        },
                                        onSuccess: function(ret) {
                                            if (ret.returnValue === true) {
                                                if (typeof successCallback === "function") {
                                                    successCallback();
                                                }
                                            }
                                            else {
                                                delete ret.returnValue;
                                                if (typeof failureCallback === "function") {
                                                    failureCallback({
                                                        errorCode : "VSRVT", 
                                                        errorText : "Failed to set video transition"
                                                    });
                                                    
                                                }   
                                            }
                                        },
                                        onFailure: function(ret) {
                                            delete ret.returnValue;
                                            if (typeof failureCallback === "function") {
                                                failureCallback({
                                                    errorCode : "VSRVT", 
                                                    errorText : "Failed to set video transition: " + ret.errorText
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        },
                        onFailure: function(ret) {
                            delete ret.returnValue;
                            if (typeof failureCallback === "function") {
                                failureCallback({
                                    errorCode : "VSRVT", 
                                    errorText : "Cannot found video area"
                                });
                            }
                        }
                    });
                },
                onFailure: function(err) {
                    if (typeof failureCallback === "function") {
                        failureCallback({
                            errorCode : "VSRVT",
                            errorText : "Cannot check content rotation."
                        });
                    }
                }
            });
        });
    }
    
    module.exports = Video;
});

Video = cordova.require('cordova/plugin/video'); // jshint ignore:line

