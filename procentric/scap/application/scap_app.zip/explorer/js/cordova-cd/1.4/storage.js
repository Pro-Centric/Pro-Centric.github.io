/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the FileManager API itself, and provides a global namespace for operating FileManager service.
 * FileManager will be used to manage files in internal memory.
 * 
 * To locate a resource for file system APIs, SCAP URI is used.
 * SCAP URI has following format.
 * 
 * @class
 */

cordova.define('cordova/plugin/storage', function (require, exports, module) { // jshint ignore:line
    var service;
    function log(msg) {
        //    console.log(msg);//will be removed // jshint ignore:line
    }
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    }
    else {
        service = {
            Request: function (uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue: false,
                        errorText: "PalmSystem Not Available. Cordova is not installed?"
                    });
                }
            }
        };
    }

    function isValidFileURI(uri) {
        if (uri) {
            // Length of URI should be less than 256
            if (uri.length > 256) {
                log("URI IS TOO LONG!!!!!!!! " + uri.length);
                return false;
            }
            else {
                // Only acceptable characters for filename is Alphanumeric and -_.
                var pathandhost = uri.substring(uri.indexOf("://") + "://".length);
                var path = pathandhost.substring(pathandhost.indexOf("/"));
                var regex = new RegExp(/^[a-zA-Z0-9-_\/\.]*$/g);
                var ret = regex.exec(path);
                if (ret) {
                    log("GOOD URI!!!!!!!! ");
                    return true;
                }
                else {
                    log("INVALID URI!!!!!!!! " + uri);
                    return false;
                }
            }
        }
        else {
            log("NO URI!!!!!!!! " + uri);
            return false;
        }

    }
	
	
	/**
	 * storage interface
	 */
    var Storage = function () {
    };

	/**
	 * @namespace Error
	 */
    Error.ERROR_CODE = {
        /**
         * There was an error while doing a file IO.
         * @since 1.3
         * @constant
         */
        IO_ERROR: "IO_ERROR",

        /**
         * There was an error while accessing external storage devices.
         * @since 1.3
         * @constant
         */
        DEVICE_ERROR: "DEVICE_ERROR",
        
        /**
         * The input parameter has error.
         * @since 1.3
         * @constant
         */
        BAD_PARAMETER: "BAD_PARAMETER",

        /**
         * The remote server returned error.
         * @since 1.3
         * @constant
         */
        SERVER_ERROR: "SERVER_ERROR",

        /**
         * The network has error connecting to the remote site.
         * @since 1.3
         * @constant
         */
        NETWORK_ERROR: "NETWORK_ERROR",

        /**
         * The signage monitor system had error while executing the command.
         * @since 1.3
         * @constant
         */
        SYSTEM_ERROR: "SYSTEM_ERROR",
    };
	
	/**
	 * <p>
	 * This section describes the SCAP URI to locate resources for the SCAP strorage APIs.
	 * SCAP URI follows the syntax of a standard URI. 	  
	 * </p>
	 * <p>
	 * Those restrictions are applied to the SCAP URI.
	 * <ul>
	 * <li> If the protocol for the URI is file://, then allowd charecter sets are [a-zA-Z0-9-._]</li>
	 * <li> URI cannot be longer than a 256 length string </li>
	 * </ul>
	 * </p>
	 * 
	 * Those are formats that are recognized by SCAP storage APIs.
	 * <p>
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr>
	 *       	<th>file://internal/</th>
	 *       	<th>
	 *       	Locate to a file in internal memory space. No directories or files should be included in the path beyond root path.<br>
	 * 		 	If the path to the file destination is not found, directories for the file path will be automatically created.<br>
	 * 		 	Maximum length for a pathname is 255.	
	 *       	<p>(note: ../ is not allowed in the file path. '*' and '?' are also not supported.)</p>
	 *       	</th>
	 *       </tr>
	 *       <tr class="odd">
	 *       	<th>file://usb:[index]/</th>
	 *       	<th>
	 *       	Locate to a file in USB storage device at USB port:[index]. A USB storage device should be connected to the port.<br>
	 *       	If the path to the file destination is not found, directories for the file path will be automatically created.<br>
	 * 		 	Maximum length for a pathname is 255.	
	 *       	<p>(note: ../ is not allowed in the file path. '*' and '?' are also not supported.)</p> 
	 *       	</th>
	 *       </tr>
	 *       <tr>
	 *       	<th>file://sdcard:[index]/</th>
	 *       	<th>
	 *       	Locate to a file in SD card device at SD card port:[index]. A SD card storage device should be connected to the port.<br>
	 *       	If the path to the file destination is not found, directories for the file path will be automatically created.<br>
	 * 		 	Maximum length for a pathname is 255.	
	 *       	<p>(note: ../ is not allowed in the file path. '*' and '?' are also not supported.)</p> 
	 *       	</th>
	 *       </tr>
	 *       <tr  class="odd">
	 *       	<th>http://, https://</th>
	 *       	<th>
	 *       	Locate to a file in remote location. The file is downloaded using HTTP GET protocol. 
	 *       	Secure connection using https protocol is also supported.
	 *       	</th>
	 *       </tr>
	 *       <tr>
	 *       	<th>
	 *       	ftp:// (FTP)<br>
	 *       	sftp:// (FTP with SSH file transfer protocol)<br>
	 *       	ftps:// (FTP over SSL/TLS)<br>
	 *       	</th>
	 *       	<th>
	 *       	Locate to a file from FTP server. sftp (FTP with SSH file transfer) and ftps (FTP with SSL/TLS) is also supported.</br>
	 *       	Additional security option may be defined for sftp and ftps.</br>
	 *       	User name, password should be part of the URI if needed. </br>
	 *       	ex) ftp://user:password@my.ftp.site:21/path/to/file.txt
	 *       	If port number is not defined in URI, port number will be 21 (ftp or ftps) or 22 (sftp). </br>
	 *       	If auth is not defined in URI, 'anonymous:anonymous@' will be used if protocol is ftp/ftps. </br>
	 *       	</th>
	 *       </tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * </p>
	 * 
	 * Note : Copied files can be accessed by local/USB application from the "./content" directory of the local/USB application</br>
	 * Note : Copied files can be accessed from local http file server.(http://127.0.0.1:9080/[copied_filename]) </br>
	 * Note : Files that are copied to USB storage can be accessed from the local http file server.(http://127.0.0.1:9080/external/usb/[usb_port]) </br>
	 * TIP : If DNS server is not set in the monitor, accessing local file server using 'localhost' can take a long time to load the resource.
	 * Use '127.0.0.1' instead.
	 * 
	 * @namespace Storage.SCAP_URI
	 * @typedef string
	 */
    Storage.SCAP_URI = ""; // 160127 iamjunyoung.park : Never used variable. Why it declared???
	
	/**
	 * Maximum buffer length for readFile/writeFile (10K)
	 * @constant
	 */
    Storage.MAX_BUFFER_LENGTH = 1024 * 10;

	/**
	 * @namespace Storage.AppMode
	 */
    Storage.AppMode = {
        /**
         * USB
         * @since 1.1
         * @constant
         */
        USB: "usb",
        /**
         * local
         * @since 1.1
         * @constant
         */
        LOCAL: "local"
    };
	
	/**
	 * <p>
	 * Downloads firmware from remote server using 'http' or 'https' protocol. 
	 * Before downloading, check the free storage size of the platform using Storage.getStorageInfo(). <br>
	 * Received firmware file will be deleted after upgrade is completed by calling Storage.upgradeFirmware(), which in turn results in monitor reboot. <br> 
	 * After reboot, stored firmware file will be deleted even if Storage.upgradeFirmware() was not called, so if wrong firmware file was downloaded, 
	 * just reboot the monitor without calling Storage.upgradeFirmware() to delete it.
	 * </p>
	 * 
	 * @example
	 * 
	 * function downloadFirmware() {
	 *    var successCb = function () { 
	 *      console.log("Download firmware is successful"); 
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = {
	 *       uri : "http://example.org/firmware.10-01.00.10_usb_V3_SECURED.epk"
	 *    };
	 *    
	 *    var storage = new Storage(); 
	 *    storage.downloadFirmware(successCb, failureCb, options);
	 *    
	 * }
	 * 
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object} options
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>uri</th><th>String</th><th>URI for the firmware(in http or https)</a></th><th>required</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText as parameters.
	 *            </p>
	 * @since 1.2
	 * @see
	 * <a href="Storage%23upgradeFirmware.html">Storage.upgradeFirmware()</a>, 
	 * <a href="Storage%23getFirmwareUpgradeStatus.html">Storage.getFirmwareUpgradeStatus()</a><br>
	 */
    Storage.prototype.downloadFirmware = function (successCallback, errorCallback, options) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "downloadFirmware",
            parameters: {
                uri: options.uri
            },
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    successCallback();
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Upgrades firmware using stored file which was downloaded by calling Storage.downloadFirmware(). 
	 * If upgrade is successful, the monitor will restart automatically. 
	 * 
	 * </p>
	 * 
	 * @example
	 * 
	 * function upgradeFirmware() {
	 *    var successCb = function () { 
	 *      console.log("firmware upgrade is successful"); 
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var storage = new Storage(); 
	 *    storage.upgradeFirmware(successCb, failureCb);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText as parameters.
	 *            </p>
	 * @since 1.2
	 * @see
	 * <a href="Storage%23downloadFirmware.html">Storage.downloadFirmware()</a>, <a href="Storage%23getFirmwareUpgradeStatus.html">Storage.getFirmwareUpgradeStatus()</a><br>
	 */
    Storage.prototype.upgradeFirmware = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "upgradeFirmware",
            parameters: {},
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    successCallback();
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Gets the status of firmware upgrading. 
	 * 
	 * </p>
	 * 
	 * @example
	 * 
	 * function getFirmwareUpgradeStatus() {
	 *    var successCb = function (cbObject) { 
	 *      console.log("status " + cbObject.status);
	 *      console.log("upgradeProgress " + cbObject.upgradeProgress); 
	 *      console.log("downloadProgress " + cbObject.downloadProgress);
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var storage = new Storage(); 
	 *    storage.getFirmwareUpgradeStatus(successCb, failureCb);
	 * 
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @return {Object} 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
     *       <tr><th>status</th><th>String</th><th>idle | downloading | ready | in progress | completed | fail</a></th></tr>
     *       <tr class="odd"><th>downloadProgress</th><th>Number</th><th> 0 ~ 100 </a></th></tr>
     *       <th>upgradeProgress</th><th>Number</th><th> 0 ~ 100 </a></th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @since 1.2
	 * @see
	 * <a href="Storage%23downloadFirmware.html">Storage.downloadFirmware()</a>, 
	 * <a href="Storage%23upgradeFirmware.html">Storage.upgradeFirmware()</a></br>
	 */
    Storage.prototype.getFirmwareUpgradeStatus = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "getFirmwareUpgradeStatus",
            parameters: {},
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    successCallback({
                        status: result.status,
                        upgradeProgress: result.upgradeProgress,
                        downloadProgress: result.downloadProgress
                    });
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Changes monitor logo image. Image can be loaded from internal|USB memory, or retrieved from remote server using 'http' or 'https'.
	 * Logo image has following restrictions :  <br>
	 *  - format : JPG or BMP <br>
	 *  - max resolution : 1920x1080 <br>
	 *  - max file size : 8 Mbytes for BMP <br>
	 * </p>
	 * 
	 * @example
	 * 
	 * function changeLogoImage() {
	 *    var successCb = function () { 
	 *      console.log("Upgrading logo image is successful"); 
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = {
	 *       uri : "http://example.org/myImage.jpg"
	 *    };
	 * 
	 *    var storage = new Storage(); 
	 *    storage.changeLogoImage(successCb, failureCb, options);
	 * 
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object} options
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>uri</th><th>String</th><th>URI for the logo image(http, https, file://internal or file://usb:[index])</a></th><th>required</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText as parameters.
	 *            </p>
	 * @since 1.2
	 * @see
	 * <a href="Storage%23upgradeFirmware.html">Storage.upgradeFirmware()</a><br>
	 */
    Storage.prototype.changeLogoImage = function (successCallback, errorCallback, options) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "changeLogoImage",
            parameters: {
                uri: options.uri
            },
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    successCallback();
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Upgrades application stored in local or USB using the one from remote server. 
	 * Remote server information(serverIP and serverPort) is set in display menu.<br>
	 * New application will be launched at next boot time and old application will be deleted at the same time. 
	 * Application on the server should be at <br> 
	 * "http://serverIP:serverPort/procentric/scap/application/scap_app.zip".
	 * <br>
	 * Note : Size of scap_app.zip (zip file itself and extracted files) should not exceed free storage size of the platform.<br>
	 * When application is being upgraded, following files exist at the same time : <br>
	 *    - old application <br>
	 *    - downloaded scap_app.zip <br> 
	 *    - content data stored by storage.copyFile() API and <br> 
	 *    - new application extracted from the downloaded scap_app.zip <br>
	 * So before upgrading the application, call storage.getStorageInfo() and check the free storage size. <br>
	 * <br>
	 * Note : Application should not include 'content' directory under application's root folder. <br>
	 * (It is reserved for Storage.copyFile() API.)
	 * 
	 * </p>
	 * 
	 * @example
	 * 
	 * function upgradeApplication() {
	 *    var successCb = function (cbObject) { 
	 *      console.log("Application Update successful"); 
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = {
	 *       to : Storage.AppMode.USB,
	 *       recovery : false
	 *    };   
	 *    
	 *    var storage = new Storage(); 
	 *    storage.upgradeApplication(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object} options
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>to</th><th>String</th><th><a href="Storage.AppMode.html#constructor">Storage.AppMode</a></th><th>required</th></tr>
	 *       <tr class="odd"><tr><th>recovery</th><th>Boolean</th><th>true : Recover old application if there was an error during upgrade. Default value.<br>
	 *       false : Remove old application to obtain free storage space.</a></th><th>optional</th></tr>
	 *       
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            </p>
	 * @since 1.0
	 * @since 1.1 options.to options.recovery added
	 * @see
	 * <a href="Storage%23removeApplication.html">Storage.removeApplication()</a><br>
	 */
    Storage.prototype.upgradeApplication = function (successCallback, errorCallback, options) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "upgradeApplication",
            parameters: {
                from: 'remote',
                to: (options === undefined || options === null ? Storage.AppMode.LOCAL : options.to),
                recovery: (options === undefined || options === null ? false : options.recovery)
            },
            onSuccess: function (result) {
                if (result.returnValue === true) {
					/**  requested by kyungyoon min
                     * - Innova issue - After download scap_app.zip or com.lg.app.signage.ipk file
                     *                  perfectly complete, call successCallback such as reboot
                     *                  Otherwise, after rebooting, it may be malfunction
                     *                  such as Network Error 203 (Zip is crashed)
                     */
                    setTimeout(function () {
                        successCallback();
                    }, 3000);
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });

    };

	/**
	 * <p>
	 * Removes application stored in local or USB storage.<br>
	 * 
	 * Current running application can't remove itself using this API.<br>
	 * (e.g. Application running from USB cannot remove itself using this API)
	 * 
	 * </p>
	 * 
	 * @example
	 * 
	 * function removeApplication() {
	 *    var successCb = function (cbObject) { 
	 *      console.log("Application removes successfully"); 
	 *    };
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = { 
	 *       to : Storage.AppMode.LOCAL
	 *    };   
	 *     
	 *    var storage = new Storage(); 
	 *    storage.removeApplication(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object} options
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>to</th><th>String</th><th><a href="Storage.AppMode.html#constructor">Storage.AppMode</a></th><th>required</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            </p>
	 * @since 1.1
	 * @see
	 * <a href="Storage%23upgradeApplication.html">Storage.upgradeApplication()</a><br>
	 */

    Storage.prototype.removeApplication = function (successCallback, errorCallback, options) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "removeApplication",
            parameters: {
                to: options.to
            },
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    successCallback();
                } else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };


	/**
	 * <p>
	 * Copies file.
	 * File can be copied from internal, external memory, or remote site to internal, external memory, or a remote FTP site.</br>
	 * </p>
	 * 
	 * @example 
	 * 
	 * function copyFile() {
	 *    var successCb = function (){
	 *      console.log("Copying File done.");
	 *    };
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    // Copy local file in internal memory to another location in internal memory.
	 *    var options_local_to_local = { 
	 *      source: 'file://internal/copy_me.txt',
	 *      destination : 'file://internal/copy/to/here.txt'
	 *    };
	 * 
	 *    var storage = new Storage();
	 *    storage.copyFile(successCb, failureCb, options_local_to_local);
	 * 
	 *    // Copy remote file to internal memory.
	 *    // Then set the file as he source for an image tag.
	 *    var options_remote_to_local = { 
	 *      source : 'http://remote.file.site/copy_me.txt',
	 *      destination : 'file://internal/copy/to/here.txt'
	 *    }; 
	 * 
	 *    storage.copyFile(successCb, failureCb, options_remote_to_local);
	 *          
	 *    // Copy file from USB memory at port 1 to internal memory.
	 *    var options_usb_to_local = { 
	 *      source : 'file://usb:1/from/copy_me.txt',
	 *      destination : 'file://internal/copy/to/here.txt'
	 *    };
	 * 
	 *    storage.copyFile(
	 *      function() {	// Success Call back. Set the copied file as image source.
	 *         var imgElement = document.getElementById('myImage');
	 *         imgElement.src = 'http://127.0.0.1:9080/copy/to/here.jpg';
	 *      },
	 *      failureCb, options_usb_to_local);
	 * 
	 *    // download remote file and copy to USB storage at port 1.
	 *    // Then set the file as he source for an image tag.
	 *    var options_remote_to_usb = { 
	 *      source : 'http://remote.file.site/copy_me.jpg',
	 *      destination : 'file://usb:1/copy/to/here.jpg'
	 *    };
	 * 
	 *    storage.copyFile(
	 *      function() {	// Success Call back. Set the copied file as image source.
	 *         var imgElement = document.getElementById('myImage');
	 *         imgElement.src = 'http://127.0.0.1:9080/external/usb/1/copy/to/here.jpg';
	 *      },
	 *      failureCb, options_remote_to_usb);
	 * 
	 * 
	 *    // Copy file from redirected server.
	 *    var options_redirect = { 
	 *      source : 'http://remote.site.that.will.redirect/copy_me.txt',
	 *      destination : 'file://usb:1/copy/to/here.txt',
	 *      maxRedirection: 5
	 *    };
	 * 
	 *    storage.copyFile(successCb, failureCb, options_redirect);
	 *    
	 *    // Copy file from ftp server.
	 *    var options_ftp = { 
	 *      source : 'ftp://user:password@remote.ftp.site/copy_me.txt',
	 *      destination : 'file://internal/copy/to/here.txt',
	 *    };
	 * 
	 *    storage.copyFile(successCb, failureCb, options_ftp);
	 *    
	 *    // Copy internal file to  ftp server.
	 *    var options_ftp2 = { 
	 *      source : 'file://internal/send/me/away.txt',
	 *      destination : 'ftp://user:password@remote.ftp.site/sent.txt',
	 *    };
	 * 
	 *    storage.copyFile(successCb, failureCb, options_ftp2);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>source</th><th>{@link Storage.SCAP_URI}</th><th>URI to the source file</a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>destination</th><th>{@link Storage.SCAP_URI}</th><th>URI to the destination file. </a></th><th>required</th></tr>
     *       <th>ftpOption</th><th>Object</th><th>FTP/SFTP options. Additional options for FTP setting.</th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>ftpOption.secureOptions</th><th>Object</th><th>secure FTP options</a></th><th>optional</th></tr>
     *       <th>ftpOption.secureOptions.privateKey</th><th>String</th><th>Private key for either key-based or hostbased user authentication (OpenSSH format)</a></th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>ftpOption.secureOptions.passphrase</th><th>String</th><th>For an encrypted private key, this is the passphrase used to decrypt it</a></th><th>optional</th></tr>
     *       <th>ftpOption.connTimeout</th><th>Number</th><th>How long (in milliseconds) to wait for the control connection to be established (default : 10000 ms)</a></th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>ftpOption.pasvTimeout</th><th>Number</th><th>How long (in milliseconds) to wait for a PASV data connection to be established (default : 10000 ms)</a></th><th>optional</th></tr>
     *       <th>ftpOption.keepalive</th><th>Number</th><th>How often (in milliseconds) to send a 'dummy'(NOOP) command to keep the connection alive (default : 10000 ms)</a></th><th>optional</th></tr>       
     *       <tr class="odd"><th>httpOption</th><th>Object</th><th>HTTP/HTTPS file copy options</th><th>optional</th></tr>
     *       <th>httpOption.maxRedirection</th><th>Number</th><th>Maximum number of allowed redirections.</br> 
     *       Default value is 0, which means no redirection is allowed.</br>Request will be redirected if the response code was 301,
     *       302,303, or 307 and a valid location was found in the response header. </br> 
     *       This option is ignored if the source file is not a remote file. Maximum number of redirection is 5.</th><th>optional</th></tr>       
     *       <tr class="odd"><tr><th>httpOption.headers</th><th>Object</th>
     *       <th>The [name : value] pairs that will be included in the HTTP request header, for remote file request. </br>
     *       This header data will be cascaded during redirection. </br> 
     *       Maximum size of header data that can be contained is 1KB. </br> 
     *       </a></th><th>optional</th></tr>
     *       <tr><th>httpOption.timeout</th><th>Number</th>
     *       <th> Milliseconds before the underlying TCP connection times out. 0 is for no time out. Default value is 0.</br>
     *       Note that if there is a server side timeout, copy file can timeout before the timeout value set by this option.
     *       </th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText. </br>
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.0 
	 * @since 1.1 access to local file from remote application
	 * @since 1.2 options.maxRedirection
	 * @since 1.3 options.ftpOption
	 * @since 1.3 options.maxRedirection moves to options.httpOption.maxRedirection
	 * @since 1.3 options.httpOption.headers
	 * @since 1.3 options.httpOption.timeout
	 */
    Storage.prototype.copyFile = function (successCallback, errorCallback, options) {

        log("Options: " + JSON.stringify(options, null, 3));

        /**
         *  160127 iamjunyoung.park : Below isValidFileURI step must not be operated
         *                            because many HTTP URLs use ?, &, #, etc
         *                            for passing parameters to server using GET method.
         */
		/* requested by park jun young
		if(!(options && isValidFileURI(options.destination) && isValidFileURI(options.source))){
			log("Bad options URI NOT VALID" );
			errorCallback({errorCode:"BAD_PARAMETER", errorText:JSON.stringify(options, null, 3)});
			return;
		}
		*/

        if (options.maxRedirection && options.maxRedirection > 5) {
            log("Bad options TOO MANY REDIRECTION");
            errorCallback({ errorCode: "BAD_PARAMETER", errorText: "Redirect cannot be more that 5" });
            return;
        }
        if (options.headers && JSON.stringify(options.headers).length > 1024) {
            log("header too long header too long");
            errorCallback({ errorCode: "BAD_PARAMETER", errorText: "Header data cannot be bigger than 1K" });
            return;
        }

        if (typeof options.httpOption === 'undefined') {
            options.httpOption = {};
        }

        if (options.httpOption.headers && JSON.stringify(options.httpOption.headers).length > 1024) {
            log("header too long header too long");
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "Header data cannot be bigger than 1K"
            });
            return;
        }
		
        // For backward compatibility with older
        /**
         * 160127 iamjunyoung.park : Below code CANNOT have backward compatibility, error is occured
         *                           if library use SCAP v1.3, and firmware support SCAP v1.2 only,
         *                           and user use copyFile() using options that SCAP v1.3 structure.
         * 
         *                           Example case: 
         *                              options.httpOptions.maxRedirection = 5;
         *                              But in storageservice (SCAP v1.2), cannot detect options.maxRedirection.
         *                              storageservice can detect options.maxRedirection instead.
         *                              So it cannot redirect.
         */
        if (options.maxRedirection || options.headers) {
            if (options.maxRedirection && typeof options.httpOption.maxRedirection === 'undefined') {
                options.httpOption.maxRedirection = options.maxRedirection;
            }
            if (options.headers && typeof options.httpOption.headers === 'undefined') {
                options.httpOption.headers = options.headers;
            }
        }
        
        // 160127 iamjunyoung.park : Add backward compatibality code start
        if (typeof options.httpOption.maxRedirection !== 'undefined') {
            if (typeof options.maxRedirection !== 'undefined') {
                if (options.httpOption.maxRedirection !== options.maxRedirection) {
                    // What do you want that use maxRedirection? Both values are different.
                    errorCallback({
                        errorCode: "BAD_PARAMETER",
                        errorText: "Both options.httpOption.maxRedirection and options.maxRedirection are exists,"
                        + "but different value. What value you want to use?"
                    });
                    return;
                }
            }
            else
                options.maxRedirection = options.httpOption.maxRedirection;
        }
        // 160127 iamjunyoung.park : Add backward compatibality code end
		
        log(options); // 160127 iamjunyoung.park : Change console.log to log
			
        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "fs/copyFile",
            parameters: {
                dest: options.destination,
                src: options.source,
                ftpOption: options.ftpOption,
                httpOption: options.httpOption
            },
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    log("SUCCESS");
                    successCallback();
                }
                else {
                    log("Err: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("Err: " + result.errorText);
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Removes file in internal or external storage.
	 * Target path is described in URI form. 
	 * </p>
	 * If the target path is a file, it will be removed.</br>
	 * If the target path is a directory, the directory will be removed.</br>
	 * If 'recursive' parameter is 'true', any file or directory in the target directory will be removed.</br>
	 * If 'recursive' parameter is 'false', operation will fail if there is any file in that directory.</br>
	 * <p>
	 * file://internal/external, file://usb:[index]/content are predefined directory for special use, and cannot be removed. 
	 * </p>
	 * 
	 * @example 
	 * 
	 * function removeFile() {
	 *    var successCb = function (){
	 *      console.log("Removing File done.");
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 
	 *    //delete a file
	 *    var options = { 
	 *      file: 'file://internal/delete_me.txt',
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.removeFile(successCb, failureCb, options);
	 * 
	 *    //delete a directory and contents in it
	 *    var options = { 
	 *      file: 'file://internal/delete/this/directory/',
	 *      recursive : true
	 *    }; 
	 * 
	 *    storage.removeFile(successCb, failureCb, options);
	 * 
	 *    //delete a directory, only if it's empty
	 *    var options = { 
	 *      file: 'file://internal/empty/directory/',
	 *      recursive : false
	 *    }; 
	 * 
	 *    storage.removeFile(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>file</th><th>{@link Storage.SCAP_URI}</th><th>URI to the file to delete</a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>recursive</th><th>Boolean</th><th>only meaningful when removing a directory. Default value is 'false'.</br>
     *           If true, the directory and all contents in it will be removed.</br>
     *           If false, removing the directory will fail if it is not empty. 
     *            </a></th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
	 * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.0 1.1 options.recursive
	 */
    Storage.prototype.removeFile = function (successCallback, errorCallback, options) {

        if (!(options && isValidFileURI(options.file))) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.file is a mandatory parameter"
            });
            return;
        }
        var param = {
            file: options.file
        };
        if (options.recursive === true) {
            param.recursive = true;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "fs/removeFile",
            parameters: param,
            onSuccess: function (result) {

                log("onSuccess");

                if (result.returnValue === true) {
                    successCallback();
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("onFailure");
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Lists files in a directory stored in external or internal memory. 
	 * Directory location is in URI format. 
	 * Listing a directory beyond the application root path is not allowed.
	 * </p>
	 * 
	 * @example 
	 * 
	 * function listFiles() {
	 * 
	 *    var successCb = function (cbObject){
	 *      var files = cbObject.files;
	 *      for(var i = 0 ; i < files.length; ++i){
	 *         var fileInfo = files[i];	
	 *         console.log("File Name: " + fileInfo.name);
	 *         console.log("File Type: " + fileInfo.type);
	 *         console.log("File Size: " + fileInfo.size);
	 *      }
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    // List files in the internal memory
	 *    var listOption = { 
	 *      path: "file://internal/list/this/dir"
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.listFiles(successCb, failureCb, listOption);
	 *          
	 *    // List files in the mass storage device in USB port 1.
	 *    var listOption = { 
	 *      path: "file://usb:1/list/this/dir"
	 *    }; 
	 * 
	 *    storage.listFiles(successCb, failureCb, listOption);
	 * 
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the directory to look for.</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with total count and an array of file info, which contains a list of File Info Object.
	 *            '.' and '..' will not be included in the list.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
     *       <tr><th>totalCount</th><th>Number</th>
     *       <th>Number of items</th>
     *       </tr>
	 *       <tr><th>files</th><th>Array</th>
	 *       <th>List of files in the directory. File Info has following properties.</th>
	 *       </tr>
     *      
	 *       <tr><th>files.name</th><th>String</th>
	 *       <th>Name of the file</th>
	 *       </tr>
	 *       
	 *       <tr><th>files.type</th><th>String</th>
	 *       <th>Type of the file</th>
	 *       </tr>
	 *       
	 *       <tr><th>files.size</th><th>Number</th>
	 *       <th>Size of the File</th>
	 *       </tr>
	 *       
	 *	</tbody>
	 * </table>
	 * </div>
	 *            </p>
	 *            <p>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 *            
	 * @since 1.0
	 * @since 1.1 list a directory
	 */
    Storage.prototype.listFiles = function (successCallback, errorCallback, options) {
        var param = {};

        if (options && options.path) {
            if (isValidFileURI(options.path)) {
                param.pathURI = options.path;
            }
            else {
                errorCallback({
                    errorCode: "BAD_PARAMETER",
                    errorText: "File URI is not valid."
                });
                return;
            }
        }
        else {
            param.pathURI = "file://internal/";
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
            method: "fs/listFiles",
            parameters: param,
            onSuccess: function (result) {
                if (result.returnValue === true) {
                    var files = [];
                    for (var i = 0; i < result.files.length; ++i) {
                        log(result.files[i]);
                        var fileinfo = {
                            name: result.files[i].name,
                            type: (result.files[i].type === 'folder') ? 'folder' : 'file',
                            size: result.files[i].size
                        };
                        files.push(fileinfo);
                    }

                    var cbObj = {
                        files: files,
                        totalCount: result.totalCount
                    };
                    successCallback(cbObj);
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Gets internal memory status.
	 * Returns free space and total space, in kilobytes.
	 * If any external storage device is connected, the storage info for that device will be returned as well.
	 * </p>
	 * 
	 * @example 
	 * 
	 * function getStorageInfo() {
	 *    var successCb = function (cbObject){
	 *      var free = cbObject.free;
	 *      var total = cbObject.total;
	 *      var used = cbObject.used;
	 *      var externals = cbObject.externalMemory;
	 *  	   
	 *      console.log( "Total: " + total + "kilobytes"); 
	 *      console.log( "Free: " + free + "kilobytes");
	 *      console.log( "Used: " + used + "kilobytes"); 
	 *
	 *      for(var uri in externals){
	 *         var external = externals[uri];
	 *         console.log("base uri: " + uri);		// ex) usb:1
	 *         console.log("Free: " + external.free);
	 *         console.log("Used: " + external.used);
	 *         console.log("Total: " + external.total);
	 *      }
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var storage = new Storage();
	 *    storage.getStorageInfo(successCb, failureCb);
	 *          
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with free and total space.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>free</th><th>Number</th>
	 *       <th>
	 *       Free space in internal memory, in KB.
	 *       </th>
	 *       </tr>
	 *       <tr><th>total</th><th>Number</th>
	 *       <th>
	 *       Total space in internal memory, in KB.
	 *       </th>
	 *       </tr>
	 *       <tr><th>used</th><th>Number</th>
	 *       <th>
	 *       Used space in internal memory, in KB.
	 *       </th>
	 *       </tr>
	 *       <tr><th>externalMemory</th><th>Array</th>
	 *       <th>
	 *       <p>
	 *       List of external memory connected to the device (ex.usb:1). Optional.
	 *       </p>
	 *       <p>Each external memory item is a JSON object containing following fields. </p>
	 *      <table align="center" class="hcap_spec" width=400>
	 *   		<thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   	    <tbody>
	 *   	 	<tr><th>free</th><th>Number</th><th>Free space in the external memory, in KB.</th></tr>
	 *   	 	<tr><th>used</th><th>Number</th><th>Used space in the external memory, in KB.</th></tr>
	 *   	 	<tr><th>total</th><th>Number</th><th>Total space in the external memory, in KB.</th></tr>
	 *          </tbody>
	 *      </table>
	 *       </th>
	 *       </tr>	 
	 *    </tbody>
	 * </table>
	 * </div>
	 *            </p>
	 *            <p>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.0
	 * @since 1.1 USB storage information
	 * @since 1.3 SDCard storage information
	 */
    Storage.prototype.getStorageInfo = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "fs/storageInfo",
            parameters: {},
            onSuccess: function (result) {
                log("returned : " + JSON.stringify(result, null, 3));
                if (result.returnValue === true) {
                    log("returned : " + JSON.stringify(result, null, 3));
                    var cbObj = {
                        free: result.spaceInfo.freeSize,
                        total: result.spaceInfo.totalSize,
                        used: result.spaceInfo.usedSize,
                        externalMemory: result.externalStorage
                    };
                    successCallback(cbObj);
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Creates a directory.
	 * The path should be described in URI format.
	 * If the URI is for external memory, external storage device should be connected to the external memory port with proper permission.
	 * The directory will be created recursively.
	 * </p>
	 * 
	 * @example 
	 * 
	 * function mkdir() {
	 *    var successCb = function (){
	 *      console.log( "directory created successfully"); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    // The directory will be created recursively.
	 *    var mkdirOption = { 
	 *      path: "file://internal/create/this/directory"
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.mkdir(successCb, failureCb, mkdirOption);
	 * 
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the directory to create. </a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.1
	 */
    Storage.prototype.mkdir = function (successCallback, errorCallback, options) {
        if (!(options && isValidFileURI(options.path))) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
            return;
        }
        var param = {
            pathURI: options.path
        };

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "fs/mkdir",
            parameters: param,
            onSuccess: function (result) {

                log("onSuccess");

                if (result.returnValue === true) {
                    successCallback();
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("onFailure");
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Checks if the given file exists or not.
	 * The path should be in URI format.
	 * If the URI is for external memory, external storage device must be connected to the external memory port with proper permission.
	 * </p>
	 * 
	 * @example 
	 * 
	 * function exists() {
	 *    var successCb = function (cbObject){
	 *      var exists = cbObject.exists;
	 *      console.log( "The file exists: " + exists); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var existsOption = { 
	 *      path: "file://internal/to/be/or/not/to/be"
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.exists(successCb, failureCb, existsOption);
	 * 
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the resource (internal/usb/sdcard).</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with a boolean attribute 'exists', which is true if the file exists and false otherwise.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.1
	 */
    Storage.prototype.exists = function (successCallback, errorCallback, options) {

        if (!(options && isValidFileURI(options.path))) {
            log("BAD_PARAMETER");

            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
            return;
        }
        var param = {
            pathURI: options.path
        };

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "fs/exists",
            parameters: param,
            onSuccess: function (result) {

                log("onSuccess");

                if (result.returnValue === true) {
                    log("returned : " + JSON.stringify(result, null, 3));
                    var cbObj = {
                        exists: result.exists
                    };
                    successCallback(cbObj);
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("onFailure");
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
	 * <p>
	 * Reads from a file.<br>
	 * It is designed to read a small data file from filesystem (not suited for a big data file).
	 * </p>
	 * <p>
	 * Note : For reading a big chunk of data, it is recommended to use AJAX with local file.
	 * </p>
	 * @example
	 * 
	 * function readFile() {
	 *    // This example will read a file as binary.
	 *    
	 *    var successCb = function (cbObject){
	 *      // If file is read as binary, array of uint8 will be returned. 
	 *      // Create an image element, and set the source as the binary data.
	 *      
	 *      var binary_data = cbObject.data;
	 *      var data_base64 = bin_array_to_base64(binary_data);
	 *      var ele = document.createElement('img');
	 *      ele.src = "data:image/jpeg;base64, " + data_base64;
	 *      document.body.appendChild(ele); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *     // Read file from the start, read the whole file, and read as binary
	 *    var options = { 
	 *      path: "file://internal/image.jpg",
	 *      position : 0,
	 *      encoding: 'binary'
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.readFile(successCb, failureCb, options);
	 * 
	 * 
	 *    // This example will read file as text.
	 *    var successCb = function (cbObject){
	 *      // If file is read as text, utf encoded string will be returned.
	 *      // Create an image element, and set the source as the binary data.
	 *   
	 *      var data_text = cbObject.data;
	 *      var ele = document.createElement('div');
	 *      ele.innerHTML = "Text is read: " + data_text;
	 *      document.body.appendChild(ele); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    // Read file from the start, read the whole file, and read as text.
	 *    var options = { 
	 *      path : "file://internal/text.txt",
	 *      position : 0,
	 *      encoding: 'utf8'
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.readFile(successCb, failureCb, options);
	 * 
	 * }
	 *
	 * @example 
	 *  // This is a recommended way of reading a big chunk of data from file with JQuery Ajax.
	 *  // Reading a data chunk bigger than 50MB is not recommended because it can lead to memory overflow (depends on system).
	 *  function readFileAjax(){
	 *  	$.ajax({
	 *  		url: "http://127.0.0.1:9080/chunk.data"
	 *  	})
	 *  	.fail(function(err){
	 *  		// Handle error.
	 *  	})
	 *  	.done(function(data){
	 *  		// Handle the data.
	 *  	});
	 *  } 
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the resource (internal/usb/sdcard). </a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>position</th><th>Number</th><th>Position where this file will be read from. Default value is 0.</br> 
     *       If the value of the position parameter is out of the range of the input file, error will be returned.</a></th><th>optional</th></tr>
     *       <tr><th>length</th><th>Number</th><th>The length of the Read buffer. Maximum length of the buffer that can be read is currently 10KB. </br> 
     *            Default value is 10KB. </br>If the size of the file intended to be read is smaller than the length parameter, 
     *            return data will include the contents of the file.</a></th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>encoding</th><th>String</th><th>Encoding method to be used for return value. </br>
     *            Default value is 'utf8'. Value of encoding can be:</br>
     *            'utf8' : Encoded as UTF-8. Return value will be a string.</br>
     *            'base64' : Encoded as base64. Return value will be a string.</br>
     *            'binary' : Raw binary data. Return value will be an ArrayBuffer.</br></a></th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
	 * @returns
	 *            <p> 
	 *            A string containing the file data with given encoding will be returned ('utf8', 'base64').</br>
	 *            If the encoding is 'binary', an ArrayBuffer will be returned.</br>
	 *            </p>
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with file data.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.readFile = function (successCallback, errorCallback, options) {
        if (!options) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.path)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (options.length && (options.length > Storage.MAX_BUFFER_LENGTH || options.length < 1)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "length should be > 0 and < " + Storage.MAX_BUFFER_LENGTH
            });
        }
        else if (options.position && (options.position < 0)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "position should be > 0"
            });
        }
        else {
            var params = {};

            params.path = options.path;
            params.length = options.length ? options.length : Storage.MAX_BUFFER_LENGTH;
            params.position = options.position ? options.position : 0;
            params.encoding = options.encoding ? options.encoding : 'utf-8';

            service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                method: "fs/readFile",
                parameters: params,
                onSuccess: function (result) {
                    if (result.returnValue) {
                        if (params.encoding === 'binary') {
                            // Read as binary so return as ArrayBuffer.
                            // Returned data is a array of byte.
                            var byteArray = result.data;
                            var arrayView = new Uint8Array(byteArray.length);
                            for (var i = 0; i < byteArray.length; ++i) {
                                arrayView[i] = byteArray[i];
                            }
                            successCallback({
                                data: arrayView.buffer
                            });
                        }
                        else {
                            // return as a string
                            successCallback({
                                data: result.data
                            });
                        }
                    }
                    else {
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                },
                onFailure: function (result) {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            });
        }
    };

	/**
	 * 
	 * Writes file
	 * 
	 * @example 
	 *   
	 * function writeFile() {
	 *    // This example will write binary data to file.
	 *   
	 *    var successCb = function (cbObject){
	 *      console.log( "Successfully writen " + cbObject.written + " bytes" ); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 
	 *    //Read a file as binary with an ajax call.
	 *    var oReq = new XMLHttpRequest();
	 *    oReq.open("GET", '/my_file.data', true);
	 *    oReq.responseType = "arraybuffer";
	 *    oReq.onload = function (oEvent) {
	 *       var arrayBuffer = oReq.response; // Note: not oReq.responseText
	 * 
	 *      if (arrayBuffer) {
	 *         var uint8View =  new Int8Array(arrayBuffer);
	 *         var array = [];
	 *         for(var i=0;i < uint8View.length;++i) {
	 *            array[i] = uint8View[i];
	 *         }
	 * 	
	 *         // write data from the start, read the whole data, and write as binary
	 *         var options = {
	 *            data: array,
	 *            path: 'file://internal/data.dat',
	 *            position : 0,
	 *            mode :'truncate',
	 *            offset:0,
	 *            length : array.length,
	 *            encoding: 'binary'
	 *         }; 
	 * 
	 *         var storage = new Storage();
	 *         storage.writeFile(successCb, failureCb, options);
	 *      }
	 *    };
	 * 
	 *    oReq.send(null);
	 *    // This example will write text data to a file.
	 *   
	 *    var successCb = function (cbObject){
	 *      console.log( "Successfully writen " + cbObject.written + " bytes" ); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject) { 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *     // write Text data, use utf-8 encoding, write all text.
	 *    var textData = "Hello SCAP!!!!!"; 
	 *    var options = { 
	 *      data: textData,
	 *      path: 'file://internal/text.txt',
	 *      position : 0,
	 *      mode :'truncate',
	 *      offset:0,
	 *      length : textData.length,
	 *      encoding: 'utf8'
	 *    }; 
	 *
	 *    var storage = new Storage();
	 *    storage.writeFile(successCb, failureCb, options);
	 * 
	 * }
	 *          
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the resource (internal/usb/sdcard).</a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>data</th><th>ArrayBuffer|String</th><th>Data to write to the file. Data type should be ArrayBuffer if encoding is 'binary' or string otherwise.</a></th><th>required</th></tr>
     *       <tr><th>mode</th><th>String</th><th>Write mode. Default is 'truncate'.</br>
     *            'truncate' : Truncate the file and start writing on it. File will be created if it doesn't exist. </br>
     *            'append'   : Append to the file. File will be created if it doesn't exist. </br>
     *            'position' : Write from the position given by option.position. File must exist for this mode. </br> </a></th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>position</th><th>Number</th><th>Position where this file will be written. Default value is 0. This option is valid only if mode is 'position'.</br> 
     *       If position is bigger than the existing file for positional write, the gap between the file contents and write position will be filled with '\00' character.</a></th><th>optional</th></tr>
     *       <tr><th>length</th><th>Number</th><th>Write buffer length in bytes. Maximum buffer size is 10KB. </br>Default value is data.length, 
     *       or 10KB if data.length-offset > 10KB.</a></th><th>optional</th></tr>
     *       <tr class="odd"><tr><th>encoding</th><th>String</th><th>Encoding to be applied to input data. Default value is 'utf8'.</br>
     *            'utf8' : input data is encoded as UTF-8. options.data should be a string.</br>
     *            'base64' : input data is encoded as base64. options.data should be a string.</br>
     *            'binary' : input data is encoded as raw binary. options.data should be an ArrayBuffer.</br></a></th><th>optional</th></tr>
     *       <tr><th>offset</th><th>Number</th><th>Offset from buffer. Default value is 0. If offset+length > data.length, error will be returned.</a></th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with the number of bytes written.</br>
	 *            The number of bytes written may be more than the length of the actual data. </br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.writeFile = function (successCallback, errorCallback, options) {
        if (!options) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.path)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a is not valid"
            });
        }
        else if (!options.data) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.data is a mandatory parameter"
            });
        }
        else if (options.mode && (options.mode !== 'truncate' && options.mode !== 'append' && options.mode !== 'position')) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "mode should be 'truncate'|'append'|'position'"
            });
        }
        else if (options.position && (options.position < 0)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "position should be > 0"
            });
        }
        else if (options.offset && (options.offset < 0)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "offset should be > 0"
            });
        }
        else if (options.length && (options.length > Storage.MAX_BUFFER_LENGTH || options.length < 1)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "length should be > 0 and < " + Storage.MAX_BUFFER_LENGTH
            });
        }
        else if (options.encoding && (options.encoding !== 'utf8' && options.encoding !== 'binary' && options.encoding !== 'base64')) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "Invalid encoding: " + options.encoding
            });
        }

        else {
            log("REQUEST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            var params = {};
            params.path = options.path;
            params.mode = options.mode ? options.mode : 'truncate';
            params.position = options.position ? options.position : 0;
            params.encoding = options.encoding ? options.encoding : 'utf8';
            var offset = options.offset ? options.offset : 0; 
            // Input data is array Buffer when encoding is binary
            if (params.encoding === 'binary') {
                log("binary, size is: " + options.data.byteLength);
                var uint8View = new Uint8Array(options.data);
                log("uint8View: " + uint8View);
                var maxLength = options.length ? options.length : Storage.MAX_BUFFER_LENGTH;
                var array = [];
                var count = 0;
                for (var i = offset; i < uint8View.length && count < maxLength; ++i, count++) {
                    array[count] = uint8View[i];
                }
                log("array length: " + count);

                params.data = array;
                params.length = count;
                params.offset = 0;
            }
            // input data is base64 encoded string if encoding is base64
            else if (params.encoding === 'base64') {
                var maxLength2 = options.length ? options.length : Storage.MAX_BUFFER_LENGTH;
                log("base64, size is: " + options.data.length);
                var base64Str = options.data;
                var decodedRaw = window.atob(base64Str);
                var decoded = decodedRaw.substring(offset, offset + maxLength2);
                var arrayView = new Uint8Array(decoded.length);

                var j;
                for (j = 0; j < decoded.length; j++) {
                    arrayView[j] = decoded.charCodeAt(j);
                }

                var array2 = [];
                for (j = 0; j < arrayView.length; ++j) {
                    array2[j] = arrayView[j];
                }

                params.data = array2;
                params.length = array2.length;
                params.offset = 0;
            }			
            // input data is utf-8 text. 
            else {
                var maxLength3 = options.length ? options.length : Storage.MAX_BUFFER_LENGTH;
                //var endPosition = (options.offset + maxLength3) > options.data.length ? options.data.length : (options.offset + maxLength3);
                params.data = options.data.substring(offset, offset + maxLength3);
                params.length = params.data.length;
                params.offset = 0;
            }
            try {
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "fs/writeFile",
                    parameters: params,
                    onSuccess: function (result) {
                        log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        if (result.returnValue) {
                            successCallback({
                                written: result.written
                            });
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });
            } catch (err) {
                log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
                // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
                errorCallback({
                    errorCode: 'STWF',
                    errorText: 'Storage.writeFile() error is occured during operation.'
                });
            }
        }
    };

	/**
	 * 
	 * Gets file stat. Stat for linked file is not shown.
	 * 
	 * @example 
	 * 
	 * function statFile() {
	 *    var successCb = function (cbObject){
	 *      console.log( "Show File Stat: " ); 
	 *      console.log( JSON.stringify(cbObject));
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = { 
	 *      path: 'file://internal/myFile.txt',
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.statFile(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the resource (internal/usb/sdcard).</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called with the file stat.</br>
	 *            Example: 
	 *            {   
	 *            	  type: file|directory|unknown,
	 *                size: 527,
	 *                atime: Mon, 10 Oct 2011 23:24:11 GMT,
	 *                mtime: Mon, 10 Oct 2011 23:24:11 GMT,
	 *                ctime: Mon, 10 Oct 2011 23:24:11 GMT
	 *            }
	 *            </br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.statFile = function (successCallback, errorCallback, options) {
        if (!(options && isValidFileURI(options.path))) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (!options.path) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        } else {
            try {
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "fs/statFile",
                    parameters: {
                        path: options.path
                    },
                    onSuccess: function (result) {
                        log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

                        if (result.returnValue) {
                            successCallback(result.stat);
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });
            } catch (err) {
                log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
                // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
                errorCallback({
                    errorCode: 'STSF',
                    errorText: 'Storage.statFile() error is occured during operation.'
                });
            }
        }
    };

	/**
	 * 
	 * Removes all files in given file system.
	 * 
	 * @example 
	 * 
	 * function removeAll() {
	 *    var successCb = function (cbObject){
	 *      console.log( "Removed all files " ); 
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 *
	 *    var options = { 
	 *      device: 'internal' // This will remove all files in the internal memory space.
	 *    }; 
	 * 
	 *    var storage = new Storage();
	 *    storage.removeAll(successCb, failureCb, options);
	 * }
	 *          
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>device</th><th>String</th><th>device to remove all files from. (internal, usb:[index], sdcard:[index])</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.removeAll = function (successCallback, errorCallback, options) {
        if (!options) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.device is a mandatory parameter"
            });
        }
        else if (!options.device) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.device is a mandatory parameter"
            });
        } else {
            try {
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "fs/removeAll",
                    parameters: {
                        device: options.device
                    },
                    onSuccess: function (result) {
                        log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

                        if (result.returnValue) {
                            successCallback();
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });
            } catch (err) {
                log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
                // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
                errorCallback({
                    errorCode: 'STRA',
                    errorText: 'Storage.removeAll() error is occured during operation.'
                });
            }
        }
    };

	/**
	 * 
	 * Flushes modified files to filesystem.
	 * 
	 * @example 
	 * 
	 * function fsync() {
	 *    // This example will copy a file to USB and sync it.
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var storage = new Storage();
	 *    storage.copyFile(
	 *      function(){  // Copy was success. fsync the file.
	 *         storage.fsync(
	 *            function(){
	 *               console.log("File synched!!!!!!!!!!");
	 *            },
	 *            failureCb,
	 *            {path : "file://usb:1/file.jpg"}
	 *         );
	 *      }, 
	 *      failureCb, 
	 *      {source:"file://internal/this.jpg", destination:"file://usb:1/file.jpg"}
	 *    );
	 * 
	 *    // This example will sync whole file system.
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *   };
	 * 
	 *    storage.copyFile(
	 *      function(){  // Copy was success. fsync the device.
	 *         storage.fsync(
	 *            function(){
	 *               console.log("File synched!!!!!!!!!!");
	 *            },
	 *            failureCb, // Failure Callback
	 *            {} // Options
	 *         );
	 *      }, 
	 *      failureCb, 	// Failure Callback
	 *      {source:"file://internal/this.jpg", destination:"file://usb:1/file.jpg"} // Options
	 *    );
	 * 
	 * }
	 *          
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>path</th><th>{@link Storage.SCAP_URI}</th><th>URI to the resource (internal/usb/sdcard).</br>If this parameter is not provided, whole file system is synced using 'sync' linux command.</a></th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.fsync = function (successCallback, errorCallback, options) {
        try {
            var params = {};
            if (options && options.path) {
                if (isValidFileURI(options.path)) {
                    params.path = options.path;
                }
                else {
                    errorCallback({
                        errorCode: "BAD_PARAMETER",
                        errorText: "Invalid File URI"
                    });
                    return;
                }
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                method: "fs/fsyncFile",
                parameters: params,
                onSuccess: function (result) {
                    log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    if (result.returnValue) {
                        successCallback();
                    }
                    else {
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                },
                onFailure: function (result) {
                    log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    log("FAILED: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            });
        } catch (err) {
            log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
            // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
            errorCallback({
                errorCode: 'STFS',
                errorText: 'Storage.fsync() error is occured during operation.'
            });
        }
    };

	/**
	 * 
	 * Moves a file or directory.
	 * If newPath already exists, it will be replaced. </br>
	 * If newPath and oldPath refer to a same file, it will return success but do nothing. </br>
	 * If oldPath is a directory, newPath must be either non-existing or emptry directory. </br>
	 * 
	 * <p>
	 *  file://internal/external, file://usb:[usb_port]/content are predefined directory for special use, and cannot be moved. 
	 * </p>
	 * @example 
	 * 
	 * function moveFile() {
	 *    var successCb = function (){
	 *      console.log("Move File done.");
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = { 
	 *      oldPath: 'file://internal/org.txt',
	 *      newPath : 'file://internal/new.txt'
	 *    };
	 * 
	 *    var storage = new Storage();
	 *    storage.moveFile(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>oldPath</th><th>{@link Storage.SCAP_URI}</th><th>URI to the original file (internal/usb/sdcard).</a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>newPath</th><th>{@link Storage.SCAP_URI}</th><th>URI to the new file (internal/usb/sdcard).</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
	 *            
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.moveFile = function (successCallback, errorCallback, options) {
        if (!options) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.oldPath)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.oldpath is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.newPath)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.newPath is a mandatory parameter"
            });
        }
        else {
            try {
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "fs/moveFile",
                    parameters: {
                        oldPath: options.oldPath,
                        newPath: options.newPath
                    },
                    onSuccess: function (result) {
                        log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

                        if (result.returnValue) {
                            successCallback();
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });
            } catch (err) {
                log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
                // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
                errorCallback({
                    errorCode: 'STMF',
                    errorText: 'Storage.moveFile() error is occured during operation.'
                });
            }
        }
    };

	/**
	 * 
	 * Unzip file. It should be compressed in PKI-ZIP format.
	 * 
	 * @example 
	 * function unzipFile() {
	 *    var successCb = function (){
	 *      console.log("Unzip File successful");
	 *    }; 
	 * 
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 *    var options = { 
	 *      zipPath: 'file://internal/myFile.zip',
	 *      targetPath: 'file://internal/unzip/to/here',
	 *    };
	 * 
	 *    var storage = new Storage();
	 *    storage.unzipFile(successCb, failureCb, options);
	 * }
	 * 
	 * @class storage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 *            
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>zipPath</th><th>{@link Storage.SCAP_URI}</th><th>URI to the zip file (internal/usb/sdcard).</a></th><th>required</th></tr>
     *       <tr class="odd"><tr><th>targetPath</th><th>{@link Storage.SCAP_URI}</th><th>URI to the target directory where the contents of the zip file will be stored. (internal/usb/sdcard)</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * 
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter. </br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            To see how error codes are defined, check {@link Error.ERROR_CODE}
	 *            </p>
	 * 
	 * @since 1.2
	 */
    Storage.prototype.unzipFile = function (successCallback, errorCallback, options) {
        if (!options) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.path is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.zipPath)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.zipPath is a mandatory parameter"
            });
        }
        else if (!isValidFileURI(options.targetPath)) {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: "options.targetPath is a mandatory parameter"
            });
        }
        else {
            try {
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "fs/unzip",
                    parameters: {
                        zipPath: options.zipPath,
                        targetPath: options.targetPath
                    },
                    onSuccess: function (result) {
                        log("onSuccess!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

                        if (result.returnValue) {
                            successCallback();
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });
            } catch (err) {
                log("EXCEPTION!!!!!!!!!!!!!!!!!" + err);
                // 160127 iamjunyoung.park : If error catch, why do not call errorCallback?
                errorCallback({
                    errorCode: 'STUF',
                    errorText: 'Storage.unzipFile() error is occured during operation.'
                });
            }
        }
    };

    module.exports = Storage;
});

Storage = cordova.require('cordova/plugin/storage'); // jshint ignore:line
