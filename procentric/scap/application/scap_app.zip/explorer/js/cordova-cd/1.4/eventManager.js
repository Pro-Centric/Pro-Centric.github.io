/**
 * New node file
 */
cordova.define('cordova/plugin/EventManager/EventProxy', function (require, exports, module) { // jshint ignore:line

	function log(msg) {
		console.log(msg);//will be removed // jshint ignore:line
	}

	var service;
	if (window.PalmSystem) { // jshint ignore:line
		log("Window.PalmSystem Available");
		service = require('cordova/plugin/webos/service');
	} else {
		service = {
				Request : function(uri, params) {
					log(uri + " invoked. But I am a dummy because PalmSystem is not available");

					if (typeof params.onFailure === 'function') {
						params.onFailure({ returnValue:false,
							errorText:"PalmSystem Not Available. Cordova is not installed?"});
					}
				}
		};
	}

	
	function EventProxy() {
		this.proxyMoniker = "prototype_moniker";
		this.subscriptions = {};
	};
	
	/**
	 * This is the parent class for the event handler proxy objects. 
	 * All the SCAP event handler proxy objects are inherited from this object.
	 *  
	 * @namespace EventProxy.CLASS
	 */		
	EventProxy.CLASS = ""
	
	/**
	 * <p>Get the moniker for the EventProxy objects. All the classes that inherits from EventProxy 
	 * should have unique moniker that identifies itself.</p>
	 *
	 * @example 
	 * 
	 * 	var manager = new EventManager();
	 * 	var proxy = manager.getEventProxy('dummy');
	 * 	console.log("Add event for: " + proxy.getMoniker()); // Should print 'dummy'
	 *  
	 * @returns  <p>Unique moniker for the proxy object.</p>
	 *  
	 * @class EventProxy
	 * @since 1.3
	 */		
	EventProxy.prototype.getMoniker = function(){
		return this.proxyMoniker;
	};
	
	
	/**
	 * <p>Get the Event Proxy hanslder setting.</p>
	 *
	 * @example 
	 * 
	 * function getHandlerSetting() {
	 *    var successCb = function (cbObject){
	 *      var settings = cbObject.settings;
	 *      console.log(settings);
	 *    };
	 *  
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode; 
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 *    proxy.getProxySetting(successCb, failureCb);
	 * }
	 * 
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * 
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following data.</p>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>settings</th><th>Object</th><th>Proxy setting. Its attributes depend on the inheriting class.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 * 
	 * @class EventProxy
	 * @since 1.3
	 */
	EventProxy.prototype.getProxySetting = function(successCb, failureCb){
		console.log("this.proxyMoniker: " +  this.proxyMoniker);
		var commandURI = "luna://com.webos.service.commercial.signage.storageservice";
		console.log("service: " +  JSON.stringify(service, null, 3));

		service.Request(commandURI, {
			method : "eventManager/getConfig",
			parameters : {
				category : this.proxyMoniker,
			},
			onSuccess : function (result){
				if(result.returnValue){
					if(typeof successCb === 'function'){
						successCb({
							settings : result.settings
						});
					}
				}
				else{
					delete result.returnValue;
					if(typeof failureCb === 'function'){
						failureCb(result);
					}
				}
			},
			onFailure : function(result){
				delete result.returnValue;
				if(typeof failureCb === 'function'){
					failureCb(result);
				}		
			}
		});
	};

	
	/**
	 * <p>Set the Event Proxy hanslder setting.</p>
	 *
	 * @example 
	 * 
	 * function setHandlerSetting() {
	 *    var successCb = function (){
	 *      console.log("successfully set");
	 *    };
	 *  
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode; 
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 * 	  var options = {
	 * 		intervalSec : 15
	 *    }
	 *    proxy.setProxySetting(successCb, failureCb, options);
	 * }
	 * 
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options List of settings. The available settings are dependent on the inheriting class.	  
	 * 
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 * 
	 * @class EventProxy
	 * @since 1.3
	 */	
	EventProxy.prototype.setProxySetting = function(successCb, failureCb, options){
		if(options){
			console.log("this.proxyMoniker: " +  this.proxyMoniker);
			console.log("options: " +  JSON.stringify(options,null, 3));
			
			var commandURI = "luna://com.webos.service.commercial.signage.storageservice";

			service.Request(commandURI, {
				method : "eventManager/setConfig",
				parameters : {
					category : this.proxyMoniker,
					settings : options
				},
				onSuccess : function (result){
					if(result.returnValue){
						if(typeof successCb === 'function'){
							successCb();
						}
					}
					else{
						delete result.returnValue;
						if(typeof failureCb === 'function'){
							failureCb(result);
						}
					}
				},
				onFailure : function(result){
					delete result.returnValue;
					if(typeof failureCb === 'function'){
						failureCb(result);
					}		
				}
			});			
		}
		else{
			if(typeof failureCb === 'function'){
				failureCb({
					errorCode: "BAD_PARAM", 
					errorText: "options is a mandatory parameter"
				});	
			}
		}					
	};

	/**
	 * <p>Remove all the listeners. The underlying watcher will stop as well.</p>
	 *
	 * @example 
	 * 
	 * function cancelAll() {
	 *    var successCb = function (){
	 *      console.log("successfully done");
	 *    };
	 *  
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode; 
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 *    proxy.cancelAll(successCb, failureCb, options);
	 * }
	 * 
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * 
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 * 
	 * @class EventProxy
	 * @since 1.3
	 */	
	EventProxy.prototype.cancelAll = function(successCb, failureCb){
		console.log("this.proxyMoniker: " +  this.proxyMoniker);
		var commandURI = "luna://com.webos.service.commercial.signage.storageservice";

		service.Request(commandURI, {
			method : "eventManager/stopWatcher",
			parameters : {
				category : this.proxyMoniker,
			},
			onSuccess : function (result){
				if(result.returnValue){
					for(var subscriptionId in this.subscriptions ){
						var subscription = this.subscriptions[subscriptionId];
						if(subscription){
							subscription.cancel({category:this.proxyMoniker});			
						}
						delete this.subscriptions[subscriptionId];
					}
					if(typeof successCb === 'function'){
						successCb();
					}
				}
				else{
					delete result.returnValue;
					if(typeof failureCb === 'function'){
						failureCb(result);
					}
				}
			},
			onFailure : function(result){
				delete result.returnValue;
				if(typeof failureCb === 'function'){
					failureCb(result);
				}		
			}
		});			
	};
	
	/**
	 * <p>Get the current value for the event handler. This will not register as listeners.</p>
	 * <p>The contents of the value object depends on the inheriting class.</p>
	 * @example 
	 * 
	 * function getValue() {
	 *    var successCb = function (cbObject){
	 *      var value = cbObject.value;
	 *      console.log("Value is: " + JSON.stringify(value));
	 *    };
	 *  
	 *    var failureCb = function(cbObject){ 
	 *      var errorCode = cbObject.errorCode; 
	 *      var errorText = cbObject.errorText; 
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText); 
	 *    };
	 * 
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 *    proxy.getValue(successCb, failureCb);
	 * }
	 * 
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * 
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 * 
	 * @class EventProxy
	 * @since 1.3
	 */
	EventProxy.prototype.getValue = function(successCb, failureCb){
		console.log("this.proxyMoniker: " +  this.proxyMoniker);
		var commandURI = "luna://com.webos.service.commercial.signage.storageservice";
		console.log("service: " +  JSON.stringify(service, null, 3));

		service.Request(commandURI, {
			method : "eventManager/getValue",
			parameters : {
				category : this.proxyMoniker,
			},
			onSuccess : function (result){
				if(result.returnValue){
					successCb({
						value : result.value
					});
				}
				else{
					delete result.returnValue;
					if(typeof failureCb === 'function'){
						failureCb(result);
					}
				}
			},
			onFailure : function(result){
				delete result.returnValue;
				if(typeof failureCb === 'function'){
					failureCb(result);
				}		
			}
		});
	};
	
	
	/**
	 * <p>
	 * Register an event handler for the event proxy. The callback function will be called whenever said event is generated 
	 * from the underlying service with supplimenting data.
	 * </p>
	 * <p>The type of events and its data is dependent on the inheriting class.</p>
	 * @example 
	 * function registerEventHandler() {
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 *	  // Add an event handler for 'event1' event.
	 *    var subscriptionId = proxy.on('event1', function(data){
	 *    	console.log("evnet1 happened!!!");
	 *    	console.log("data: " + JSON.strignify(data));
	 *    });
	 * }
	 * 
	 * @returns subscriptionId of the new subscription. This will be used to cancel the event handler.
	 * @class EventProxy
	 * @since 1.3
	 */	
	EventProxy.prototype.on = function(event, cb){
		// Start monitoring.
		console.log("Add Event for: " +  event);

		var commandURI = "luna://com.webos.service.commercial.signage.storageservice";
		var subscriptionId = this.proxyMoniker + "-" + Date.now();	
		var subscription =  service.Request(commandURI, {
			method : "eventManager/getValue",
			parameters : {
				category : this.proxyMoniker,				
				event : event,				
				subscribe : true
			},
			onSuccess : function (result){
				console.log("onSuccessonSuccessonSuccessonSuccess");
				console.log(result);
				cb(result);
			},
			onFailure : function(result){
				console.log("onFailureonFailureonFailureonFailureonFailure");
				console.log(result);
				cb(result);
			}
		});
		this.subscriptions[subscriptionId] = subscription;
		return subscriptionId;
	};

	
	/**
	 * <p>
	 * Cancel the event handler. Registered callback will never be evoked when said event is generated.
	 * </p>
	 * <p>The type of events and its data is dependent on the inheriting class.</p>
	 * @example 
	 * function cancelEventHandler() {
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('dummy');
	 *	  // Add an event handler for 'event1' event.
	 *    var subscriptionId = proxy.on('event1', function(data){
	 *    	console.log("evnet1 happened!!!");
	 *    	console.log("data: " + JSON.strignify(data));
	 *    });
	 *    
	 *    proxy.cancel(subscriptionId);
	 * }
	 * 
	 * @param {String} subscriptionId subscription ID returned when this event handler was registered.
	 * @class EventProxy
	 * @since 1.3
	 */	
	EventProxy.prototype.cancel = function(subscriptionId){
		var subscription = this.subscriptions[subscriptionId];
		if(subscription){
			subscription.cancel({category:this.proxyMoniker});
			delete subscription;
		}
	};

	module.exports = EventProxy;

});
EventProxy = cordova.require('cordova/plugin/EventManager/EventProxy'); // jshint ignore:line

//THIS IS DEBUG PURPOSE API
/*EventProxy.prototype.fireEvent = function(event, data){
	if(this.__EVENT_MAP[event]){
		this.__EVENT_MAP[event](data);		
		return true;
	}
}*/

//cordova.define('cordova/plugin/EventManager/FanEventProxy', function (require, exports, module) { // jshint ignore:line
//var FanEventProxy= function(){
//this.proxyMoniker = "fan";
//}

//FanEventProxy.prototype = new EventProxy();
//module.exports = FanEventProxy;
//});

//FanEventProxy = cordova.require('cordova/plugin/EventManager/FanEventProxy'); // jshint ignore:line
//cordova.define('cordova/plugin/EventManager/TemperatureEventProxy', function (require, exports, module) { // jshint ignore:line
//var TemperatureEventProxy= function(){
//this.proxyMoniker = "temperature";
//}

//TemperatureEventProxy.prototype = new EventProxy();
//module.exports = TemperatureEventProxy;
//});

//TemperatureEventProxy = cordova.require('cordova/plugin/EventManager/TemperatureEventProxy'); // jshint ignore:line

//cordova.define('cordova/plugin/EventManager/NetworkEventProxy', function (require, exports, module) { // jshint ignore:line
//var NetworkEventProxy= function(){
//this.proxyMoniker = "network";
//}

//NetworkEventProxy.prototype = new EventProxy();
//module.exports = NetworkEventProxy;
//});

//NetworkEventProxy = cordova.require('cordova/plugin/EventManager/NetworkEventProxy'); // jshint ignore:line

cordova.define('cordova/plugin/EventManager/DummyProxy', function (require, exports, module) { // jshint ignore:line
	var DummyProxy= function(){
		this.proxyMoniker = "dummy";
	}
	
	DummyProxy.prototype = new EventProxy();
	DummyProxy.prototype.constructor = DummyProxy;
	module.exports = DummyProxy;
});

DummyProxy = cordova.require('cordova/plugin/EventManager/DummyProxy'); // jshint ignore:line

cordova.define('cordova/plugin/EventManager/ThermometerProxy', function (require, exports, module) { // jshint ignore:line
	var ThermometerProxy= function(){
		this.proxyMoniker = "thermometer";
	}

	ThermometerProxy.prototype = new EventProxy();
	/**
	 * Event handler class for monitor temperature.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @since 1.3
	 */	
	ThermometerProxy.prototype.constructor = ThermometerProxy;
	
	/**
	 * Register a listener callback for the monitor temperature events. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getTemperature</th><th>Return the current monitor temperature periodically.</th><th>temperature : current monitor temperature, in Celcious</th></tr>
	 *       <tr><th>temperatureChanged</th><th>Notify that temperature has changed.</th><th>temperature : new monitor temperature, in Celcious</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	ThermometerProxy.prototype.on = ThermometerProxy.prototype.on;
		
	/**
	 * Unregister a listener callback for the monitor temperature events. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getTemperature</th><th>Return the current monitor temperature periodically.</th><th>temperature : current monitor temperature, in Celcious</th></tr>
	 *       <tr><th>temperatureChanged</th><th>Notify that temperature has changed.</th><th>temperature : new monitor temperature, in Celcious</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	ThermometerProxy.prototype.cancel = ThermometerProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * The return value will be the monitor temperature, in celcious.
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	ThermometerProxy.prototype.getValue = ThermometerProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each temerature data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	ThermometerProxy.prototype.setProxySetting = ThermometerProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each temerature data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ThermometerProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	ThermometerProxy.prototype.getProxySetting = ThermometerProxy.prototype.getProxySetting;

	module.exports = ThermometerProxy;
});

ThermometerProxy = cordova.require('cordova/plugin/EventManager/ThermometerProxy'); // jshint ignore:line


cordova.define('cordova/plugin/EventManager/LampProxy', function (require, exports, module) { // jshint ignore:line
	var LampProxy= function(){
		this.proxyMoniker = "lamp";
	}

	LampProxy.prototype = new EventProxy();
	/**
	 * Event handler class for the Lamp.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.LampProxy
	 * @since 1.3
	 */	
	LampProxy.prototype.constructor = LampProxy;
	
	/**
	 * Register a listener for the monitor lamp events. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current lamp status periodically.</th><th>status : current lamp status (OK/Fault/NA)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the lamp status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the lamp status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the lamp status has changed to 'na' status.</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.LampProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	LampProxy.prototype.on = LampProxy.prototype.on;
		
	/**
	 * Unregister a listener for the monitor lamp events. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current lamp status periodically.</th><th>status : current lamp status (OK/Fault/NA)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the lamp status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the lamp status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the lamp status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.LampProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	LampProxy.prototype.cancel = LampProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * Get the current lamp status. (ok/fault/na)
	 * 
	 * @namespace eventManager.LampProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	LampProxy.prototype.getValue = LampProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each lamp status polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.LampProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	LampProxy.prototype.setProxySetting = LampProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each lamp status polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.LampProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	LampProxy.prototype.getProxySetting = LampProxy.prototype.getProxySetting;

	module.exports = LampProxy;
});

LampProxy = cordova.require('cordova/plugin/EventManager/LampProxy'); // jshint ignore:line

cordova.define('cordova/plugin/EventManager/FanProxy', function (require, exports, module) { // jshint ignore:line
	var FanProxy= function(){
		this.proxyMoniker = "fan";
	}

	FanProxy.prototype = new EventProxy();
	/**
	 * Event handler class for the monitor fan.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.FanProxy
	 * @since 1.3
	 */	
	FanProxy.prototype.constructor = FanProxy;
	
	/**
	 * Register a listener callback for the monitor fan. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.FanProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	FanProxy.prototype.on = FanProxy.prototype.on;
		
	/**
	 * Unregister a listener callback for monitor fan. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.FanProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	FanProxy.prototype.cancel = FanProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * The return value will be the monitor temperature, in celcious.
	 * 
	 * @namespace eventManager.FanProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	FanProxy.prototype.getValue = FanProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.FanProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	FanProxy.prototype.setProxySetting = FanProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.FanProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	FanProxy.prototype.getProxySetting = FanProxy.prototype.getProxySetting;

	module.exports = FanProxy;
});

FanProxy = cordova.require('cordova/plugin/EventManager/FanProxy'); // jshint ignore:line


cordova.define('cordova/plugin/EventManager/SignalProxy', function (require, exports, module) { // jshint ignore:line
	var SignalProxy= function(){
		this.proxyMoniker = "signal";
	}

	SignalProxy.prototype = new EventProxy();
	/**
	 * Event handler class for the monitor signal.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.SignalProxy
	 * @since 1.3
	 */	
	SignalProxy.prototype.constructor = SignalProxy;
	
	/**
	 * Register a listener callback for the monitor signal. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.SignalProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	SignalProxy.prototype.on = SignalProxy.prototype.on;
		
	/**
	 * Unregister a listener callback for the monitor signal. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.SignalProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	SignalProxy.prototype.cancel = SignalProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * The return value will signal/nosignal.
	 * 
	 * @namespace eventManager.SignalProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	SignalProxy.prototype.getValue = SignalProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.SignalProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	SignalProxy.prototype.setProxySetting = SignalProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.SignalProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	SignalProxy.prototype.getProxySetting = SignalProxy.prototype.getProxySetting;

	module.exports = SignalProxy;
});

SignalProxy = cordova.require('cordova/plugin/EventManager/SignalProxy'); // jshint ignore:line

cordova.define('cordova/plugin/EventManager/ScreenProxy', function (require, exports, module) { // jshint ignore:line
	var ScreenProxy= function(){
		this.proxyMoniker = "screen";
	}

	ScreenProxy.prototype = new EventProxy();
	/**
	 * Event handler class for the monitor screen.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @since 1.3
	 */	
	ScreenProxy.prototype.constructor = ScreenProxy;
	
	/**
	 * Register a listener callback for the monitor screen. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	ScreenProxy.prototype.on = ScreenProxy.prototype.on;
		
	/**
	 * Unregister a listener callback for the monitor screen. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>getStatus</th><th>Return the current status periodically.</th><th>status : current status (ok/fault/na)</th></tr>
	 *       <tr><th>ok</th><th>Notify that the status has changed to 'ok' status.</th><th>none</th></tr>
	 *       <tr><th>fault</th><th>Notify that the status has changed to 'fault' status. </th>none</th></tr>
	 *       <tr><th>na</th><th>Notify that the status has changed to 'na' status. (Not Available)</th><th>none</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	ScreenProxy.prototype.cancel = ScreenProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * The return value will be ok/fault/na.
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	ScreenProxy.prototype.getValue = ScreenProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	ScreenProxy.prototype.setProxySetting = ScreenProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * The list of available settings are:
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>intervalSec</th><th>Seconds between each data polling.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.ScreenProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	ScreenProxy.prototype.getProxySetting = ScreenProxy.prototype.getProxySetting;

	module.exports = ScreenProxy;
});

ScreenProxy = cordova.require('cordova/plugin/EventManager/ScreenProxy'); // jshint ignore:line



cordova.define('cordova/plugin/EventManager/NetworkProxy', function (require, exports, module) { // jshint ignore:line
	var NetworkProxy= function(){
		this.proxyMoniker = "network";
	}

	NetworkProxy.prototype = new EventProxy();
	/**
	 * Event handler class for the monitor signal.
	 * This class will inherit from the {@link EventProxy.CLASS}.
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @since 1.3
	 */	
	NetworkProxy.prototype.constructor = NetworkProxy;
	
	/**
	 * Register a listener callback for the monitor signal. This method will inherit from the {@link EventProxy#on}. </br>
	 * Available events are listed in the table. </br>
	 *  
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>statusChanged</th><th>network status changed.</th><th>status : NetworkStatus.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * 
	 * NetworkStatus returned with statusChanged has following information.
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>type</th><th>description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>wired</th><th>Object</th><th>The wired object provides detailed information about state of the wired connection.</th></tr>
	 *       <tr><th>wifi</th><th>Object</th><th>The wifi object provides detailed information about the state of the Wi-Fi connection.</th></tr>
	 *       <tr><th>wifiDirect</th><th>Object</th><th>The wifiDirect object provides detailed information about the state of the Wi-Fi direct connection.</th></tr>
	 *       <tr><th>isInternetConnectionAvailable</th><th>boolean</th><th>If the internet connection is available, 
	 *       isInternetConnectionAvailable contains true.</br> If the internet connection is not available, 
	 *       isInternetConnectionAvailable contains false.<?br></th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @see  <a href="EventProxy%23on.html">EventProxy#on</a><br>
	 * @since 1.3
	 * 
	 */	
	NetworkProxy.prototype.on = NetworkProxy.prototype.on;
		
	/**
	 * Unregister a listener callback for the monitor signal. This method will inherit from the {@link EventProxy#cancel}. </br>
	 * Available events are listed in the table. </br>
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th><th>Data</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>statusChanged</th><th>network status changed.</th><th>status : NetworkStatus.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @see  <a href="EventProxy%23cancel.html">EventProxy#cancel</a><br>
	 * @since 1.3
	 */	
	NetworkProxy.prototype.cancel = NetworkProxy.prototype.cancel;
	
	/**
	 * This method will inherit from the {@link EventProxy#getValue}. </br>
	 * return value will include following data.
	 * 
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>type</th><th>description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>wired</th><th>Object</th><th>The wired object provides detailed information about state of the wired connection.</th></tr>
	 *       <tr><th>wifi</th><th>Object</th><th>The wifi object provides detailed information about the state of the Wi-Fi connection.</th></tr>
	 *       <tr><th>wifiDirect</th><th>Object</th><th>The wifiDirect object provides detailed information about the state of the Wi-Fi direct connection.</th></tr>
	 *       <tr><th>isInternetConnectionAvailable</th><th>boolean</th><th>If the internet connection is available, 
	 *       isInternetConnectionAvailable contains true.</br> If the internet connection is not available, 
	 *       isInternetConnectionAvailable contains false.<?br></th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getValue</a><br>
	 * @since 1.3
	 */	
	NetworkProxy.prototype.getValue = NetworkProxy.prototype.getValue;

	/**
	 * This method will inherit from the {@link EventProxy#setProxySetting}. </br>
	 * There is no avilable setting for this proxy.
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#setProxySetting</a><br>
	 * @since 1.3
	 */	
	NetworkProxy.prototype.setProxySetting = NetworkProxy.prototype.setProxySetting;

	/**
	 * This method will inherit from the {@link EventProxy#getProxySetting}. </br>
	 * There is no avilable setting for this proxy.
	 * 
	 * @namespace eventManager.NetworkProxy
	 * @see  <a href="EventProxy%23getValue.html">EventProxy#getProxySetting</a><br>
	 * @since 1.3
	 */	
	NetworkProxy.prototype.getProxySetting = NetworkProxy.prototype.getProxySetting;

	module.exports = NetworkProxy;
});

NetworkProxy = cordova.require('cordova/plugin/EventManager/NetworkProxy'); // jshint ignore:line

/**
 * @class
 */
cordova.define('cordova/plugin/EventManager', function (require, exports, module) { // jshint ignore:line
	/**
	 * Event Manager
	 */
	var EventManager = function(){
	}

	//EventManager.prototype._FAN_EVENT_PROXY =  new FanEventProxy();
	//EventManager.prototype._NETWORK_EVENT_PROXY = new NetworkEventProxy();
	
	EventManager.prototype._DUMMY_EVENT_PROXY = new DummyProxy();
	EventManager.prototype._THERMO_EVENT_PROXY = new ThermometerProxy();
	EventManager.prototype._FAN_EVENT_PROXY = new FanProxy();
	EventManager.prototype._LAMP_EVENT_PROXY = new LampProxy();
	EventManager.prototype._SIGNAL_EVENT_PROXY = new SignalProxy();
	EventManager.prototype._SCREEN_EVENT_PROXY = new ScreenProxy();
	EventManager.prototype._NETWORK_EVENT_PROXY = new NetworkProxy();

	EventManager.prototype._reousceManagers = {
			//		"fan" : EventManager.prototype._FAN_EVENT_PROXY,
			//		"temperature" : EventManager.prototype._TEMPERATUR_EVENT_PROXY,
			"dummy" : EventManager.prototype._DUMMY_EVENT_PROXY	,
			"thermo" : EventManager.prototype._THERMO_EVENT_PROXY,		
			"fan" : EventManager.prototype._FAN_EVENT_PROXY,
			"lamp" : EventManager.prototype._LAMP_EVENT_PROXY,
			"signal" : 	EventManager.prototype._SIGNAL_EVENT_PROXY,	
			"screen" : 	EventManager.prototype._SCREEN_EVENT_PROXY,
			"network" : 	EventManager.prototype._NETWORK_EVENT_PROXY
	};

	/**
	 * Get event proxy for monitor event handling.
	 * Available proxies are: </br>
	 * "thermo" : Monitor Temperature event manager. See {@link ThermometerProxy#constructor}</br>
	 * 
	 * @example 
	 * function getEventProxy() {
	 * 	  var manager = new EventManager();
	 * 	  var proxy = manager.getEventProxy('thermo'); // This is event manager proxy.
	 * 
	 * }
	 * 
	 * @param resource
	 * @namespace EventManager
	 * @returns EventProxy for the given resource. false will be returned if there is no EventProxy object for the given resource.
	 */
	EventManager.prototype.getEventProxy = function(resource){
		if(resource){
			console.log("Get event proxy for " + resource);
			var proxy = EventManager.prototype._reousceManagers[resource];
			console.log(proxy);
			if(proxy){
				console.log("Proxy exists for: " + proxy);				
				return proxy;
			}
			else{
				console.log("Proxy do not exist for: " + proxy);				
				return false;
			} 			
		}
		else{
			console.log("Resource is mandatory" );
			return false
		}
	};
	
	module.exports = EventManager;
});

EventManager = cordova.require('cordova/plugin/EventManager'); // jshint ignore:line
