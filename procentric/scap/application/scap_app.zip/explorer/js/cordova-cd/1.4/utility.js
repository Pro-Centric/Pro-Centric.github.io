/*
 * This is utility cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the utility API itself, and provides a global namespace for operating utility service.
 * @class
 */
cordova.define('cordova/plugin/utility', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    /**
     * utility interface
     */
    var Utility = function () {
    };
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    /**
     * 160318 iamjunyoug.park : Add function
     */
    var version = null;
    var platformInfoObj = {}; 
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }

    Utility.prototype.createToast = function (successCallback, errorCallback, options) {
            log("createToast: " + options.msg);

            if (options.msg === null && typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "UTCT", "Utility.createToast returns failure. command was not defined.");
                errorCallback(result);
                log("Utility.createToast invalid ");
                return;
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
                method: "createToast",
                parameters: {
                    text : options.msg
                },
                onSuccess: function(result) {
                    log("createToast: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure: function(result) {
                    log("createToast: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "UTCT", "Utility.createToast returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Utility.createToast Done");                    
    };

    module.exports = Utility;
});

Utility = cordova.require('cordova/plugin/utility'); // jshint ignore:line

