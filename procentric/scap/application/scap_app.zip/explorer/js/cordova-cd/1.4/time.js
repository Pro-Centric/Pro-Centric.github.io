/*
 * This is time cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the time API itself, and provides a global namespace for operating time service.
 * @class
 */
cordova.define('cordova/plugin/time', function (require, exports, module) { // jshint ignore:line
    
    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }
    
    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                        
                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    /**
     * time interface
     */
    var Time = function () {
    };
    
    function checkErrorCodeNText(result, errorCode, errorText) {
        
        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    /**
     * 160318 iamjunyoug.park : Add function
     */
    var version = null;
    var platformInfoObj = {}; 
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }

    Time.prototype.setHolidayScheduleMode = function (successCallback, errorCallback, options) {        
        log("setHolidayScheduleMode: " + options.enabled);
        
        if (options.enabled === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "TSHM", "Time.setHolidayScheduleMode returns failure. command was not defined.");
            errorCallback(result);
            log("Time.setHolidayScheduleMode invalid ");
            return;
        }      
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",        
                settings : {
                    "holidayScheduleMode" : (options.enabled === true ) ? "on" : "off" 
                }
            },
            onSuccess : function(result) {
                log("setHolidayScheduleMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setHolidayScheduleMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TSHM", "Time.setHolidayScheduleMode returns failure.");
                    errorCallback(result);
                }
            }
        });
        
        log("Time.setHolidayScheduleMode Done");
    };

    Time.prototype.getHolidayScheduleMode = function (successCallback, errorCallback) {
        
        log("getHolidayScheduleMode: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "commercial",
                keys: ["holidayScheduleMode"]
            },
            onSuccess: function(result) {
                log("getHolidayScheduleMode: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    cbObj.enabled = (result.settings.holidayScheduleMode === "on") ? true : false;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getHolidayScheduleMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TGHM", "Time.getHolidayScheduleMode returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Time.getHolidayScheduleMode Done");
    };

    Time.prototype.addHolidaySchedule = function (successCallback, errorCallback, options) {        
        log("addHolidaySchedule: " + "startMonth : " + options.startMonth + ", startDay : " + options.startDay + ", endMonth : " + options.endMonth + ", endDay : " + options.endDay);
     
        var startSch = new Date((new Date()).getFullYear(), options.startMonth-1, options.startDay, 0, 0);
        var endSch = new Date((new Date()).getFullYear(), options.endMonth-1, options.endDay, 0, 0);         

        //validation check
        if (typeof errorCallback === 'function') {
            if (typeof options.startMonth !== 'number' || typeof options.startDay !== 'number' || isNaN(options.startMonth) || isNaN(options.startDay) ||
                    typeof options.endMonth !== 'number' || typeof options.endDay !== 'number' || isNaN(options.endMonth) || isNaN(options.endDay)) {
                var result = {};
                checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure. parmas are not valid.");
                errorCallback(result);                
                return;
            }

            if (startSch.getMonth() !== options.startMonth - 1 || startSch.getDate() !== options.startDay ||
                endSch.getMonth() !== options.endMonth - 1 || endSch.getDate() !== options.endDay) {
                var result = {};
                checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure for out of range.");
                errorCallback(result);                
                return;
            }

            if (startSch.getTime() > endSch.getTime())
            {
                var result = {};
                checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure. schedule is not valid.");
                errorCallback(result);                
                return;
            }           
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["holidaySchedule"]
            },
            onSuccess : function(result) {
                log("getHolidaySchedule: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var schedule      = {};
                        var savedStartSch = null
                        var savedEndSch   = null
                        var scheduleList  = result.settings.holidaySchedule;

                        if(scheduleList.length >= 7)
                        {
                            var result = {};
                            checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure. schedule list is full");
                            errorCallback(result);                            
                            return;
                        }     

                        //check same schedule
                        for(var i=0; i<scheduleList.length; i++) {

                            savedStartSch = new Date((new Date()).getFullYear(), scheduleList[i].startMonth - 1, scheduleList[i].startDay, 0, 0);
                            savedEndSch   = new Date((new Date()).getFullYear(), scheduleList[i].endMonth - 1, scheduleList[i].endDay, 0, 0);

                            if ( ((savedStartSch.getTime() <= startSch.getTime()) && (savedEndSch.getTime() > startSch.getTime())) ||
                                 ((savedStartSch.getTime() < endSch.getTime()) && (savedEndSch.getTime() >= endSch.getTime())) ||
                                 ((savedStartSch.getTime() === startSch.getTime()) && (savedEndSch.getTime() === endSch.getTime())) ||
                                 ((startSch.getTime() === endSch.getTime()) && (savedEndSch.getTime() === startSch.getTime())) ) {
                                var result = {};
                                checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure. schedule is not valid");
                                errorCallback(result);                                
                                return;
                            }                     
                        }

                        schedule.startMonth = options.startMonth;
                        schedule.startDay   = options.startDay;
                        schedule.endMonth   = options.endMonth;
                        schedule.endDay     = options.endDay;
                        scheduleList.push(schedule);

                        log("scheduleList : " + JSON.stringify(scheduleList));

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                category: "commercial",
                                settings: {
                                    "holidaySchedule": scheduleList
                                }
                            },
                            onSuccess: function(result) {
                                log("addHolidaySchedule: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("addHolidaySchedule: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    }
                }
            },
            onFailure : function(result) {
                log("addHolidaySchedule: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TAHS", "Time.addHolidaySchedule returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Time.addHolidaySchedule Done");
    };

    Time.prototype.delHolidaySchedule = function (successCallback, errorCallback, options) {        
        log("delHolidaySchedule: " + "id : " + options.scheduleId);
        
        if ((typeof options.scheduleId !== 'string' || options.scheduleId === undefined || options.scheduleId === null) && typeof errorCallback === 'function') 
        {
            var result = {};
            checkErrorCodeNText(result, "TDHS", "Time.delHolidaySchedule returns failure. scheduleId is not valid.");
            errorCallback(result);
            log("Time.delHolidaySchedule invalid ");
            return;
        }    

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["holidaySchedule"]
            },
            onSuccess : function(result) {
                log("getHolidaySchedule: On Success");

                if (result.returnValue === true) {                
                    if (typeof successCallback === 'function') {
                        var scheduleList = null;
                        var tempList     = [];
                        var flag         = false;
                        
                        scheduleList     = result.settings.holidaySchedule;

                        log("before scheduleList : " + JSON.stringify(scheduleList));

                        for(var i=0; i<scheduleList.length; i++) {
                            if(scheduleList[i]._id === options.scheduleId) {                                
                                flag = true;                      
                            } else {
                                tempList.push(scheduleList[i]); //copy schedulelist except for schedule to remove
                            }
                        }                     
                        
                        if(flag === false && typeof errorCallback === 'function') {
                            var result = {};
                            checkErrorCodeNText(result, "TDHS", "Time.delHolidaySchedule returns failure. can not find schedule id.");
                            errorCallback(result);
                            log("Time.delHolidaySchedule invalid ");
                        }

                        log("after scheduleList : " + JSON.stringify(tempList));

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                category: "commercial",
                                settings: {
                                    "holidaySchedule": tempList
                                }
                            },
                            onSuccess: function(result) {
                                log("delHolidaySchedule: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("delHolidaySchedule: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "TDHS", "Time.delHolidaySchedule returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });
                    }                    
                }
            },
            onFailure : function(result) {
                log("delHolidaySchedule: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TDHS", "Time.delHolidaySchedule returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Time.delHolidaySchedule Done");
    };

    Time.prototype.delAllHolidaySchedules = function (successCallback, errorCallback) {        
        log("delAllHolidaySchedules: ");
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "set",
            parameters: {
                category: "commercial",
                settings: {
                    "holidaySchedule": []
                }
            },
            onSuccess: function(result) {
                log("delAllHolidaySchedules: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure: function(result) {
                log("delAllHolidaySchedules: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TDAS", "Time.delAllHolidaySchedules returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Time.delAllHolidaySchedules Done");
    };

    Time.prototype.getAllHolidaySchedules = function (successCallback, errorCallback) {           
        log("getAllHolidaySchedules: ");
        
        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "get",
            parameters : {
                category : "commercial",
                keys : ["holidaySchedule"]
            },
            onSuccess : function(result) {
                log("getHolidaySchedule: On Success");

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        var cbObj = {};
                        cbObj.holidayScheduleList = result.settings.holidaySchedule;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                }
            },
            onFailure : function(result) {
                log("getAllHolidaySchedules: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "TGAS", "Time.getAllHolidaySchedules returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Time.getAllHolidaySchedules Done");
    };

    module.exports = Time;
});

Time = cordova.require('cordova/plugin/time'); // jshint ignore:line

