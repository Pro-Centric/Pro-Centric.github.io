String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}



/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * Power#setDPMWakeup
 *
 */
function setDPMWakeup() {
    Debug_Log("Status" + "<br>"
            + "Success : set DPMWakeup<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
          'dpmSignalType : <select id="dpmSignalType"  style = "font-size : 50%;">' +
	      '<option>Power.DPMSignalType.CLOCK</option>' +
	      '<option>Power.DPMSignalType.CLOCK_WITH_DATA</option>' +
	      '</select><br>' +
        "<button style='font-size:100%' onclick = 'doSetDPMWakeup()'>Set DPMWakeup</button>";
}


function doSetDPMWakeup () {

	var options = {};
    options.dpmSignalType = document.getElementById('dpmSignalType').value;

    switch (options.dpmSignalType) {
            case "Power.DPMSignalType.CLOCK" :
                options.dpmSignalType = Power.DPMSignalType.CLOCK;
                break;
            case "Power.DPMSignalType.CLOCK_WITH_DATA" :
                options.dpmSignalType = Power.DPMSignalType.CLOCK_WITH_DATA;
                break;
    }

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "dpmSignalType : " + options.dpmSignalType + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var power = new Power();
	power.setDPMWakeup(successCb, failureCb, options);
}

/**
 *
 * Power#getDPMWakeup
 *
 */

function getDPMWakeup() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getDPMWakeup(successCb, failureCb);
}



/**
 *
 * Power#setPMMode
 *
 */
function setPMMode() {
    Debug_Log("Status" + "<br>"
            + "Success : set PMMode<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        'mode : <select id="mode"  style = "font-size : 50%;">' +
	      '<option>Power.PMMode.PowerOff</option>' +
	      '<option>Power.PMMode.SustainAspectRatio</option>' +
	      '<option>Power.PMMode.ScreenOff</option>' +
	      '<option>Power.PMMode.ScreenOffAlways</option>' +
          '<option>Power.PMMode.ScreenOffBacklight</option>' +
	      '</select><br>' +
        "<button style='font-size:100%' onclick = 'doSetPMMode()'>Set PMMode</button>";
}


function doSetPMMode () {

	var options = {};
    options.mode = document.getElementById('mode').value;

	switch (options.mode) {
            case "Power.PMMode.PowerOff" :
                options.mode = Power.PMMode.PowerOff;
                break;
            case "Power.PMMode.SustainAspectRatio" :
                options.mode = Power.PMMode.SustainAspectRatio;
                break;
            case "Power.PMMode.ScreenOff" :
	            options.mode = Power.PMMode.ScreenOff;
	            break;
            case "Power.PMMode.ScreenOffAlways" :
	            options.mode = Power.PMMode.ScreenOffAlways;
	            break;
            case "Power.PMMode.ScreenOffBacklight" :
                options.mode = Power.PMMode.ScreenOffBacklight;
                break;
    }


    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "mode : " + options.mode + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var power = new Power();
	power.setPMMode(successCb, failureCb, options);
}

/**
 *
 * Power#getPMMode
 *
 */

function getPMMode() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getPMMode(successCb, failureCb);
}


/**
 *
 * Power#setPowerOnDelay
 *
 */
function setPowerOnDelay() {
    Debug_Log("Status" + "<br>"
            + "Success : set PowerOnDelay<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "delayTime : <textarea rows='1' cols = '12' style='font-size:75%' id = 'delayTime'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetPowerOnDelay()'>Set PowerOnDelay</button>";
}


function doSetPowerOnDelay () {

	var options = {};
    options.delayTime = parseInt(document.getElementById('delayTime').value);

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "delayTime : " + options.delayTime + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var power = new Power();
	power.setPowerOnDelay(successCb, failureCb, options);
}

/**
 *
 * Power#getPowerOnDelay
 *
 */

function getPowerOnDelay() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getPowerOnDelay(successCb, failureCb);
}



/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

var WEEK_MON =  1,
    WEEK_TUE =  2,
    WEEK_WED =  4,
    WEEK_THU =  8,
    WEEK_FRI = 16,
    WEEK_SAT = 32
    WEEK_SUN = 64;


/*******************************************************************************
 *
 * Power#enableAllOffTimer()
 *
 */

function enableAllOffTimer() {
    Debug_Log("");
    document.getElementById('inputForm').innerHTML = "<form>"
            + "<input type='checkbox' id='offTimer'>Enable All Off Timer<br>"
            + "<input type='checkbox' id='clearOffTimer'>Clear Off Timer<br>"
            + "</form>"
            + "<button onclick = 'doEnableAllOffTimer()'>Enable All Off Timer</button>";
}

function doEnableAllOffTimer() {
    var options = {
        allOffTimer : document.getElementById('offTimer').checked,
        clearOffTimer : document.getElementById('clearOffTimer').checked // SCAP v1.3 added
    };

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.enableAllOffTimer(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Power#enableAllOnTimer()
 *
 */

function enableAllOnTimer() {
    document.getElementById('inputForm').innerHTML = "<form>"
            + "<input type='checkbox' id='OnTimer'>Enable All On Timer<br>"
            + "<input type='checkbox' id='clearOnTimer'>Clear On Timer<br>"
            + "</form>"
            + "<button onclick = 'doEnableAllOnTimer()'>Enable All On Timer</button>";

}

function doEnableAllOnTimer() {
    var options = {
        allOnTimer : document.getElementById('OnTimer').checked,
        clearOnTimer : document.getElementById('clearOnTimer').checked // SCAP v1.3 added
    };

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.enableAllOnTimer(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Power#getOffTimerList()
 *
 */

function getOffTimerList () {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getOffTimerList()";
    function successCb(cbObject) {
        var returnStr = '';
        var timerList = cbObject.timerList;
        returnStr = "Success : <br>";
        for ( var i = 0; i < timerList.length; i++) {
            returnStr += "timerList[" + i + "] : " + JSON.stringify(timerList[i]) + "<br>" +
                         "timerList[" + i + "] : " +
                         (timerList[i].hour < 10 ? ("0" + timerList[i].hour) : timerList[i].hour)  + ":" +
                         (timerList[i].minute < 10 ? ("0" + timerList[i].minute) : timerList[i].minute) + " - " ;
            if (timerList[i].week & WEEK_MON)
                returnStr += "MON ";
            if (timerList[i].week & WEEK_TUE)
                returnStr += "TUE ";
            if (timerList[i].week & WEEK_WED)
                returnStr += "WED ";
            if (timerList[i].week & WEEK_THU)
                returnStr += "THU ";
            if (timerList[i].week & WEEK_FRI)
                returnStr += "FRI ";
            if (timerList[i].week & WEEK_SAT)
                returnStr += "SAT ";
            if (timerList[i].week & WEEK_SUN)
                returnStr += "SUN ";
            returnStr += "<br>";
        }
        document.getElementById('status').innerHTML = returnStr;
        Debug_Log(returnStr);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getOffTimerList(successCb, failureCb);
}

/*******************************************************************************
 *
 * Power#getOnTimerList()
 *
 */

function getOnTimerList () {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getOnTimerList()";
      function successCb(cbObject) {
         var timerList = cbObject.timerList;
         returnStr = "Success : <br>";
         for ( var i = 0; i < timerList.length; i++) {
             returnStr  += "timerList[" + i + "] : " + JSON.stringify(timerList[i]) + "<br>" +
                           "timerList[" + i + "] : " +
                           (timerList[i].hour < 10 ? ("0" + timerList[i].hour) : timerList[i].hour)  + ":" +
                           (timerList[i].minute < 10 ? ("0" + timerList[i].minute) : timerList[i].minute) + " - " ;
            if (timerList[i].week & WEEK_MON)
                returnStr += "MON ";
            if (timerList[i].week & WEEK_TUE)
                returnStr += "TUE ";
            if (timerList[i].week & WEEK_WED)
                returnStr += "WED ";
            if (timerList[i].week & WEEK_THU)
                returnStr += "THU ";
            if (timerList[i].week & WEEK_FRI)
                returnStr += "FRI ";
            if (timerList[i].week & WEEK_SAT)
                returnStr += "SAT ";
            if (timerList[i].week & WEEK_SUN)
                returnStr += "SUN ";
            returnStr += "<br>";

            document.getElementById('status').innerHTML = returnStr;
            Debug_Log(returnStr);
        }
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getOnTimerList(successCb, failureCb);
}


/*******************************************************************************
 *
 * Power#addOffTimer()
 *
 */


function addOffTimer () {
    Debug_Log("Status" + "<br>"
            + "Success : Add Off Timer(use getOffTimerList() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =
                                "Hour : <textarea id = 'offTimerHour'></textarea><br>" +
                                "Minute : <textarea id = 'offTimerMinute'></textarea>" +
                                "<form>" +
                                "<input type='checkbox' id='MON'>Monday<br>" +
                                "<input type='checkbox' id='TUE'>Tuesday<br>" +
                                "<input type='checkbox' id='WED'>Wednesday<br>" +
                                "<input type='checkbox' id='THU'>Thursday<br>" +
                                "<input type='checkbox' id='FRI'>Friday<br>" +
                                "<input type='checkbox' id='SAT'>Saturday<br>" +
                                "<input type='checkbox' id='SUN'>Sunday<br>" +
                                "</form>" +
                                "<button onclick = 'doAddOffTimer()'>Add Off Timer</button>";
}


function doAddOffTimer () {
    var options = {
        hour : parseInt(document.getElementById('offTimerHour').value),
        minute : parseInt(document.getElementById('offTimerMinute').value),
        week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY
    };
    var timerWeek = 0;
    if (document.getElementById('MON').checked)
        timerWeek += WEEK_MON;
    if (document.getElementById('TUE').checked)
        timerWeek += WEEK_TUE;
    if (document.getElementById('WED').checked)
        timerWeek += WEEK_WED;
    if (document.getElementById('THU').checked)
        timerWeek += WEEK_THU;
    if (document.getElementById('FRI').checked)
        timerWeek += WEEK_FRI;
    if (document.getElementById('SAT').checked)
        timerWeek += WEEK_SAT;
    if (document.getElementById('SUN').checked)
        timerWeek += WEEK_SUN;

    options.week = timerWeek;
    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.addOffTimer(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Power#addOnTimer()
 *
 */

function addOnTimer () {
    Debug_Log("Status" + "<br>"
            + "Success : Add On Timer(use getOnTimerList() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =
                                "Hour : <textarea id = 'OnTimerHour'></textarea><br>" +
                                "Minute : <textarea id = 'OnTimerMinute'></textarea>" +
                                "<form>" +
                                "<input type='checkbox' id='MON'>Monday<br>" +
                                "<input type='checkbox' id='TUE'>Tuesday<br>" +
                                "<input type='checkbox' id='WED'>Wednesday<br>" +
                                "<input type='checkbox' id='THU'>Thursday<br>" +
                                "<input type='checkbox' id='FRI'>Friday<br>" +
                                "<input type='checkbox' id='SAT'>Saturday<br>" +
                                "<input type='checkbox' id='SUN'>Sunday<br>" +
                                'Input Source : <select id="mode"  style = "font-size : 100%;">' +
                                  '<option>HDMI 1</option>' +
                                  '<option>HDMI 2</option>' +
                                  '<option>DisplayPort</option>' +
                                  '<option>DVI</option>' +
                                  '<option>RGB</option>' +
                                  '<option>OPS</option>' +
                                  '<option>Custom</option>' +
                                  '</select><br>' +
                                "</form>" +
                                'Custom Value : <textarea rows="1" cols = "12" style="font-size:75%" id = "customValue"></textarea><br>' +
                                "<button onclick = 'doAddOnTimer()'>Add On Timer</button>";
}


function doAddOnTimer () {
    var options = {
        hour : parseInt(document.getElementById('OnTimerHour').value),
        minute : parseInt(document.getElementById('OnTimerMinute').value),
        week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY,
        inputSource: ""
    };
    switch (document.getElementById('mode').value) {
        case "HDMI 1":
            options.inputSource = "ext://hdmi:1";
            break;
        case "HDMI 2":
            options.inputSource = "ext://hdmi:2";
            break;
        case "DisplayPort":
            options.inputSource = "ext://dp:1";
            break;
        case "DVI":
            options.inputSource = "ext://dvi:1";
            break;
        case "RGB":
            options.inputSource = "ext://rgb:1";
            break;
        case "OPS":
            options.inputSource = "ext://ops:1";
            break;
        case "Custom":
            options.inputSource = document.getElementById('customValue').value;
            break;
    }
    var timerWeek = 0;
        if (document.getElementById('MON').checked)
            timerWeek += WEEK_MON;
        if (document.getElementById('TUE').checked)
            timerWeek += WEEK_TUE;
        if (document.getElementById('WED').checked)
            timerWeek += WEEK_WED;
        if (document.getElementById('THU').checked)
            timerWeek += WEEK_THU;
        if (document.getElementById('FRI').checked)
            timerWeek += WEEK_FRI;
        if (document.getElementById('SAT').checked)
            timerWeek += WEEK_SAT;
        if (document.getElementById('SUN').checked)
            timerWeek += WEEK_SUN;

    options.week = timerWeek;

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.addOnTimer(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Power#deleteOffTimer()
 *
 */

function deleteOffTimer () {
    Debug_Log("Status" + "<br>"
            + "Success : Delete Off Timer(use getOffTimerList() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =
                                "Hour : <textarea id = 'offTimerHour'></textarea><br>" +
                                "Minute : <textarea id = 'offTimerMinute'></textarea>" +
                                "<form>" +
                                "<input type='checkbox' id='MON'>Monday<br>" +
                                "<input type='checkbox' id='TUE'>Tuesday<br>" +
                                "<input type='checkbox' id='WED'>Wednesday<br>" +
                                "<input type='checkbox' id='THU'>Thursday<br>" +
                                "<input type='checkbox' id='FRI'>Friday<br>" +
                                "<input type='checkbox' id='SAT'>Saturday<br>" +
                                "<input type='checkbox' id='SUN'>Sunday<br>" +
                                "</form>" +
                                "<button onclick = 'doDeleteOffTimer()'>delete Off Timer</button>";
}


function doDeleteOffTimer () {
  var options = {
     hour : parseInt(document.getElementById('offTimerHour').value),
     minute : parseInt(document.getElementById('offTimerMinute').value),
     week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY
  };
  var timerWeek = 0;
    if (document.getElementById('MON').checked)
        timerWeek += WEEK_MON;
    if (document.getElementById('TUE').checked)
        timerWeek += WEEK_TUE;
    if (document.getElementById('WED').checked)
        timerWeek += WEEK_WED;
    if (document.getElementById('THU').checked)
        timerWeek += WEEK_THU;
    if (document.getElementById('FRI').checked)
        timerWeek += WEEK_FRI;
    if (document.getElementById('SAT').checked)
        timerWeek += WEEK_SAT;
    if (document.getElementById('SUN').checked)
        timerWeek += WEEK_SUN;
    options.week = timerWeek;

  function successCb() {
      Debug_Log("Success. No Return value.");
  }

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
     Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var power = new Power();
  power.deleteOffTimer(successCb, failureCb, options);
}



/*******************************************************************************
 *
 * Power#deleteOnTimer()
 *
 */

function deleteOnTimer () {
    Debug_Log("Status" + "<br>"
            + "Success : Delete On Timer(use getOnTimerList() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =
                                "Hour : <textarea id = 'OnTimerHour'></textarea><br>" +
                                "Minute : <textarea id = 'OnTimerMinute'></textarea>" +
                                "<form>" +
                                "<input type='checkbox' id='MON'>Monday<br>" +
                                "<input type='checkbox' id='TUE'>Tuesday<br>" +
                                "<input type='checkbox' id='WED'>Wednesday<br>" +
                                "<input type='checkbox' id='THU'>Thursday<br>" +
                                "<input type='checkbox' id='FRI'>Friday<br>" +
                                "<input type='checkbox' id='SAT'>Saturday<br>" +
                                "<input type='checkbox' id='SUN'>Sunday<br>" +
                                'Input Source : <select id="mode"  style = "font-size : 100%;">' +
                                  '<option>HDMI 1</option>' +
                                  '<option>HDMI 2</option>' +
                                  '<option>DisplayPort</option>' +
                                  '<option>DVI</option>' +
                                  '<option>RGB</option>' +
                                  '<option>OPS</option>' +
                                  '<option>Custom</option>' +
                                  '</select><br>' +
                                "</form>" +
                                'Custom Value : <textarea rows="1" cols = "12" style="font-size:75%" id = "customValue"></textarea><br>' +
                                "<button onclick = 'doDeleteOnTimer()'>delete On Timer</button>";
}


function doDeleteOnTimer () {
    var options = {
       hour : parseInt(document.getElementById('OnTimerHour').value),
       minute : parseInt(document.getElementById('OnTimerMinute').value),
       week : Power.TimerWeek.MONDAY + Power.TimerWeek.FRIDAY
    };
    var timerWeek = 0;
    if (document.getElementById('MON').checked)
        timerWeek += WEEK_MON;
    if (document.getElementById('TUE').checked)
        timerWeek += WEEK_TUE;
    if (document.getElementById('WED').checked)
        timerWeek += WEEK_WED;
    if (document.getElementById('THU').checked)
        timerWeek += WEEK_THU;
    if (document.getElementById('FRI').checked)
        timerWeek += WEEK_FRI;
    if (document.getElementById('SAT').checked)
        timerWeek += WEEK_SAT;
    if (document.getElementById('SUN').checked)
        timerWeek += WEEK_SUN;

    switch (document.getElementById('mode').value) {
        case "HDMI 1":
            options.inputSource = "ext://hdmi:1";
            break;
        case "HDMI 2":
            options.inputSource = "ext://hdmi:2";
            break;
        case "DisplayPort":
            options.inputSource = "ext://dp:1";
            break;
        case "DVI":
            options.inputSource = "ext://dvi:1";
            break;
        case "RGB":
            options.inputSource = "ext://rgb:1";
            break;
        case "OPS":
            options.inputSource = "ext://ops:1";
            break;
        case "Custom":
            options.inputSource = document.getElementById('customValue').value;
            break;
    }
    options.week = timerWeek;

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
       var errorCode = cbObject.errorCode;
       var errorText = cbObject.errorText;
       Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.deleteOnTimer(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Power#setDisplayMode()
 *
 */

function setDisplayMode() {
    Debug_Log("");
    document.getElementById('inputForm').innerHTML = "<form>"
            + "<input type='checkbox' id='display'>Display On<br>"
            + "</form>"
            + "<button onclick = 'doSetDisplayMode()'>Set Display Mode</button>";

}

function doSetDisplayMode() {
    var options = {
        displayMode : (document.getElementById('display').checked ? Power.DisplayMode.DISPLAY_ON : Power.DisplayMode.DISPLAY_OFF)
    };

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
         Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.setDisplayMode(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Power#getPowerStatus()
 *
 */



function getPowerStatus() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getPowerStatus()";
    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "wakeOnLan : " + cbObject.wakeOnLan + "<br>"
                + "displayMode : " + cbObject.displayMode + "<br>"
                + "allOnTimer : " + cbObject.allOnTimer + "<br>"
                + "allOffTimer : " + cbObject.allOffTimer + "<br>");
    }
    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.getPowerStatus(successCb, failureCb);

}

/*******************************************************************************
 *
 * Power#enableWakeOnLan()
 *
 */

function enableWakeOnLan() {
    Debug_Log("");
    document.getElementById('inputForm').innerHTML = "<form>"
                                                   + "<input type='checkbox' id='wol'>Wake On Lan<br>"
                                                   + "</form>"
                                                   + "<button onclick = 'doEnableWakeOnLan()'>Enable Wake On Lan</button>";

}

function doEnableWakeOnLan() {
    var options = {
        wakeOnLan : document.getElementById('wol').checked
    };

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.enableWakeOnLan(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Power#enableWakeOnLan()
 * WARNING : This method call will be terminate or restart webOS Signage.
 *
 */

function executePowerCommand() {
    Debug_Log("");
    document.getElementById('inputForm').innerHTML = '<select id="mode"  style = "font-size : 100%;">'
                                                   + '<option>Reboot</option>'
                                                   + '<option>Shutdown</option>'
                                                   + '</select><br>'
                                                   + "<button onclick = 'doExecutePowerCommand()'>Execute Power Command</button>";
}

function doExecutePowerCommand () {
    var options = {};

    switch(document.getElementById('mode').value) {
    case "Reboot":
        options.powerCommand = Power.PowerCommand.REBOOT;
        break;
    case "Shutdown":
        options.powerCommand = Power.PowerCommand.SHUTDOWN;
        break;
    }

    function successCb() {
          // Do something
          // Signage poewr off
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var power = new Power();
    power.executePowerCommand(successCb, failureCb, options);
}

