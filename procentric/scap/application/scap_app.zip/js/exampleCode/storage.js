String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/*******************************************************************************
 *
 * Storage#readFile
 *
 */

function readFile() {
    Debug_Log("Status" + "<br>"
            + "Success : File Data<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = ""
                                                   + "URL<br>(Empty : file://internal/TEST.dat) :<br>"
                                                   + "<textarea rows='1' cols = '15' style='font-size:75%'  id = 'value'></textarea><br>"
                                                   + "Position(Offset, Default : 0) : <br>"
                                                   + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'position'></textarea><br>"
                                                   + "Length(Default value : 10240 (10 KB)) : <br>"
                                                   + "<textarea rows='1' cols = '15' style='font-size:75%'  id = 'length'></textarea><br>"
                                                   + "Encoding(Empty : default value)<br>Available : [binary], [utf8]) : <br>"
                                                   + "<textarea rows='1' cols = '15' style='font-size:75%'  id = 'mode'></textarea><br>"
                                                   + "<br>"
                                                   + "INFO : If encoding mode is binary,<br>ArrayBuffer will be return.<br>"
                                                   + "<button style='font-size:100%' onclick = 'doReadFile()'>Read Select File</button>";
}

function doReadFile() {
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var readOption = {};

    readOption.path =  document.getElementById('value').value === "" ? "file://internal/TEST.dat" : document.getElementById('value').value;
    if (document.getElementById("position").value !== "")
        readOption.position  =  parseInt(document.getElementById("position").value);
    if (document.getElementById("length").value !== "")
        readOption.length  =  parseInt(document.getElementById("length").value);
    if (document.getElementById("mode").value !== "")
        readOption.encoding = document.getElementById("mode").value;

    var storage = new Storage();
    storage.readFile(successCb, failureCb, readOption);
}

/*******************************************************************************
 *
 * Storage#writeFile
 *
 */

function writeFile() {
    Debug_Log("Status" + "<br>"
            + "Success : Return number of bytes written<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = ""
                                                    + "URL<br>(Empty : file://internal/TEST.dat) :<br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'path'></textarea><br>"
                                                    + "Data <div style='font-size:50%'>(If encoding is binary, write such as [00020406FF].<br>"
                                                    + "This means [00][02][04][06][FF] - 5 Bytes data will be written.)<br>"
                                                    + "Any invalid value (not 0~9 and a~f) will be ignored.</div>"
                                                    + "<textarea rows='10' cols = '20' style='font-size:75%'  id = 'data'></textarea><br>"
                                                    + "Position(Empty : default value 0) : <br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'position'></textarea><br>"
                                                    + "Offset(Empty : default value 0) : <br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'offset'></textarea><br>"
                                                    + "Length(Empty : default value) : <br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'length'></textarea><br>"
                                                    + 'Mode : <select id="mode"  style = "font-size : 100%;">'
                                                    + '<option>Truncate</option>'
                                                    + '<option>Append</option>'
                                                    + '<option>Position</option>'
                                                    + '</select><br>'
                                                    + "Encoding(Available : [binary][utf8]) : <br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'encoding'></textarea><br>"
                                                    + '</select>'
                                                    + "<button style='font-size:100%' onclick = 'doWriteFile()'>Write File</button>";
}

function doWriteFile() {
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var writeOption = {};

    writeOption.path =  document.getElementById('path').value === "" ? "file://internal/TEST.dat" : document.getElementById('path').value; 

    if (document.getElementById("position").value !== "")
        writeOption.position  =  parseInt(document.getElementById("position").value);
    if (document.getElementById("length").value !== "")
        writeOption.length  =  parseInt(document.getElementById("length").value);
    if (document.getElementById("mode").value !== "")
    writeOption.mode = (document.getElementById("mode").value).toLowerCase();
    if (document.getElementById("encoding").value !== "") {
        switch (document.getElementById("encoding").value) {
        case "binary":
            writeOption.encoding = 'binary';
            var HEX_string = document.getElementById('data').value;
            var HEX_array = [];
            for (var i = 0; i < HEX_string.length; i = i + 2) {
                HEX_array[i / 2] = parseInt(HEX_string[i] + HEX_string[i + 1], 16);
            }
            var u8array = new Uint8Array(HEX_array);
            var array = [];
            for (var i = 0; i < u8array.length; ++i) {
                array[i] = u8array[i];
            }
            writeOption.data = array;
            break;
        case "utf8":
            writeOption.encoding = 'utf8';
            writeOption.data = document.getElementById('data').value;
            break;
        default:
            writeOption.encoding = document.getElementById("encoding").value;
            writeOption.data = document.getElementById('data').value;
        }
    }
    else {
        writeOption.encoding = "utf8";
        writeOption.data = document.getElementById('data').value;
    }

    var storage = new Storage();
    storage.writeFile(successCb, failureCb, writeOption);
}

/*******************************************************************************
 *
 * Storage#removeFile
 *
 */

function removeFile() {
    Debug_Log("Status" + "<br>"
            + "Success : Remove target File<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = ""
                                                    + "URL(Empty : Default value) :<br>"
                                                    + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"
                                                    + "Recursive : <input type='checkbox' id = 'recursive'><br>"
                                                    + "<button style='font-size:100%' onclick = 'doRemoveFile()'>Remove Select File</button>";
}

function doRemoveFile() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var removeOption = {
            file : document.getElementById('value').value === "" ? "file://internal/TEST.dat" : document.getElementById('value').value,
            recursive : document.getElementById('recursive').checked
    };

    var storage = new Storage();
    storage.removeFile(successCb, failureCb, removeOption);

}


/*******************************************************************************
 *
 * Storage#listFiles
 *
 */

function listFiles() {
    Debug_Log("Status" + "<br>"
            + "Success : Get file lists<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL(Empty : file://internal) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doListFiles()'>See file list</button>";
}

function doListFiles() {
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "<div id = 'files'></div>");
        document.getElementById("files").innerHTML = "";
        for(var i=0; i<cbObject.totalCount; i++) {
            document.getElementById("files").innerHTML += "["+i+"] "+cbObject.files[i].name + " ("+cbObject.files[i].type +"), "+ cbObject.files[i].size + " Bytes<br>";
        }
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var listOption = {
        path : document.getElementById('value').value === "" ? "file://internal/" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.listFiles(successCb, failureCb, listOption);

}


/*******************************************************************************
 *
 * Storage#getStorageInfo
 *
 */

function getStorageInfo() {
    var successCb = function(cbObject) {
        var returnStr = '';
        returnStr += "Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                   + "Local - Total : " + cbObject.total + "<br>"
                   + "Local - Free : " + cbObject.free + "<br>"
                   + "Local - Used : " + cbObject.used + "<br><br>";
        for ( var uri in cbObject.externalMemory) {
            var external = cbObject.externalMemory[uri];
            returnStr += "URI : " + uri + "<br>"
                       + "- Total : " + external.total + "<br>"
                       + "- Free : " + external.free + "<br>"
                       + "- Used : " + external.used + "<br>";
        }
        Debug_Log(returnStr);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var storage = new Storage();
    storage.getStorageInfo(successCb, failureCb);
}

/*******************************************************************************
 *
 * Storage#downloadFirmware
 *
 */

function downloadFirmware() {
    Debug_Log("Status" + "<br>"
            + "Success : Download firmware (Emulator cannot support)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL(Empty : set default value) :<br> <textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doDownloadFirmware()'>Download Firmware</button>";
}

function doDownloadFirmware() {
    Debug_Log("Download Firmware from :<br>"
        + ((document.getElementById('value').value === "") ? "http://10.196.18.93/test_epk/test.epk" : document.getElementById('value').value) + '<br>'
        + 'Please wait until downloading.<br>'
        + 'You can see download progress using getFirmwareUpgradeStatus().');
    function successCb() {
        Debug_Log("Success. No Return value.<br>"
                + "URL : " + options.uri);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        uri : (document.getElementById('value').value === "") ? "http://10.196.18.93/test_epk/test.epk" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.downloadFirmware(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Storage#getFirmwareUpgradeStatus
 *
 */

var timerId=0;
function getFirmwareUpgradeStatus() {
    var successCb = function (cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Status : " + cbObject.status + "<br>"
                + "Upgrade Progess : " + cbObject.upgradeProgress + "<br>"
                + "Download Progress : " + cbObject.downloadProgress);

        if (cbObject.status === "idle")
            clearInterval(timerId);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
        clearInterval(timerId);
    };

    var storage = new Storage();
    storage.getFirmwareUpgradeStatus(successCb, failureCb);
}

/*******************************************************************************
 *
 * Storage#upgradeFirmware
 *
 */

function upgradeFirmware() {
    // If upgrade start, all inputs are disabled.
    timerId=setInterval(getFirmwareUpgradeStatus, 500);
    var successCb = function() {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var storage = new Storage();
    storage.upgradeFirmware(successCb, failureCb);
}

/*******************************************************************************
 *
 * Storage#changeLogoImage
 *
 */

function changeLogoImage() {
    Debug_Log("Status" + "<br>"
            + "Success : Change booting logo (Emulator cannot support)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL(Empty : set default value) :<br> <textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doChangeLogoImage()'>Change Logo Image</button>";
}

function doChangeLogoImage() {
    var successCb = function() {
        Debug_Log("Success. No Return value.<br>"
                + "URL : " + options.uri);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var options = {
        uri : (document.getElementById('value').value === "") ? "file://internal/.content/logo.jpg" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.changeLogoImage(successCb, failureCb, options);

}


/*******************************************************************************
 *
 * Storage#removeAll
 *
 */

function removeAll() {
    Debug_Log("Status" + "<br>"
            + "Success : Delete ALL data from target<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    'Device : <select id="device"  style = "font-size : 100%;">' +
                                                    '<option>Internal Memory</option>' +
                                                    '<option>USB 1</option>' +
                                                    '<option>SD Card 1</option>' +
                                                    '<option>Custom</option>' +
                                                    '</select><br>' +
                                                    'Custom Value : <textarea rows="1" cols = "12" style="font-size:75%" id = "customValue"></textarea><br>' +
                                                    "<div style='font-size:200%; color:#FF0000'>" +
                                                    "<br><br>WARNING : THIS FUNCTION WILL REMOVE ALL DATA FROM SELECT DEVICE.</div>" +
                                                    "<button style='font-size:100%' onclick = 'doRemoveAll()'>Remove All</button>";
}

function doRemoveAll() {
    var successCb = function() {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }
    var options = {};
    switch (document.getElementById('device').value) {
    case "Internal Memory":
        options.device = "internal";
        break;
    case "USB":
        options.device = "usb:1";
        break;
    case "SD Card 1":
        options.device = "sdcard:1";
        break;
    case "Custom":
        options.device = options.src = document.getElementById('customValue').value;
        break;
    }

    var storage = new Storage();
    storage.removeAll(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Storage#upgradeApplication
 *
 */

function upgradeApplication() {
    Debug_Log("Status" + "<br>"
            + "Success : Upgrade target application<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    'To : <select id="device"  style = "font-size : 100%;">' +
                                                    '<option>Local</option>' +
                                                    '<option>USB</option>' +
                                                    '</select><br>' +
                                                    "<input type='checkbox' id='recovery'>Recovery<br>" +
                                                    "<button style='font-size:100%' onclick = 'doUpgradeApplication()'>Upgrade Application</button>";
}

function doUpgradeApplication() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var options = {
        recovery : document.getElementById('recovery').value
    };

    switch (document.getElementById('device').value) {
    case "Local":
        options.to = Storage.AppMode.LOCAL;
        break;
    case "USB":
        options.to = Storage.AppMode.USB;
        break;
    }

    var storage = new Storage();
    storage.upgradeApplication(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Storage#removeApplication
 *
 */

function removeApplication() {
    Debug_Log("Status" + "<br>"
            + "Success : Remove target application (Cannot remove itself)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    'To : <select id="device"  style = "font-size : 100%;">' +
                                                    '<option>Local</option>' +
                                                    '<option>USB</option>' +
                                                    '</select><br>' +
                                                    "<button style='font-size:100%' onclick = 'doRemoveApplication()'>Remove Application</button>";
}

function doRemoveApplication() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var options = {};
    switch (document.getElementById('device').value) {
    case "Local":
        options.to = Storage.AppMode.LOCAL;
        break;
    case "USB":
        options.to = Storage.AppMode.USB;
        break;
    }

    var storage = new Storage();
    storage.removeApplication(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Storage#exists
 *
 */

function exists() {
    Debug_Log("Status" + "<br>"
            + "Success : true(File exists) false (File not exists)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL(Empty : Default value) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doExists()'>Check File Exists</button>";
}

function doExists() {
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Exists  : " + cbObject.exists + "<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var existsOption = {
        path : document.getElementById('value').value === "" ? "file://internal/TEST.dat" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.exists(successCb, failureCb, existsOption);

}

/*******************************************************************************
 *
 * Storage#moveFile
 *
 */

function moveFile() {
    Debug_Log("Status" + "<br>"
            + "Success : Move file<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "Move from<br>(Empty : file://internal/TEST.dat) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'oldPath'></textarea><br>"+
                                                    "Move to<br>(Empty : file://internal/TEST_moved.dat) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'newPath'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doMoveFile()'>Move File</button>";
}

function doMoveFile() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var moveOption = {
            oldPath : document.getElementById('oldPath').value === "" ? "file://internal/TEST.dat" : document.getElementById('oldPath').value,
            newPath : document.getElementById('newPath').value === "" ? "file://internal/TEST_moved.dat" : document.getElementById('newPath').value
    };

    var storage = new Storage();
    storage.moveFile(successCb, failureCb, moveOption);

}


/*******************************************************************************
 *
 * Storage#copyFile
 *
 */

function copyFile() {
    Debug_Log("Status" + "<br>"
            + "Success : File will be copied<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = ""
                                                   + "<div style='font-size:50%'>Internal/USB and HTTP/HTTPS/FTP/SFTP( and redirect) available.</div>"
                                                   + "Copy from<br>(Empty : file://internal/TEST.dat) :<br>"
                                                   + "<textarea rows='1' cols = '20' style='font-size:75%'  id = 'source'></textarea><br>"
                                                   + "Copy to<br>(Empty : file://internal/TEST_moved.dat) :<br>"
                                                   + "<textarea rows='1' cols = '20' style='font-size:75%'  id = 'destination'></textarea><br>"
                                                   ////////////////////////////////////////////////////////////////
                                                   // SCAP v1.3 Added
                                                   + "(S)FTP Options (Optional) : <br>"
                                                   + "Secure : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'secure'>explicit</textarea><br>"
                                                   + "Private Key : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'privateKey'></textarea><br>"
                                                   + "Passphrase : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'passphrase'></textarea><br>"
                                                   + "Connection Timeout : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'connTimeout'></textarea> ms<br>"
                                                   + "PASV Timeout : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'pasvTimeout'></textarea> ms<br>"
                                                   + "Keep Alive : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'keepalive'></textarea> ms<br>"
                                                   + "HTTP(S) Options (Optional) : <br>"
                                                   + "Max Redirection<br>(Empty : default value 0 - not allow) :<br>"
                                                   + "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'redirection'></textarea><br>"
                                                   + "Header : <br><textarea rows='5' cols = '20' style='font-size:75%'  id = 'header'></textarea><br>"
                                                   + "Timeout : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'timeout'></textarea> ms    "
                                                   + "<button style='font-size:100%' onclick = 'doCopyFile()'>Copy File</button><br>"
                                                   + "Scenario Test for JAEJU Shinhwa World : <button style='font-size:100%' onclick = 'doCopyFileAfterCapture()'>Copy File after capture</button>";
                                                   ////////////////////////////////////////////////////////////////
}

function doCopyFileAfterCapture() {
    var imgdata = null;
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>"
            + "<div><img id='image' width=768 height=432></div>");
        document.getElementById('image').src = imgdata;
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var copyOption = {
        source : document.getElementById('source').value === "" ? "file://internal/TEST.dat" : document.getElementById('source').value,
        destination : document.getElementById('destination').value === "" ? "file://internal/TEST_copied.dat" : document.getElementById('destination').value,
        ftpOption : {
            secureOptions : {}
        },
        httpOption : {}
    };
    if (document.getElementById('redirection').value !== "")
        copyOption.maxRedirection = parseInt(document.getElementById('redirection').value);
    ////////////////////////////////////////////////////////////////
    // SCAP v1.3 Added
    // FTP Options
    if (document.getElementById('secure').value !== "")
        copyOption.ftpOption.secure = document.getElementById('secure').value;
    if (document.getElementById('privateKey').value !== "")
        copyOption.ftpOption.secureOptions.privateKey = document.getElementById('privateKey').value;
    if (document.getElementById('passphrase').value !== "")
        copyOption.ftpOption.secureOptions.privateKey = document.getElementById('passphrase').value;
    if (document.getElementById('connTimeout').value !== "")
        copyOption.ftpOption.connTimeout = parseInt(document.getElementById('connTimeout').value);
    if (document.getElementById('pasvTimeout').value !== "")
        copyOption.ftpOption.pasvTimeout = parseInt(document.getElementById('pasvTimeout').value);
    if (document.getElementById('keepalive').value !== "")
        copyOption.ftpOption.keepalive = parseInt(document.getElementById('keepalive').value);
    // HTTP Options
    if (document.getElementById('header').value !== "")
        copyOption.httpOption.headers = document.getElementById('header').value;
    if (document.getElementById('connTimeout').value !== "")
        copyOption.httpOption.timeout = parseInt(document.getElementById('timeout').value);
    ////////////////////////////////////////////////////////////////
    var options = {};
    options.save = true;

    var storage = new Storage();
    var signage = new Signage();
    signage.captureScreen(function(cbObject){
        imgdata = 'data:image/jpeg;base64,' + cbObject.data;
        storage.copyFile(successCb, failureCb, copyOption);
    }, failureCb, options);
}


function doCopyFile() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var copyOption = {
        source : document.getElementById('source').value === "" ? "file://internal/TEST.dat" : document.getElementById('source').value,
        destination : document.getElementById('destination').value === "" ? "file://internal/TEST_copied.dat" : document.getElementById('destination').value,
        ftpOption : {
            secureOptions : {}
        },
        httpOption : {}
    };
    if (document.getElementById('redirection').value !== "")
        copyOption.maxRedirection = parseInt(document.getElementById('redirection').value);
    ////////////////////////////////////////////////////////////////
    // SCAP v1.3 Added
    // FTP Options
    if (document.getElementById('secure').value !== "")
        copyOption.ftpOption.secure = document.getElementById('secure').value;
    if (document.getElementById('privateKey').value !== "")
        copyOption.ftpOption.secureOptions.privateKey = document.getElementById('privateKey').value;
    if (document.getElementById('passphrase').value !== "")
        copyOption.ftpOption.secureOptions.privateKey = document.getElementById('passphrase').value;
    if (document.getElementById('connTimeout').value !== "")
        copyOption.ftpOption.connTimeout = parseInt(document.getElementById('connTimeout').value);
    if (document.getElementById('pasvTimeout').value !== "")
        copyOption.ftpOption.pasvTimeout = parseInt(document.getElementById('pasvTimeout').value);
    if (document.getElementById('keepalive').value !== "")
        copyOption.ftpOption.keepalive = parseInt(document.getElementById('keepalive').value);
    // HTTP Options
    if (document.getElementById('header').value !== "")
        copyOption.httpOption.headers = document.getElementById('header').value;
    if (document.getElementById('connTimeout').value !== "")
        copyOption.httpOption.timeout = parseInt(document.getElementById('timeout').value);
    ////////////////////////////////////////////////////////////////
    var storage = new Storage();
    storage.copyFile(successCb, failureCb, copyOption);
}


/*******************************************************************************
 *
 * Storage#statFile
 *
 */

function statFile() {
    Debug_Log("Status" + "<br>"
            + "Success : Get file stats<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL<br>(Empty : file://internal/TEST.dat) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doStatFile()'>Check File Stat</button>";
}

function doStatFile() {
    var successCb = function(cbObject) {
            Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                    + "Type : " + cbObject.type + "<br>"
                    + "size : " + cbObject.size + "<br>"
                    + "Access Time : " + cbObject.atime + "<br>"
                    + "Modify Time : " + cbObject.mtime + "<br>"
                    + "Create Time : " + cbObject.ctime + "<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var statOption = {
        path : document.getElementById('value').value === "" ? "file://internal/TEST.dat" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.statFile(successCb, failureCb, statOption);

}


/*******************************************************************************
 *
 * Storage#mkdir
 *
 */

function mkdir() {
    Debug_Log("Status" + "<br>"
            + "Success : Make directory<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL<br>(Empty : file://internal/a/b/c/d/e) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'value'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doMkdir()'>Make Directory</button>";
}

function doMkdir() {
        var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var statOption = {
        path : document.getElementById('value').value === "" ? "file://internal/a/b/c/d/e" : document.getElementById('value').value
    };

    var storage = new Storage();
    storage.mkdir(successCb, failureCb, statOption);
}


/*******************************************************************************
 *
 * Storage#unzipFile
 *
 */

function unzipFile() {
    Debug_Log("Status" + "<br>"
            + "Success : Unzip target file to target path<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL<br>(Default : example path) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'zipPath'></textarea><br>"+
                                                    "Target Path<br>(Empty : file://internal/zipExample) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'targetPath'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doUnzipFile()'>Unzip File</button>" +
                                                    "<br><button style='font-size:100%' onclick = 'getSampleZip()'>Get Sample ZIP File from Web</button>";
}

function doUnzipFile() {
        var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var unzipOption = {
        zipPath : document.getElementById('zipPath').value === "" ? "file://internal/ZIP_EXAMPLE.zip" : document.getElementById('zipPath').value,
        targetPath : document.getElementById('targetPath').value === "" ? "file://internal/unzipPath" : document.getElementById('targetPath').value
    };

    var storage = new Storage();
    storage.unzipFile(successCb, failureCb, unzipOption);
}

function getSampleZip() {
    new Storage().copyFile(
        function() {
                Debug_Log("Download Success.");
        },
        function(cbObject) {
                var errorCode = cbObject.errorCode;
                var errorText = cbObject.errorText;
                Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
         },
        {
            source : "http://signup.lge.com/Update/Update_Release/CDTechSupport/WebOS_Task/SCAP/scap_testZip.zip",
            destination : "file://internal/ZIP_EXAMPLE.zip"
        }
     );
}


/*******************************************************************************
 *
 * Storage#fsync
 *
 */

function fsync() {
    Debug_Log("Status" + "<br>"
            + "Success : Sync file or file system<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "URL<br>(Empty : Whole file system) :<br>" +
                                                    "<textarea rows='1' cols = '10' style='font-size:75%'  id = 'path'></textarea><br>"+
                                                    "<button style='font-size:100%' onclick = 'doFsync()'>Sync</button>";
}

function doFsync() {
    var successCb = function(cbObject) {
        Debug_Log("Success. No Return value.<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var fsyncOption = {};
    if (document.getElementById('path').value !== "") {
        fsyncOption.path = document.getElementById('path').value;
    }

    var storage = new Storage();
    storage.fsync(successCb, failureCb, fsyncOption);

}




/*******************************************************************************
 *
 * THIS IS NOT SCAP API
 * Download resource files for test easily using copyFile()
 *
 */

function downloadTestFileResource() {
    var count = 0;
    Debug_Log("Downloading. Please wait......");
    var successCb = function() {
        count++;
        if (count === file.length)
            Debug_Log("Download all resource files.");
        else
            Debug_Log("Download " + count + " resource files.")
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };
    var url1 = "http://signup.lge.com/Update/Update_Release/CDTechSupport/Emulator/SCAP_Test_Resource/";
    var url2 = "file://internal/";
    var file = ["binExample1.bin", "bmpExample1.bmp", "bmpExample2.bmp", "gitExample1.gif", "jpgExample1.jpg", "jpgExample2.jpg", "jpgExample3.jpg", "jpgExample4.jpg",
                "pngExample1.png", "tarExample1.tar", "txtExample1.txt", "txtExample2.txt", "txtExample3.txt", "zipExample1.zip", "mp4Example1.mp4"];


    var storage = new Storage();
    for (var i = 0; i < file.length; i++) {
        storage.copyFile(successCb, failureCb, {source:url1+file[i], destination:url2+file[i]});
    }
}

