String.prototype.replaceAll = function(org, dest) {
     return this.split(org).join(dest);
 };

 function Debug_Log(str, isErr, retObj) {
    clearLog();

     if (isErr) {
         console.error(str.replaceAll('<br>', '\n'));
         str = '<font color=#FF0000>' + str + '</font>';

        document.getElementById('status').innerHTML = "Failure : <br>";
     } else {
         console.log(str.replaceAll('<br>', '\n'));
        document.getElementById('status').innerHTML = "Success : <br>";
     }

     if ( retObj ) {
        document.getElementById('ledOutput').innerHTML = JSON.stringify(retObj,null,'\t');
     } else {
        document.getElementById("status").innerHTML = str;
     }
 }

 function clearLog() {
    document.getElementById("status").innerHTML = '';
    document.getElementById("ledOutput").innerHTML = '';
 }

 /***********************************************************************************************************

   SCAP v1.4

 ***********************************************************************************************************/

 /**
  *
  * Led#getLayoutInfo
  *
  */
  function getLayoutInfo() {
    clearLog();

     document.getElementById("inputForm").innerHTML = "No Input form";

     function successCb(cbObject) {
         Debug_Log("Success : " + JSON.stringify(cbObject), false, cbObject);
     }

     function failureCb(cbObject) {
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
         Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
     }

     var led = new Led();
     led.getLayoutInfo(successCb, failureCb);
 }

  /**
  *
  * Led#getUnitStatus
  *
  */
   function getUnitStatus() {
    clearLog();

     Debug_Log("Status" + "<br>"
          + "Success : get Unit Status(use getUnitStatus() to check) <br>"
          + "Failure : ErrorCode and ErrorText message" );

     document.getElementById("inputForm").innerHTML = "senderId : <textarea rows='1' cols = '12' style='font-size:75%' id = 'senderId'></textarea><br>" +
                                   "unitId : <textarea rows='1' cols = '12' style='font-size:75%' id = 'unitId'></textarea><br>" +
                                   "<button style='font-size:100%' onclick = 'doGetUnitStatus()'>Get Unit Status</button>";

   }

   function doGetUnitStatus() {

     var options = {};
     options.senderId = parseInt( document.getElementById('senderId').value );
     options.unitId = parseInt( document.getElementById('unitId').value );

     function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject), false, cbObject);
     }

     function failureCb(cbObject) {
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
         Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
     }

     var led = new Led();
     led.getUnitStatus(successCb, failureCb, options);
  }

  function readLog() {
    clearLog();

     document.getElementById("inputForm").innerHTML = "No Input form";

     function successCb(cbObject) {
         Debug_Log("Success : " + cbObject.data);
         var text = "Success : \n";
         text += cbObject.data;
         document.getElementById("status").innerText = text;
     }

     function failureCb(cbObject) {
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
         Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
     }

     var led = new Led();
     led.readLog(successCb, failureCb);
 }