String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * Sound#setSoundMode
 *
 */

function setSoundMode() {
    Debug_Log("Status" + "<br>"
            + "Success : set SoundMode<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        'mode : <select id="mode"  style = "font-size : 50%;">' +
	      '<option>Sound.SoundMode.Standard</option>' +
	      '<option>Sound.SoundMode.Cinema</option>' +
	      '<option>Sound.SoundMode.ClearVoice</option>' +
	      '<option>Sound.SoundMode.Sports</option>' +
	      '<option>Sound.SoundMode.Music</option>' +
	      '<option>Sound.SoundMode.Game</option>' +
	      '</select><br>' +
        "balance : <textarea rows='1' cols = '12' style='font-size:75%' id = 'balance'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetSoundMode()'>Set SoundMode</button>";
}


function doSetSoundMode () {

	var options = {};
    options.mode = document.getElementById('mode').value;
    options.balance = parseInt(document.getElementById('balance').value);

    switch (options.mode) {
            case "Sound.SoundMode.Standard" :
                options.mode = Sound.SoundMode.Standard;
                break;
            case "Sound.SoundMode.Cinema" :
                options.mode = Sound.SoundMode.Cinema;
                break;
            case "Sound.SoundMode.ClearVoice" :
                options.mode = Sound.SoundMode.ClearVoice;
                break;
            case "Sound.SoundMode.Sports" :
                options.mode = Sound.SoundMode.Sports;
                break;
            case "Sound.SoundMode.Music" :
                options.mode = Sound.SoundMode.Music;
                break;
            case "Sound.SoundMode.Game" :
                options.mode = Sound.SoundMode.Game;
                break;
    }

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "specifier : " + options.specifier + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var sound = new Sound();
	sound.setSoundMode(successCb, failureCb, options);
}


/**
 *
 * Sound#getSoundMode
 *
 */

function getSoundMode () {
	Debug_Log("");
	document.getElementById("inputForm").innerHTML = "No Input form : <br>getSoundMode()";
	function successCb(cbObject) {
		Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
				+ "mode : " + cbObject.mode + "<br>"
				+ "balance : " + cbObject.balance);
	}

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var sound = new Sound();
  sound.getSoundMode(successCb, failureCb);
}


/**
 *
 * Sound#setSoundOut
 *
 */

function setSoundOut() {
    Debug_Log("Status" + "<br>"
            + "Success : set SoundOut<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "speakerType : <select id='speakerType'  style = 'font-size : 50%;'>" +
	      "<option>Sound.SpeakerType.SignageSpeaker</option>" +
	      "<option>Sound.SpeakerType.LGSoundSync</option>" +
	      "</select><br>" +
        "<button style='font-size:100%' onclick = 'doSetSoundOut()'>Set SoundOut</button>";
}


function doSetSoundOut () {

	var options = {};
    options.speakerType = document.getElementById('speakerType').value;

    switch (options.speakerType) {
            case "Sound.SpeakerType.SignageSpeaker" :
                options.speakerType = Sound.SpeakerType.SignageSpeaker;
                break;
            case "Sound.SpeakerType.LGSoundSync" :
                options.speakerType = Sound.SpeakerType.LGSoundSync;
                break;
    }

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "specifier : " + options.specifier + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var sound = new Sound();
	sound.setSoundOut(successCb, failureCb, options);
}


/**
 *
 * Sound#getSoundOut
 *
 */


function getSoundOut () {
	Debug_Log("");
	document.getElementById("inputForm").innerHTML = "No Input form : <br>getSoundOut()";
	function successCb(cbObject) {
		Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
				+ "speakerType : " + cbObject.speakerType);
	}

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var sound = new Sound();
  sound.getSoundOut(successCb, failureCb);
}


/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/*******************************************************************************
 *
 * Sound#getSoundStatus
 *
 */

function getSoundStatus () {
	Debug_Log("");
	document.getElementById("inputForm").innerHTML = "No Input form : <br>getSoundStatus()";
	function successCb(cbObject) {
		Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
				+ "level : " + cbObject.level + "<br>"
				+ "muted : " + cbObject.muted + "<br>"
				+ "externalSpeaker : " + cbObject.externalSpeaker);
	}

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var sound = new Sound();
  sound.getSoundStatus(successCb, failureCb);
}

/*******************************************************************************
 *
 * Sound#setExternalSpeaker
 *
 */

function setExternalSpeaker() {
	Debug_Log("Status" + "<br>"
		    + "Success : Enable or disable external speaker (getSoundStatus() to check)<br>"
		    + "Failure : ErrorCode and ErrorText message");
	document.getElementById("inputForm").innerHTML = "" +
													"External Speaker Enable : <input type='checkbox' id = 'speaker'><br>" +
													"<button style='font-size:100%' onclick = 'doSetExternalSpeaker()'>Set External Speaker</button>";
}


function doSetExternalSpeaker() {
	var options = {
		externalSpeaker : document.getElementById('speaker').checked
	};

	function successCb() {
		Debug_Log("Success. No Return value.");
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var sound = new Sound();
	sound.setExternalSpeaker(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Sound#setMuted
 *
 *
 */

function setMuted() {
	Debug_Log("Status" + "<br>"
		    + "Success : Set mute or not (getSoundStatus() to check)<br>"
		    + "Failure : ErrorCode and ErrorText message");
	document.getElementById("inputForm").innerHTML = "" +
													"Mute : <input type='checkbox' id = 'mute'><br>" +
													"<button style='font-size:100%' onclick = 'doSetMuted()'>Set Mute</button>";
}


function doSetMuted() {
	  var options = {
		muted : document.getElementById('mute').checked
	};

	function successCb() {
		Debug_Log("Success. No Return value.");
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var sound = new Sound();
	sound.setMuted(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Sound#setVolumeLevel
 *
 *
 */

function setVolumeLevel () {
	Debug_Log("Status" + "<br>"
		    + "Success : Set volume level (getSoundStatus() to check)<br>"
		    + "Failure : ErrorCode and ErrorText message");
	document.getElementById("inputForm").innerHTML = "" +
													"Volume : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'volume'></textarea><br>"+
													"Vol OSD Enabled : <input type='checkbox' id = 'osdenable' checked><br>" +
													"<button style='font-size:100%' onclick = 'doSetVolumeLevel()'>Set Volume</button>";

}

function doSetVolumeLevel () {
	  var options = {};
	  if (document.getElementById('volume').value !== "")
	  options.level = parseInt(document.getElementById('volume').value);

	  if (document.getElementById('osdenable').checked === false)
	  options.volOsdEnabled = false;

	  function successCb() {
			Debug_Log("Success. No Return value.");
	  }

	  function failureCb(cbObject) {
	     var errorCode = cbObject.errorCode;
	     var errorText = cbObject.errorText;
			Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	  }

	  var sound = new Sound();
	  sound.setVolumeLevel(successCb, failureCb, options);
	}
