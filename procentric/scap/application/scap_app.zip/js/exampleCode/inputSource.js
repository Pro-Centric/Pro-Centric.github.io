String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/**
 *
 * InputSource#initialize
 *
 */


function initialize() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = '' +
                                          '<select id="mode"  style = "font-size : 100%;">' +
                                          '<option>HDMI 1</option>' +
                                          '<option>HDMI 2</option>' +
                                          '<option>DisplayPort</option>' +
                                          '<option>DVI</option>' +
                                          '<option>RGB</option>' +
                                          '<option>OPS</option>' +
                                          '<option>Custom</option>' +
                                          '</select><br>' +
                                          'Custom Value : <textarea rows="1" cols = "12" style="font-size:75%" id = "customValue"></textarea><br>' +
                                          "<button style='font-size:100%' onclick = 'doInitialize()'>Initialize</button>";
}

function init() {
    document.getElementById("status").innerHTML += "<br><br>Initialize callback function Success";
}

function doInitialize() {
    var options = {
       divId : "inputSource", // It should be matched to <div> tag name in an HTML page.
       videoId : "inputSourceVid",
       callback : init,
       src : ""
    };

    switch (document.getElementById('mode').value) {
    case "HDMI 1":
        options.src = "ext://hdmi:1";
        break;
    case "HDMI 2":
        options.src = "ext://hdmi:2";
        break;
    case "DisplayPort":
        options.src = "ext://dp:1";
        break;
    case "DVI":
        options.src = "ext://dvi:1";
        break;
    case "RGB":
        options.src = "ext://rgb:1";
        break;
    case "OPS":
        options.src = "ext://ops:1";
        break;
    case "Custom":
        options.src = document.getElementById('customValue').value;
        break;
    }

    function successCb() {
        Debug_Log("<font color = '#FF0000'>Success : Initilize input source to : " + options.src + "<br>"
                + "If black screen appear, check input signal.</font>");
    }

    function failureCb(cbObject) {
       var errorCode = cbObject.errorCode;
       var errorText = cbObject.errorText;
       Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText);
    }

    var inputSource = new InputSource();
    inputSource.initialize(successCb, failureCb, options);
}

/**
 *
 * InputSource#changeInputSource
 *
 */
function changeInputSource () {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = '' +
                                          '<select id="mode"  style = "font-size : 100%;">' +
                                          '<option>HDMI 1</option>' +
                                          '<option>HDMI 2</option>' +
                                          '<option>DisplayPort</option>' +
                                          '<option>DVI</option>' +
                                          '<option>RGB</option>' +
                                          '<option>OPS</option>' +
                                          '<option>Custom</option>' +
                                          '</select><br>' +
                                          'Custom Value : <textarea rows="1" cols = "12" style="font-size:75%" id = "customValue"></textarea><br>' +
                                          "<button style='font-size:100%' onclick = 'doChangeInputSource()'>Change Input Source</button>";
}

function doChangeInputSource() {
    var options = {};
    switch (document.getElementById('mode').value) {
    case "HDMI 1":
        options.src = "ext://hdmi:1";
        break;
    case "HDMI 2":
        options.src = "ext://hdmi:2";
        break;
    case "DisplayPort":
        options.src = "ext://dp:1";
        break;
    case "DVI":
        options.src = "ext://dvi:1";
        break;
    case "RGB":
        options.src = "ext://rgb:1";
        break;
    case "OPS":
        options.src = "ext://ops:1";
        break;
    case "Custom":
        options.src = document.getElementById('customValue').value;
        break;
    }
    function successCb() {
        Debug_Log("Success : Initilize input source to : " + document.getElementById('mode').value);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Error Code [" + errorCode + "]: " + errorText, true);
    }

    var inputSource = new InputSource();
    inputSource.changeInputSource(successCb, failureCb, options);
}

/**
 *
 * InputSource#getInputSourceStatus
 *
 */

function getInputSourceStatus () {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getInputSourceStatus()";
    var returnStr = '';

    function successCb(cbObject) {
        var inputSourceList = cbObject.inputSourceList;
        for ( var i = 0; i < inputSourceList.length; i++) {
            returnStr += "inputSourceList[" + i + "] : " + JSON.stringify(inputSourceList[i]) + "<br>" +
                         "inputSourceList[" + i + "].inputPort : " + inputSourceList[i].inputPort + "<br>";
        }
        returnStr += "currentInputSource : " + cbObject.currentInputSource + "<br>" +
                     "currentSignalState : " + cbObject.currentSignalState;
        Debug_Log("<font color = '#FF0000'>" + returnStr + "</font>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Error Code [" + errorCode + "]: " + errorText, true);
    }

    var inputSource = new InputSource();
    inputSource.getInputSourceStatus(successCb, failureCb);
}
