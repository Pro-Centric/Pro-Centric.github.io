String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}


/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/




/**
 *
 * Signage#setIntelligentAuto
 *
 */

function setIntelligentAuto() {
    Debug_Log("Status" + "<br>"
            + "Success : Set IntelligentAuto<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetIntelligentAuto()'>Set IntelligentAuto</button>";
}

function doSetIntelligentAuto () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var signage = new Signage();
	signage.setIntelligentAuto(successCb, failureCb, options);
}

/**
 *
 * Signage#getIntelligentAuto
 *
 */

function getIntelligentAuto () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var signage = new Signage();
	signage.getIntelligentAuto(successCb, failureCb);
}


/**
 *
 * Signage#setStudioMode
 *
 */

function setStudioMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set StudioMode<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetStudioMode()'>Set StudioMode</button>";
}

function doSetStudioMode () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var signage = new Signage();
	signage.setStudioMode(successCb, failureCb, options);
}

/**
 *
 * Signage#getStudioMode
 *
 */

function getStudioMode () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var signage = new Signage();
	signage.getStudioMode(successCb, failureCb);
}

/**
 *
 * Signage#setPivotMode
 *
 */

function setPivotMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set PivotMode<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetPivotMode()'>Set PivotMode</button>";
}

function doSetPivotMode () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var signage = new Signage();
	signage.setPivotMode(successCb, failureCb, options);
}

/**
 *
 * Signage#getPivotMode
 *
 */

function getPivotMode () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var signage = new Signage();
	signage.getPivotMode(successCb, failureCb);
}


/**
 *
 * Signage#setScanInversion
 *
 */

function setScanInversion() {
    Debug_Log("Status" + "<br>"
            + "Success : Set ScanInversion<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetScanInversion()'>Set ScanInversion</button>";
}

function doSetScanInversion () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var signage = new Signage();
	signage.setScanInversion(successCb, failureCb, options);
}

/**
 *
 * Signage#getScanInversion
 *
 */

function getScanInversion () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var signage = new Signage();
	signage.getScanInversion(successCb, failureCb);
}




/***********************************************************************************************************

  SCAP v1.3

***********************************************************************************************************/

/**
 *
 * Signage#enableCheckScreen
 *
 */


function enableCheckScreen() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled'>Enable Check Screen</form><br>"
                                                   + "<button style='font-size:100%' onclick = 'doEnableCheckScreen()'>Enable Check Screen</button>";
}

function doEnableCheckScreen () {
    var options = {
        checkScreen  : document.getElementById('enabled').checked
    };

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var signage = new Signage();
    signage.enableCheckScreen(successCb, failureCb, options);
}

/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/*******************************************************************************
 *
 * Signage#captureScreen
 *
 */

function captureScreen() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "Save : <input type='checkbox' id = 'save'><br>"
                                                    + "Thumbnail : <input type='checkbox' id = 'thumbnail'><br>"
													+ "Image Resolution : <select id='resol'  style = 'font-size : 100%;'>"
													+ "<option>HD</option>"
                                                    + "<option>FHD</option>"
												    + "</select><br>"
                                                    + "<button onclick = 'doCaptureScreen()'>Capture Screen</button>";
}

function doCaptureScreen() {
    var successCB = function(cbObject) {

        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Data size : " + cbObject.size + "<br>"
                + "Data encoding : " + cbObject.encoding + "<br>"
                + "Data : " + cbObject.data + "<br>");

        document.getElementById('image').src = 'data:image/jpeg;base64,' + cbObject.data;

    };

    var failureCB = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {};
    if (document.getElementById("save").checked)
        options.save = true;
    if (document.getElementById("thumbnail").checked)
        options.thumbnail = true;
	if (document.getElementById("resol").value === Signage.ImgResolution.FHD)
        options.imgResolution = Signage.ImgResolution.FHD;

    var signage = new Signage();
    signage.captureScreen(successCB, failureCB, options);
}

/*******************************************************************************
 *
 * Signage#getSignageInfo
 *
 */

function getSignageInfo() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getSignageInfo()";

    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Portrait Mode : " + cbObject.portraitMode + "<br>"
                + "Ism Method : " + cbObject.ismMethod + "<br>"
                + "Check Screen : " + cbObject.checkScreen + "<br>");   // SCAP v1.3 added
        var digitalAudioInputMode = cbObject.digitalAudioInputMode;

        for ( var input in digitalAudioInputMode) {
            var audioInput = digitalAudioInputMode[input];
            document.getElementById("status").innerHTML += "Digital Audio Input Mode for " + input + " : " + audioInput + "<br>";
        }
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getSignageInfo(successCb, failureCb);

}

/*******************************************************************************
 *
 * Signage#getSystemMonitoringInfo
 *
 */

function getSystemMonitoringInfo() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getSystemMonitoringInfo()";
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Fan : " + cbObject.fan + "<br>"
                + "Signal : " + cbObject.signal + "<br>"
                + "Lamp : " + cbObject.lamp + "<br>"
                + "Screen : " + cbObject.screen + "<br>"
                + "Temperature : " + cbObject.temperature + "<br>");
        };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getSystemMonitoringInfo(successCb, failureCb);
}


/*******************************************************************************
 *
 * Signage#getFailoverMode
 *
 */

function getFailoverMode() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getFailoverMode()";

    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Failover Mode : " + cbObject.mode + "<br>"
                + "Priority : " + cbObject.priority);
        };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getFailoverMode(successCb, failureCb);
}


/*******************************************************************************
 *
 * Signage#getPowerSaveMode
 *
 */

function getPowerSaveMode() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getPowerSaveMode()";
       var successCb = function (cbObject){
            Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                    + "Smart Energy Saving Mode : " + cbObject.ses + "<br>"
                    + "Display Power Management Mode : " + cbObject.dpmMode + "<br>"
                    + "Automatic Standby  Mode : " + cbObject.automaticStandby + "<br>"
                    + "15 Minutes Off Mode : " + cbObject.do15MinOff);
       };

   var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getPowerSaveMode(successCb, failureCb);
}


/*******************************************************************************
 *
 * Signage#getTileInfo
 *
 */

function getTileInfo() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getTileInfo()";
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Enabled : " + cbObject.enabled + "<br>"
                + "Row : " + cbObject.row + "<br>"
                + "Column : " + cbObject.column + "<br>"
                + "Tile ID : " + cbObject.tileId + "<br>"
                + "Natural Mode : " + cbObject.naturalMode);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getTileInfo(successCb, failureCb);
}

/*******************************************************************************
 *
 * Signage#setTileInfo
 *
 */

function setTileInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set tile settings(use getTileInfo() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
                                                    "Tile Mode Enabled : <input type='checkbox' id = 'tileMode'><br>" +
                                                    "Row : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'row'></textarea><br>" +
                                                    "Column : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'col'></textarea><br>" +
                                                    "Tile ID : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'tileId'></textarea><br>" +
                                                    "Natural Mode : <input type='checkbox' id = 'naturalMode'><br>" +
                                                    "<button style='font-size:100%' onclick = 'doSetTileInfo()'>Set Tile Mode</button>";
}

function doSetTileInfo() {
       var options = {
         tileInfo: {}
       };


       options.tileInfo.enabled = document.getElementById('tileMode').checked
       if (document.getElementById('row').value !== "")
           options.tileInfo.row = parseInt( document.getElementById('row').value );
       if (document.getElementById('col').value !== "")
       options.tileInfo.column = parseInt( document.getElementById('col').value );
       if (document.getElementById('tileId').value !== "")
       options.tileInfo.tileId = parseInt( document.getElementById('tileId').value );
       options.tileInfo.naturalMode = document.getElementById('naturalMode').checked

       var successCb = function (){
            Debug_Log("Success. No Return value.<br><br>"
                    + "Setting Value : <br>"
                    + "Enabled : " + options.tileInfo.enabled + "<br>"
                    + "Row : " + options.tileInfo.row + "<br>"
                    + "Column : " + options.tileInfo.column + "<br>"
                    + "Tile ID : " + options.tileInfo.tileId + "<br>"
                    + "Natural Mode : " + options.tileInfo.naturalMode + "<br>");
       };

       var failureCb = function(cbObject){
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
            Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
       };

       var signage = new Signage();
       signage.setTileInfo(successCb, failureCb, options);
    }

/*******************************************************************************
 *
 * Signage#getUsageData
 *
 */

function getUsageData() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getUsageData()";
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Uptime : " + cbObject.uptime + "<br>"
                + "Total Used : " + cbObject.totalUsed);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getUsageData(successCb, failureCb);
}

/*******************************************************************************
 *
 * Signage#getUsagePermission
 *
 */

function getUsagePermission() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getUsagePermission()";
    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Remote Control Operation: " + cbObject.remoteKeyOperationMode + "<br>"
                + "Local Key Operation : " + cbObject.localKeyOperationMode);
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getUsagePermission(successCb, failureCb);
}



/*******************************************************************************
 *
 * Signage#setUsagePermission
 *
 */

function setUsagePermission() {
    Debug_Log("Status" + "<br>"
            + "Success : Restrict local/remote keys (getUsagePermission() to check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =  "Remote Key Operation Mode : <br><select id='remote'  style = 'font-size : 100%;'>"
                                                    + "<option>Allow All</option>"
                                                    + "<option>Block All</option>"
                                                    + "<option>Power Only</option>"
                                                    + "</select><br>"
                                                    + "Local Key Operation Mode : <br><select id='local'  style = 'font-size : 100%;'>"
                                                    + "<option>Allow All</option>"
                                                    + "<option>Block All</option>"
                                                    + "<option>Power Only</option>"
                                                    + "</select><br>"
                                                    + "<button onclick = 'doSetUsagePermission()'>Set Usage Permission</button>";
}

function doSetUsagePermission() {
    var options = {
        policy : {
            remoteKeyOperationMode : null,
            localKeyOperationMode : null,
        }
    };

    switch(document.getElementById('remote').value) {
    case "Allow All":
        options.policy.remoteKeyOperationMode = Signage.KeyOperationMode.ALLOW_ALL;
        break;
    case "Block All":
        options.policy.remoteKeyOperationMode = Signage.KeyOperationMode.BLOCK_ALL;
        break;
    case "Power Only":
        options.policy.remoteKeyOperationMode = Signage.KeyOperationMode.POWER_ONLY;
        break;
    }

    switch(document.getElementById('local').value) {
    case "Allow All":
        options.policy.localKeyOperationMode = Signage.KeyOperationMode.ALLOW_ALL;
        break;
    case "Block All":
        options.policy.localKeyOperationMode = Signage.KeyOperationMode.BLOCK_ALL;
        break;
    case "Power Only":
        options.policy.localKeyOperationMode = Signage.KeyOperationMode.POWER_ONLY;
        break;
    }

    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setUsagePermission(successCb, failureCb, options);

}

/*******************************************************************************
 *
 * Signage#registerSystemMonitor
 *
 */

function registerSystemMonitor() {
    Debug_Log("Status" + "<br>"
            + "Success : Start System Monitor and event handler start.<br>"
            + "(getSystemMonitoringInfo() to check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML = "<form>"
                                                    + "<input type='checkbox' id='fan'>Fan<br>"
                                                    + "<input type='checkbox' id='signal'>Signal<br>"
                                                    + "<input type='checkbox' id='lamp'>Lamp<br>"
                                                    + "<input type='checkbox' id='screen'>Screen<br>"
                                                    + "<input type='checkbox' id='temperature'>Temperature<br>"
                                                    + "</form>"
                                                    + "<button onclick = 'doRegisterSystemMonitor()'>Register System Monitor</button>";
}

function doRegisterSystemMonitor() {
   var eventHandler = function(event){
       Debug_Log("RegisterSystemMonitor() -> Event Handler : <br>"
               + "Event" + JSON.stringify(event) + "<br>"
               + "Source : " +  event.source + "<br>"
               + "Type : " +  event.type + "<br>"
               + "Data : " +  JSON.stringify(event.data));

   };

    var options = {
        monitorConfiguration : {
            fan : document.getElementById('fan').checked,
            signal : document.getElementById('signal').checked,
            lamp : document.getElementById('lamp').checked,
            screen : document.getElementById('screen').checked,
            temperature : document.getElementById('temperature').checked
        },
        eventHandler : eventHandler
    };

    var successCb = function() {
        Debug_Log("Success. Event Handler run.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.registerSystemMonitor(successCb, failureCb, options);

}


/*******************************************************************************
 *
 * Signage#unregisterSystemMonitor
 *
 */

function unregisterSystemMonitor() {
       var successCb = function (){
            Debug_Log("Success. No Return value.<br>"
                    + "All System Monitor are removed.");
       };

       var failureCb = function(cbObject){
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
            Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
       };

       var signage = new Signage();
       signage.unregisterSystemMonitor(successCb, failureCb);
    }

/*******************************************************************************
 *
 * Signage#setDigitalAudioInputMode
 *
 */

function setDigitalAudioInputMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set Audio Input Signal(use getSignageInfo() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML = "HDMI 1 : <select id='hdmi1'  style = 'font-size : 100%;'>"
                                                   + "<option>HDMI or DisplayPort</option>"
                                                   + "<option>Audio In</option>"
                                                   + "</select><br>"
                                                   + "HDMI 2 : <select id='hdmi2'  style = 'font-size : 100%;'>"
                                                   + "<option>HDMI or DisplayPort</option>"
                                                   + "<option>Audio In</option>"
                                                   + "</select><br>"
                                                   + "DisplayPort 1 : <select id='dp1'  style = 'font-size : 100%;'>"
                                                   + "<option>HDMI or DisplayPort</option>"
                                                   + "<option>Audio In</option>"
                                                   + "</select><br>"
                                                   //160104 : yooni modificaiton
                                                   + "OPS 1 : <select id='ops1'  style = 'font-size : 100%;'>"
                                                   + "<option>HDMI or DisplayPort</option>"
                                                   + "<option>Audio In</option>"
                                                   + "</select><br>"
                                                   + "<form><input type='checkbox' id='iswebOS1'>Is it webOS Signage 1.0?<br>"
                                                   + "Or Use HDMI2?</form><br>"
                                                   + "If unchecked this, HDMI2 will be ignored"
                                                   + "<button onclick = 'doSetDigitalAudioInputMode()'>Set Digital Audio Input Mode</button>";
}

function doSetDigitalAudioInputMode() {

    var options = {
        digitalAudioInputList : {
            'ext://hdmi:1' : document.getElementById("hdmi1").value === "HDMI or DisplayPort" ? Signage.DigitalAudioInput.HDMI_DP : Signage.DigitalAudioInput.AUDIO_IN,
//            'ext://hdmi:2' : document.getElementById("hdmi2").value === "HDMI or DisplayPort" ? Signage.DigitalAudioInput.HDMI_DP : Signage.DigitalAudioInput.AUDIO_IN,
            'ext://dp:1'   : document.getElementById("dp1").value === "HDMI or DisplayPort"   ? Signage.DigitalAudioInput.HDMI_DP : Signage.DigitalAudioInput.AUDIO_IN,
            'ext://ops:1'   : document.getElementById("ops1").value === "HDMI or DisplayPort"   ? Signage.DigitalAudioInput.HDMI_DP : Signage.DigitalAudioInput.AUDIO_IN,
        }
    };

    if (document.getElementById('iswebOS1').checked) {
        options.digitalAudioInputList['ext://hdmi:2'] = document.getElementById("hdmi2").value === "HDMI or DisplayPort" ? Signage.DigitalAudioInput.HDMI_DP : Signage.DigitalAudioInput.AUDIO_IN;
    }

    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setDigitalAudioInputMode(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Signage#setFailoverMode
 *
 */

function setFailoverMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set Failover Mode(use getFailoverMode() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =  "Failover Mode : <select id='mode'  style = 'font-size : 100%;'>"
                                                    + "<option>Auto</option>"
                                                    + "<option>Manual</option>"
                                                    + "<option>Off</option>"
                                                    + "</select><br>";
    for(var i=1; i<=6; i++) {
        if(i === 6)
        {
            document.getElementById('inputForm').innerHTML += "Priority " + (i) + " : <select id='priority" + (i) + "'  style = 'font-size : 100%;'>"
                                                        + "<option>HDMI 1</option>"
                                                        + "<option>HDMI 2</option>"
                                                        + "<option>DisplayPort</option>"
                                                        + "<option>DVI</option>"
                                                        + "<option>Internal Memory</option>"
                                                        + '<option>RGB</option>'
                                                        + '<option>OPS</option>'
                                                        + '<option selected="selected">USB</option>'
                                                        + '<option>SD Card</option>'
                                                        + '<option>Custom</option>'
                                                        + "</select><br>"
                                                        + 'Custom Value ' + i + ' : <textarea rows="1" cols = "10" style="font-size:75%" id = "customValue' + (i) + '">'
                                                        + '</textarea><br>'
        }
        else
        {
            document.getElementById('inputForm').innerHTML += "Priority " + (i) + " : <select id='priority" + (i) + "'  style = 'font-size : 100%;'>"
                                                        + "<option>HDMI 1</option>"
                                                        + "<option>HDMI 2</option>"
                                                        + "<option>DisplayPort</option>"
                                                        + "<option>DVI</option>"
                                                        + "<option>Internal Memory</option>"
                                                        + '<option>RGB</option>'
                                                        + '<option>OPS</option>'
                                                        + '<option>USB</option>'
                                                        + '<option>SD Card</option>'
                                                        + '<option>Custom</option>'
                                                        + "</select><br>"
                                                        + 'Custom Value ' + i + ' : <textarea rows="1" cols = "10" style="font-size:75%" id = "customValue' + (i) + '">'
                                                        + '</textarea><br>'
        }
    }
    document.getElementById('inputForm').innerHTML += "<form><input type='checkbox' id='iswebOS1'>Is it webOS Signage 1.0?</form>"
                                                    + "- Priority6 must select Internal Memory/USB/SD Card.<br>"
                                                    + "- Priority1~6 is depending on input count of set.<br>"
													+ "for example if input count of set is 3, only Priority1~3 are valid<br>"
                                                    + "<button onclick = 'doSetFailoverMode()'>Set Failover Mode</button>";
}



function doSetFailoverMode() {
    var numOfPriority = document.getElementById('iswebOS1').checked ? 5 : 6;
    //Available input types and number of input ports for each input types may differ model by model.
    var options = {
            failoverMode : {
                mode : null,
                priority : undefined
            }
    };
    switch(document.getElementById('mode').value) {
    case "Auto":
        options.failoverMode.mode = Signage.FailoverMode.AUTO;
        break;
    case "Manual":
        options.failoverMode.mode = Signage.FailoverMode.MANUAL;
        break;
    case "Off":
        options.failoverMode.mode = Signage.FailoverMode.OFF;
        break;
    }

    if (options.failoverMode.mode === Signage.FailoverMode.MANUAL) {
        options.failoverMode.priority = [null, null, null, null, null];
        for(var i=0; i<numOfPriority; i++) {
            options.failoverMode.priority[i] = null;
            switch(document.getElementById('priority' + (i+1) ).value) {
            case "HDMI 1":
                options.failoverMode.priority[i] = "ext://hdmi:1";
                break;
            case "HDMI 2":
                options.failoverMode.priority[i] = "ext://hdmi:2";
                break;
            case "DisplayPort":
                options.failoverMode.priority[i] = "ext://dp:1";
                break;
            case "DVI":
                options.failoverMode.priority[i] = "ext://dvi:1";
                break;
            case "Internal Memory":
                options.failoverMode.priority[i] = "ext://internal_memory";
                break;
            case "RGB":
                options.failoverMode.priority[i] = "ext://rgb:1";
                break;
            case "OPS":
                options.failoverMode.priority[i] = "ext://ops:1";
                break;
            case "USB":
                options.failoverMode.priority[i] = "ext://usb:1";
                break;
            case "SD Card":
                options.failoverMode.priority[i] = "ext://sdCard:1";
                break;
            case "Custom":
                options.failoverMode.priority[i] = document.getElementById('customValue' + (i+1)).value;
                break;
            }
        }
    }
    console.log(JSON.stringify(options, null, 4));

    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setFailoverMode(successCb, failureCb, options);
}




/*******************************************************************************
 *
 * Signage#setPowerSaveMode
 *
 */

function setPowerSaveMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set power saving mode(use getPowerSaveMode() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML =
                                                    "<form>"
                                                    + "<input type='checkbox' id='ses'>SES <br>"
                                                    + "<input type='checkbox' id='do15'>Do 15 Min Off<br>"
                                                    + "</form>"
                                                    + "DPM Mode : <select id='dpm' style = 'font-size : 100%;'>"
                                                    + "<option>Off</option>"
                                                    + "<option>5 Seconds</option>"
                                                    + "<option>10 Seconds</option>"
                                                    + "<option>15 Seconds</option>"
                                                    + "<option>1 Minute</option>"
                                                    + "<option>3 Minutes</option>"
                                                    + "<option>5 Minutes</option>"
                                                    + "<option>10 Minutes</option>"
                                                    + "</select><br>"
                                                    + "Automatic Standby : <select id='automaticStandby'  style = 'font-size : 100%;'>"
                                                    + "<option>On</option>"
                                                    + "<option>Off</option>"
                                                    + "</select><br>"
                                                    + "<button onclick = 'doSetPowerSaveMode()'>Set Power Save Mode</button>";
}

function doSetPowerSaveMode() {
    var options = {
        powerSaveMode : {
            ses : document.getElementById('ses').checked,
            dpmMode : null,
            automaticStandby : null,
            do15MinOff : document.getElementById('do15').checked
        }
    };

    switch(document.getElementById('dpm').value) {
    case "Off":
        options.powerSaveMode.dpmMode = Signage.DpmMode.OFF;
        break;
    case "5 Seconds":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_5SECOND;
        break;
    case "10 Seconds":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_10SECOND;
        break;
    case "15 Seconds":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_15SECOND;
        break;
    case "1 Minute":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_1MINUTE;
        break;
    case "3 Minutes":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_3MINUTE;
        break;
    case "5 Minutes":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_5MINUTE;
        break;
    case "10 Minutes":
        options.powerSaveMode.dpmMode = Signage.DpmMode.POWER_OFF_10MINUTE;
        break;
    }
    switch(document.getElementById('automaticStandby').value) {
    case "On":
        options.powerSaveMode.automaticStandby = Signage.AutomaticStandbyMode.STANDBY_4HOURS;
        break;
    case "Off":
        options.powerSaveMode.automaticStandby = Signage.AutomaticStandbyMode.OFF;
        break;
    }
    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setPowerSaveMode(successCb, failureCb, options);
}

/*******************************************************************************
 *
 * Signage#setIsmMethod
 *
 */

function setIsmMethod() {
    Debug_Log("Status" + "<br>"
            + "Success : Set ISM Method(use getSignageInfo() check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML = "Ism Mode : <select id='mode'  style = 'font-size : 100%;'>"
                                                   + "<option>Normal</option>"
                                                   + "<option>Inversion</option>"
                                                   + "<option>Orbiter</option>"
                                                   + "<option>White Wash</option>"
                                                   + "<option>Color Wash</option>"
                                                   + "<option>Washing Bar</option>"
                                                   + "<option>User Image</option>"
                                                   + "<option>User Video</option>"
                                                   + "</select><br>"
                                                   + "Note : User Image/Video<br>must download file using OSD menu<br>before use.<br>"
                                                   + "<button onclick = 'doSetIsmMethod()'>Set Ism Method</button>";
}



function doSetIsmMethod() {
    var options = {};

    switch (document.getElementById('mode').value) {
    case "Normal":
        options.ismMethod = Signage.IsmMethod.NORMAL;
        break;
    case "Inversion":
        options.ismMethod = Signage.IsmMethod.INVERSION;
        break;
    case "Orbiter":
        options.ismMethod = Signage.IsmMethod.ORBITER;
        break;
    case "White Wash":
        options.ismMethod = Signage.IsmMethod.WHITEWASH;
        break;
    case "Color Wash":
        options.ismMethod = Signage.IsmMethod.COLORWASH;
        break;
    case "Washing Bar":
        options.ismMethod = Signage.IsmMethod.WASHING_BAR;
        break;
    case "User Image":
        options.ismMethod = Signage.IsmMethod.USER_IMAGE;
        break;
    case "User Video":
        options.ismMethod = Signage.IsmMethod.USER_VIDEO;
        break;
    }

    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setIsmMethod(successCb, failureCb, options);

}


/*******************************************************************************
 *
 * Signage#setPortraitMode
 * WARNING : If Portrait Mode on, mouse will be disabled.
 *
 */

function setPortraitMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set Portrait Mode(Emulator cannot support Portrait Mode)<br>"
            + "WARNING : If you set Portrait Mode, mouse will be not available.<br>"
            + "Restart this app will be disable Portrait Mode, and mouse will be available.<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById('inputForm').innerHTML = "<form>"
                                                    + "<input type='checkbox' id='portrait'>Portrait Mode<br>"
                                                    + "</form>"
                                                    + "<button onclick = 'doSetPortraitMode()'>Set Portrait Mode</button>";
}

function doSetPortraitMode() {

    var options = {
        portraitMode : document.getElementById('portrait').checked ? Signage.OsdPortraitMode.ON : Signage.OsdPortraitMode.OFF
    };

    var successCb = function() {
        Debug_Log("Success. No Return value.");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.setPortraitMode(successCb, failureCb, options);
}


/*******************************************************************************
 *
 * Signage#getMirrorMode
 *
 */

function getMirrorMode() {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getMirrorMode()";

    var successCb = function(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Mirror Mode : " + cbObject.mode + "<br>");
    };

    var failureCb = function(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var signage = new Signage();
    signage.getMirrorMode(successCb, failureCb);

}

/*******************************************************************************
 *
 * Signage#setMirrorMode
 *
 */

function setMirrorMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set IntelligentAuto<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetMirrorMode()'>set MirrorMode</button>";

    document.getElementById('inputForm').innerHTML = "mode : <select id='mode'  style = 'font-size : 100%;'>"
                                                    + "<option>on</option>"
                                                    + "<option>off</option>"
                                                    + "</select><br>"
                                                    + "<button style='font-size:100%' onclick = 'doSetMirrorMode()'>set MirrorMode</button>";
}

function doSetMirrorMode () {

	var options = {};
    options.mode = document.getElementById("mode").value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var signage = new Signage();
	signage.setMirrorMode(successCb, failureCb, options);
}