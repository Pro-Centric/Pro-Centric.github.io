String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * Utility#createToast
 *
 */

function createToast() {
    Debug_Log("Status" + "<br>"
            + "Success : create Toast<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "msg : <textarea rows='1' cols = '12' style='font-size:75%' id = 'msg'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doCreateToast()'>create Toast</button>";
}


function doCreateToast () {

	var options = {};
    options.msg = document.getElementById('msg').value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "msg : " + options.msg + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var utility = new Utility();
	utility.createToast(successCb, failureCb, options);
}

