String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * Configuration#getLocaleList
 *
 */

function getLocaleList() {
    document.getElementById("inputForm").innerHTML = "No Input form";

	function successCb(cbObject) {
		var returnStr = '';
        for (var i = cbObject.localeList.length-1; i>=0; i--) {
            returnStr += "localeList [" + i + "].language : " + cbObject.localeList[i].language + '<br>';
            returnStr += "localeList [" + i + "].languageCode : " + cbObject.localeList[i].languageCode + '<br>';
            for (var j = cbObject.localeList[i].countries.length-1; j>=0; j--) {
            	returnStr += "localeList [" + i + "].countries [" + j + "].name : " + cbObject.localeList[i].countries[j].name + '<br>';
            	returnStr += "localeList [" + i + "].countries [" + j + "].specifier : " + cbObject.localeList[i].countries[j].specifier + '<br>';
            }
        }
		Debug_Log("Success : " + JSON.stringify(cbObject) + '<br>' + returnStr);
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.getLocaleList(successCb, failureCb);
}


/**
 *
 * Configuration#setOSDLanguage
 *
 */
function setOSDLanguage() {
    Debug_Log("Status" + "<br>"
            + "Success : set OSDLanguage<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "specifier : <textarea rows='1' cols = '12' style='font-size:75%' id = 'specifier'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetOSDLanguage()'>Set OSDLanguage</button>";
}


function doSetOSDLanguage () {

	var options = {};
    options.specifier = document.getElementById('specifier').value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "specifier : " + options.specifier + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.setOSDLanguage(successCb, failureCb, options);
}

/**
 *
 * Configuration#getOSDLanguage
 *
 */

function getOSDLanguage() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getOSDLanguage(successCb, failureCb);
}

/**
 *
 * Configuration#setVirtualKeyboardLanguage
 *
 */


function setVirtualKeyboardLanguage() {
    Debug_Log("Status" + "<br>"
            + "Success : set VirtualKeyboardLanguage<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "languageCode : <textarea rows='1' cols = '12' style='font-size:75%' id = 'languageCode'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetVirtualKeyboardLanguage()'>Set VirtualKeyboardLanguage</button>";
}


function doSetVirtualKeyboardLanguage () {

	var options = {};
    options.languageCodeList = document.getElementById('languageCode').value.split(',');

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "languageCode : " + options.languageCodeList + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.setVirtualKeyboardLanguage(successCb, failureCb, options);
}



/**
 *
 * Configuration#getVirtualKeyboardLanguage
 *
 */


function getVirtualKeyboardLanguage() {
    document.getElementById("inputForm").innerHTML = "No Input form";

	function successCb(cbObject) {
		var returnStr = '';
        for (var i = cbObject.languageCodeList.length-1; i>=0; i--) {
            returnStr += "languageCodeList [" + i + "] : " + cbObject.languageCodeList[i] + '<br>';
        }
		Debug_Log("Success : " + JSON.stringify(cbObject) + '<br>' + returnStr);
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.getVirtualKeyboardLanguage(successCb, failureCb);
}


/**
 *
 * Configuration#setUSBLock
 *
 */


function setUSBLock() {
    Debug_Log("Status" + "<br>"
            + "Success : Set USBLock<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetUSBLock()'>Set USBLock</button>";
}

function doSetUSBLock () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.setUSBLock(successCb, failureCb, options);
}

/**
 *
 * Configuration#getUSBLock
 *
 */

function getUSBLock() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getUSBLock(successCb, failureCb);
}


/**
 *
 * Configuration#setOSDLock
 *
 */


function setOSDLock() {
    Debug_Log("Status" + "<br>"
            + "Success : Set OSDLock<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetOSDLock()'>Set OSDLock</button>";
}

function doSetOSDLock () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.setOSDLock(successCb, failureCb, options);
}

/**
 *
 * Configuration#getOSDLock
 *
 */

function getOSDLock() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getOSDLock(successCb, failureCb);
}




/***********************************************************************************************************

  SCAP v1.3

***********************************************************************************************************/

/**
 *
 * Configuration#clearCache
 *
 */

function clearCache() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb() {
        Debug_Log("Success. No Callback return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.clearCache(successCb, failureCb);
}

/**
 *
 * Configuration#getTimeZoneList
 *
 */

function getTimeZoneList() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        var returnStr = '';
        for (var i = cbObject.timeZone.length-1; i>=0; i--) {
            returnStr += "timeZone [" + i + "].continent : " + cbObject.timeZone[i].continent + '<br>';
            returnStr += "timeZone [" + i + "].country : " + cbObject.timeZone[i].country + '<br>';
            returnStr += "timeZone [" + i + "].city : " + cbObject.timeZone[i].city + '<br>';
        }
        Debug_Log("Success : " + JSON.stringify(cbObject) + '<br>' + returnStr);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getTimeZoneList(successCb, failureCb);
}

/**
 *
 * Configuration#getTimeZone
 *
 */

function getTimeZone() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getTimeZone(successCb, failureCb);
}


/**
 *
 * Configuration#setTimeZone
 *
 */

function setTimeZone() {
    Debug_Log("Status" + "<br>"
            + "Success : set timezone<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "Continent : <textarea rows='1' cols = '12' style='font-size:75%' id = 'Continent'></textarea><br>" +
        "Country : <textarea rows='1' cols = '12' style='font-size:75%'  id = 'Country'></textarea><br>" +
        "City : <textarea rows='1' cols = '15' style='font-size:75%'  id = 'City'></textarea><br><br>" +
        "<button style='font-size:100%' onclick = 'doSetTimeZone()'>Set Timezone</button>";
}

function doSetTimeZone () {
    var options = {
        timeZone : {}
    };
    options.timeZone.continent = document.getElementById('Continent').value;
    options.timeZone.country = document.getElementById('Country').value;
    options.timeZone.city = document.getElementById('City').value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "Continent : " + options.timeZone.continent + "<br>"
                + "Country : " + options.timeZone.country + "<br>"
                + "City : " + options.timeZone.city + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.setTimeZone(successCb, failureCb, options);
}


/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/**
 *
 * Configuration#getCurrentTime
 *
 */


function getCurrentTime() {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getCurrentTime(successCb, failureCb);
}

/**
 *
 * Configuration#getPictureMode
 *
 */

function getPictureMode () {
    document.getElementById("inputForm").innerHTML = "No Input form";
    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getPictureMode(successCb, failureCb);
}

/**
 *
 * Configuration#getPictureProperty
 *
 */

function getPictureProperty () {
    document.getElementById("inputForm").innerHTML = "No Input form";
    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
                  "Backlight : " + cbObject.backlight + "<br>" +
                  "Contrast : " + cbObject.contrast + "<br>" +
                  "Brightness : " + cbObject.brightness + "<br>" +
                  "Sharpness : " + cbObject.sharpness + "<br>" +
                  "hSharpness : " + cbObject.hSharpness + "<br>" +
                  "vSharptness : " + cbObject.vSharpness + "<br>" +
                  "Color : " + cbObject.color + "<br>" +
                  "Tint : " + cbObject.tint + "<br>" +
                  "Color Temperture : " + cbObject.colorTemperature + "<br>" +
                  "Dynamic Contrast : " + cbObject.dynamicContrast + "<br>" +
                  "Super Resolution : " + cbObject.superResolution + "<br>" +
                  "Color Gamut : " + cbObject.colorGamut + "<br>" +
                  "Dynamic Color : " + cbObject.dynamicColor + "<br>" +
                  "Noise Reduction : " + cbObject.noiseReduction + "<br>" +
                  "MPEG Noise Reduction : " + cbObject.mpegNoiseReduction + "<br>" +
                  "Black Level : " + cbObject.blackLevel + "<br>" +
                  "Gamma : " + cbObject.gamma + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getPictureProperty(successCb, failureCb);
}

/**
 *
 * Configuration#getProperty
 *
 */

function getProperty () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    var options = '{"keys":["alias"]}';

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));

             var parsedString = JSON.parse(cbObject);
             for(var key in parsedString) {
                 var value = parsedString[key];
                 console.log(key + ": " + value);
             }
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getProperty(successCb, failureCb, options);
}

/**
 *
 * Configuration#getServerProperty
 *
 */

function getServerProperty () {
    document.getElementById("inputForm").innerHTML = "No Input form";
    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
                  "server IP : " + cbObject.serverIp + "<br>" +
                  "server Port : " + cbObject.serverPort + "<br>" +
                  "secure Connection : " + cbObject.secureConnection + "<br>" +
                  "applicationLaunchMode : " + cbObject.appLaunchMode + "<br>" +
                  "fully Qualified Domain Name Mode : " + cbObject.fqdnMode + "<br>" +
                  "fully Qualified Domain Name Address: " + cbObject.fqdnAddr);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.getServerProperty(successCb, failureCb);
}

/**
 *
 * Configuration#restartApplication
 *
 */

function restartApplication() {

    function successCb() {
             console.log("Application Restart ");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText + "<br>"
                                                    + "(Set server settings correctly first.)");
    }

    var configuration = new Configuration();
    configuration.restartApplication(successCb, failureCb);
}

/**
 *
 * Configuration#setCurrentTime
 *
 */

function setCurrentTime() {
    Debug_Log("Status" + "<br>"
            + "Success : Set device time(use getCurrentTime() to check)<br>"
            + "Failure : ErrorCode and ErrorText message"
            + "Note : If NTP if true, all other values are ignored.");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='ntp'>Enable Network Time Protocol</form>"
                                                   + "ntpServerAddress : <textarea rows='1' cols = '5' style='font-size:75%' id = 'ntpServerAddress'></textarea><br>"
                                                   + "Year : <textarea rows='1' cols = '5' style='font-size:75%' id = 'Year'></textarea><br>"
                                                   + "Month : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'Month'></textarea><br>"
                                                   + "Day : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'Day'></textarea><br>"
                                                   + "Hour : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'Hour'></textarea><br>"
                                                   + "Minute : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'Minute'></textarea><br>"
                                                   + "Second : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'Second'></textarea><br><br>"
                                                   + "<button style='font-size:100%' onclick = 'doSetTime()'>Set Current Time</button>";
}

function doSetTime () {
    var options = {};
    options.ntp = document.getElementById('ntp').checked;
    options.ntpServerAddress = document.getElementById('ntpServerAddress').value;
    options.year = parseInt(document.getElementById('Year').value);
    options.month = parseInt(document.getElementById('Month').value);
    options.day = parseInt(document.getElementById('Day').value);
    options.hour = parseInt(document.getElementById('Hour').value);
    options.minute = parseInt(document.getElementById('Minute').value);
    options.sec = parseInt(document.getElementById('Second').value);

    if (options.ntp === true) {
        options.year = 2012;
        options.month = 1;
        options.day = 1;
        options.hour = 1;
        options.minute = 1;
        options.sec = 1;
    }

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "ntp : " + options.ntp + "<br>"
                + "ntpServerAddress : " + options.ntpServerAddress + "<br>"
                + "Year : " + options.year + "<br>"
                + "Month : " + options.month + "<br>"
                + "Day : " + options.day + "<br>"
                + "Hour : " + options.hour + "<br>"
                + "Minute : " + options.minute + "<br>"
                + "Second : " + options.sec + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.setCurrentTime(successCb, failureCb, options);
}

/**
 *
 * Configuration#setPictureMode
 *
 */

function setPictureMode () {
    Debug_Log("Status<br>"
            + "Success : set Picture Mode(use setPictureMode() to check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = '<select id="mode"  style = "font-size : 100%;">'
                                                   + '<option>APS</option>'
                                                   + '<option>CINEMA</option>'
                                                   + '<option>EXPERT1</option>'
                                                   + '<option>EXPERT2</option>'
                                                   + '<option>GAME</option>'
                                                   + '<option>SPORTS</option>'
                                                   + '<option>STANDARD</option>'
                                                   + '<option>VIVID</option>'
                                                   + '</select><br><br>'
                                                   + '<button style="font-size:100%" onclick = "doSetPictureMode()">Set Picture Mode</button>';
}

function doSetPictureMode() {

    var picMode = document.getElementById('mode').value;
    switch (picMode) {
    case 'APS':
        picMode = Configuration.PictureMode.APS;
        break;
    case 'CINEMA':
        picMode = Configuration.PictureMode.CINEMA;
        break;
    case 'EXPERT1':
        picMode = Configuration.PictureMode.EXPERT1;
        break;
    case 'EXPERT2':
        picMode = Configuration.PictureMode.EXPERT2;
        break;
    case 'GAME':
        picMode = Configuration.PictureMode.GAME;
        break;
    case 'SPORTS':
        picMode = Configuration.PictureMode.SPORTS;
        break;
    case 'STANDARD':
        picMode = Configuration.PictureMode.STANDARD;
        break;
    case 'VIVID':
        picMode = Configuration.PictureMode.VIVID;
        break;
    }
    var options = {
        mode : picMode
    };

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>" +
                "Set Picture mode to : " + picMode);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.setPictureMode(successCb, failureCb, options);
}

/**
 *
 * Configuration#setPictureProperty
 *
 */

function setPictureProperty () {
    Debug_Log("Status<br>"
            + "Success : set Picture Properties(use getPictureProperty() to check)<br>"
            + "Failure : ErrorCode and ErrorText message<br>"
            + "NOTE : <br>Parameters are not required."
            + "<br>Modify doSetPictureProperty() in /js/exampleCode/configuration.js<br>"
            + "       and use comment to parameters use or not.");
    document.getElementById("inputForm").innerHTML = "Backlight : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'backlight'></textarea><br>"
                                                   + "Contrast : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'contrast'></textarea><br>"
                                                   + "Brightness : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'brightness'></textarea><br>"
                                                   + "Sharpness : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'sharpness'></textarea><br>"
                                                   + "hSharpness : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'hSharpness'></textarea><br>"
                                                   + "vSharptness : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'vSharpness'></textarea><br>"
                                                   + "Color : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'color'></textarea><br>"
                                                   + "Tint : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'tint'></textarea><br>"
                                                   + "Color Temperture : <textarea rows='1' cols = '5' style='font-size:75%' id = 'colorTemperature'></textarea><br>"
                                                   + "Dynamic Contrast : <textarea rows='1' cols = '5' style='font-size:75%' id = 'dynamicContrast'></textarea><br>"
                                                   + "Super Resolution : <textarea rows='1' cols = '5' style='font-size:75%' id = 'superResolution'></textarea><br>"
                                                   + "Color Gamut : <textarea rows='1' cols = '5' style='font-size:75%' id = 'colorGamut'></textarea><br>"
                                                   + "Dynamic Color : <textarea rows='1' cols = '5' style='font-size:75%' id = 'dynamicColor'></textarea><br>"
                                                   + "Noise Reduction : <textarea rows='1' cols = '5' style='font-size:75%' id = 'noiseReduction'></textarea><br>"
                                                   + "MPEG Noise Reduction : <textarea rows='1' cols = '5' style='font-size:75%' id = 'mpegNoiseReduction'></textarea><br>"
                                                   + "Black Level : <textarea rows='1' cols = '5' style='font-size:75%' id = 'blacklevel'></textarea><br>"
                                                   + "Gamma : <textarea rows='1' cols = '5' style='font-size:75%' id = 'gamma'></textarea><br><br>"
                                                   + "<button style='font-size:100%' onclick = 'doSetPictureProperty()'>Set Picture Property</button>";
}

function doSetPictureProperty() {
    var options = {};
    if (document.getElementById('backlight').value !== "")
            options.backlight = parseInt(document.getElementById('backlight').value);
    if (document.getElementById('contrast').value !== "")
        options.contrast = parseInt(document.getElementById('contrast').value);
    if (document.getElementById('brightness').value !== "")
        options.brightness = parseInt(document.getElementById('brightness').value);
    if (document.getElementById('sharpness').value !== "")
        options.sharpness = parseInt(document.getElementById('sharpness').value);
    if (document.getElementById('hSharpness').value !== "")
        options.hSharpness = parseInt(document.getElementById('hSharpness').value);
    if (document.getElementById('vSharpness').value !== "")
        options.vSharpness = parseInt(document.getElementById('vSharpness').value);
    if (document.getElementById('color').value !== "")
        options.color = parseInt(document.getElementById('color').value);
    if (document.getElementById('tint').value !== "")
        options.tint = parseInt(document.getElementById('tint').value);
    if (document.getElementById('colorTemperature').value !== "")
        options.colorTemperature = parseInt(document.getElementById('colorTemperature').value);
    if (document.getElementById('dynamicContrast').value !== "")
        options.dynamicContrast = document.getElementById('dynamicContrast').value;
    if (document.getElementById('superResolution').value !== "")
        options.superResolution = document.getElementById('superResolution').value;
    if (document.getElementById('colorGamut').value !== "")
        options.colorGamut = document.getElementById('colorGamut').value;
    if (document.getElementById('dynamicColor').value !== "")
        options.dynamicColor = document.getElementById('dynamicColor').value;
    if (document.getElementById('noiseReduction').value !== "")
        options.noiseReduction = document.getElementById('noiseReduction').value;
    if (document.getElementById('mpegNoiseReduction').value !== "")
        options.mpegNoiseReduction = document.getElementById('mpegNoiseReduction').value;
    if (document.getElementById('blacklevel').value !== "")
        options.blackLevel = document.getElementById('blacklevel').value;
    if (document.getElementById('gamma').value !== "")
        options.gamma = document.getElementById('gamma').value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br><br>" +
                    "Backlight : " + options.backlight + "<br>" +
                    "Contrast : " + options.contrast + "<br>" +
                    "Brightness : " + options.brightness + "<br>" +
                    "Sharpness : " + options.sharpness + "<br>" +
                    "hSharpness : " + options.hSharpness + "<br>" +
                    "vSharptness : " + options.vSharpness + "<br>" +
                    "Color : " + options.color + "<br>" +
                    "Tint : " + options.tint + "<br>" +
                    "Color Temperture : " + options.colorTemperature + "<br><br>" +

                    "Dynamic Contrast : " + options.dynamicContrast + "<br>" +
                    "Super Resolution : " + options.superResolution + "<br>" +
                    "Color Gamut : " + options.colorGamut + "<br>" +
                    "Dynamic Color : " + options.dynamicColor + "<br>" +
                    "Noise Reduction : " + options.noiseReduction + "<br>" +
                    "MPEG Noise Reduction : " + options.mpegNoiseReduction + "<br>" +
                    "Black Level : " + options.blackLevel + "<br>" +
                    "Gamma : " + options.gamma + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;

        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
        document.getElementById("status").innerHTML ="Error Code [" + errorCode + "]: " + errorText;
    }

    var configuration = new Configuration();
    configuration.setPictureProperty(successCb, failureCb, options);
}

/**
 *
 * Configuration#setProperty
 *
 */

function setProperty () {
    Debug_Log("Status" + "<br>"
            + "Success : Set property(use getProperty() to check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
            "Key : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'key'></textarea><br>" +
            "Value : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'value'></textarea><br>" +
            "(Key value is available only [alias])<br>" +
            "<button style='font-size:100%' onclick = 'doSetProperty()'>Set Property</button>";
}

function doSetProperty () {
    var options = '{"' + document.getElementById('key').value + '":"' + document.getElementById('value').value + '"}';

    console.log("OPTIONS : " + options);
    function successCb() {
        Debug_Log("Success. No Callback return value.<br><br>" +
        "Options : " + options + "<br>" +
        "Key : " + document.getElementById('key').value + "<br>" +
        "Value : " + document.getElementById('value').value + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;

        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.setProperty(successCb, failureCb, options);
}

/**
 *
 * Configuration#setServerProperty
 *
 */

function setServerProperty () {
    Debug_Log("Status" + "<br>"
            + "Success : Set server settings(use getProperty() or SERVER settings menu to check)<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
            "IP : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'ip'></textarea><br>" +
            "Port : <textarea rows='1' cols = '5' style='font-size:75%'  id = 'port'></textarea><br>" +
            "Secured Connection : <input type='checkbox' id = 'secured'><br>" +
            "App Launch Mode : " +
            '<select id="mode"  style = "font-size : 100%;">' +
              '<option>NONE</option>' +
              '<option>LOCAL</option>' +
              '<option>USB</option>' +
              '<option>REMOTE</option>' +
              '</select><br>' +
            "Fully Qualified Domain Name Mode : <input type='checkbox' id = 'fqdn'><br>" +
            "Fully Qualified Domain Name Address : <br><textarea rows='1' cols = '20' style='font-size:75%'  id = 'url'></textarea><br>" +
            "<button style='font-size:100%' onclick = 'doSetServerProperty()'>Set Server Value</button>";
}

function doSetServerProperty () {
    var options = {};
    if (document.getElementById('ip').value !== "")
        options.serverIp = document.getElementById('ip').value;
    if (document.getElementById('port').value !== "")
        options.serverPort = parseInt(document.getElementById('port').value);

    options.secureConnection = document.getElementById('secured').checked;
    options.fqdnMode = document.getElementById('fqdn').checked;

    if (document.getElementById('url').value !== "")
        options.fqdnAddr = document.getElementById('url').value;

    switch(document.getElementById("mode").value) {
        case "NONE":        // Not support this deploying scenario
            options.appLaunchMode = Configuration.AppMode.NONE;
            break;
        case "LOCAL":
            options.appLaunchMode = Configuration.AppMode.LOCAL;
            break;
        case "USB":
            options.appLaunchMode = Configuration.AppMode.USB;
            break;
        case "REMOTE":
            options.appLaunchMode = Configuration.AppMode.REMOTE;
            break;
    }

    function successCb() {
        Debug_Log("Success. No Callback return value.<br><br>"
                + "IP : " + options.serverIp + "<br>"
                + "Port : " + options.serverPort + "<br>"
                + "Secured Connection : " + options.secureConnection + "<br>"
                + "App Launch Mode : " + options.appLaunchMode + "<br>"
                + "Fully Qualified Domain Name Mode : " + options.fqdnMode + "<br>"
                + "Fully Qualified Domain Name Address : " + options.fqdnAddr + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var configuration = new Configuration();
    configuration.setServerProperty(successCb, failureCb, options);
}

/**
 *
 * Configuration#getBrightnessSchedule
 *
 */

 function getBrightnessSchedule() {
    document.getElementById("inputForm").innerHTML = "No Input form";

	function successCb(cbObject) {
		Debug_Log("Success : " + JSON.stringify(cbObject) );
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.getBrightnessSchedule(successCb, failureCb);
}


/**
 *
 * Configuration#setBrightnessSchedule
 *
 */
 var brightnessScheduleCnt = 1;
 function setBrightnessSchedule() {
    brightnessScheduleCnt = 1;

    Debug_Log("Status" + "<br>"
        + "Success : set BrightnessSchedule<br>"
        + "Failure : ErrorCode and ErrorText message");

    var inputText =  "<form><input type='checkbox' id='enabled'>Enable</form>"  +

    " Brightness Schedule <br>"+
    "<button style='font-size:40%' onclick = 'addSchedule()'>add</button>"+

    "<div id='schedule'>" +
    "hour"+brightnessScheduleCnt+" : <textarea rows='1' cols = '9' style='font-size:75%' id = 'hour"+brightnessScheduleCnt+"'></textarea><br>" +
    "minute"+brightnessScheduleCnt+" : <textarea rows='1' cols = '9' style='font-size:75%' id = 'minute"+brightnessScheduleCnt+"'></textarea><br>" +
    "backlight"+brightnessScheduleCnt+" : <textarea rows='1' cols = '9' style='font-size:75%' id = 'backlight"+brightnessScheduleCnt+"'></textarea><br><br>" +
    "</div>"+

    "<button style='font-size:100%' onclick = 'doSetBrightnessSchedule()'>Set BrightnessSchedule</button>";

    document.getElementById("inputForm").innerHTML = inputText;
 }

 function addSchedule() {
    brightnessScheduleCnt++;

    var innerText = document.getElementById('schedule').innerHTML;

    innerText += "hour" + brightnessScheduleCnt + " : <textarea rows='1' cols = '9' style='font-size:75%' id = 'hour" + brightnessScheduleCnt + "'></textarea><br>" +
    "minute" + brightnessScheduleCnt + " : <textarea rows='1' cols = '9' style='font-size:75%' id = 'minute" + brightnessScheduleCnt + "'></textarea><br>" +
    "backlight" + brightnessScheduleCnt + " : <textarea rows='1' cols = '9' style='font-size:75%' id = 'backlight" + brightnessScheduleCnt + "'></textarea><br><br>";

    document.getElementById('schedule').innerHTML = innerText;
 }

 function doSetBrightnessSchedule() {
    var options = {};

    options.enabled = document.getElementById('enabled').checked;

    for( var j=1; j<=brightnessScheduleCnt; j++ ) {
        var hour = document.getElementById( 'hour'+j ).value;
        var minute = document.getElementById( 'minute'+j ).value;
        var backlight = document.getElementById( 'backlight'+j ).value;

        if ( hour!== null && hour !== '' && minute !== null && minute != '' && backlight!== null && backlight !== '' ) {
            if ( Object.prototype.hasOwnProperty.call( options, 'brightnessSchedule' ) === false ) {
                options.brightnessSchedule = [];
            }
            options.brightnessSchedule.push({
                hour : parseInt(hour),
                minute : parseInt(minute),
                backlight : parseInt(backlight)
            })
        }
    }

	function successCb() {
		Debug_Log("Success. No Callback return value." );
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var configuration = new Configuration();
	configuration.setBrightnessSchedule(successCb, failureCb, options);
}
