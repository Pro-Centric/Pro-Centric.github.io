String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * Time#setHolidayScheduleMode
 *
 */

function setHolidayScheduleMode() {
    Debug_Log("Status" + "<br>"
            + "Success : Set HolidayScheduleMode<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "<form><input type='checkbox' id='enabled'>Enable</form>"  +
        "<button style='font-size:100%' onclick = 'doSetHolidayScheduleMode()'>Set HolidayScheduleMode</button>";
}

function doSetHolidayScheduleMode () {

	var options = {};
    options.enabled = document.getElementById('enabled').checked;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "enabled : " + options.enabled + "<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var time = new Time();
	time.setHolidayScheduleMode(successCb, failureCb, options);
}

/**
 *
 * Time#getHolidayScheduleMode
 *
 */

function getHolidayScheduleMode () {
    document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var time = new Time();
	time.getHolidayScheduleMode(successCb, failureCb);
}


/**
 *
 * Time#addHolidaySchedule
 *
 */


function addHolidaySchedule() {
    Debug_Log("Status" + "<br>"
            + "Success : add HolidaySchedule<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "startMonth : <textarea rows='1' cols = '6' style='font-size:75%' id = 'startMonth'></textarea><br>" +
        "startDay : <textarea rows='1' cols = '6' style='font-size:75%' id = 'startDay'></textarea><br>" +
        "endMonth : <textarea rows='1' cols = '6' style='font-size:75%' id = 'endMonth'></textarea><br>" +
        "endDay : <textarea rows='1' cols = '6' style='font-size:75%' id = 'endDay'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doAddHolidaySchedule()'>Add HolidaySchedule</button>";
}


function doAddHolidaySchedule () {

	var options = {};
    options.startMonth = parseInt(document.getElementById('startMonth').value);
    options.startDay = parseInt(document.getElementById('startDay').value);
    options.endMonth = parseInt(document.getElementById('endMonth').value);
    options.endDay = parseInt(document.getElementById('endDay').value);

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "startMonth : " + options.startMonth + "<br>"
                + "startDay : " + options.startDay + "<br>"
                + "endMonth : " + options.endMonth + "<br>"
                + "endDay : " + options.endDay + "<br>"
                );
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}
	var time = new Time();
	time.addHolidaySchedule(successCb, failureCb, options);
}


/**
 *
 * Time#delHolidaySchedule
 *
 */


function delHolidaySchedule() {
    Debug_Log("Status" + "<br>"
            + "Success : delete HolidaySchedule<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "scheduleId : <textarea rows='1' cols = '6' style='font-size:75%' id = 'scheduleId'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doDelHolidaySchedule()'>Del HolidaySchedule</button>";
}


function doDelHolidaySchedule () {

	var options = {};
    options.scheduleId = document.getElementById('scheduleId').value;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "scheduleId : " + options.scheduleId + "<br>"
                );
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}
	var time = new Time();
	time.delHolidaySchedule(successCb, failureCb, options);
}


/**
 *
 * Time#delAllHolidaySchedule
 *
 */

function delAllHolidaySchedules () {
	document.getElementById("inputForm").innerHTML = "No Input form";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

	var time = new Time();
	time.delAllHolidaySchedules(successCb, failureCb);
}


/**
 *
 * Time#getAllHolidaySchedule
 *
 */

function getAllHolidaySchedules () {
	function successCb(cbObject) {
		var returnStr = '';
        for (var i = cbObject.holidayScheduleList.length-1; i>=0; i--) {
        	returnStr += "holidayScheduleList [" + i + "]._id : " + cbObject.holidayScheduleList[i]._id + '<br>';
            returnStr += "holidayScheduleList [" + i + "].startMonth : " + cbObject.holidayScheduleList[i].startMonth + '<br>';
            returnStr += "holidayScheduleList [" + i + "].startDay : " + cbObject.holidayScheduleList[i].startDay + '<br>';
            returnStr += "holidayScheduleList [" + i + "].endMonth : " + cbObject.holidayScheduleList[i].endMonth + '<br>';
            returnStr += "holidayScheduleList [" + i + "].endDay : " + cbObject.holidayScheduleList[i].endDay + '<br>';
            }
		Debug_Log("Success : " + JSON.stringify(cbObject) + '<br>' + returnStr);
	}

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var time = new Time();
	time.getAllHolidaySchedules(successCb, failureCb);
}

