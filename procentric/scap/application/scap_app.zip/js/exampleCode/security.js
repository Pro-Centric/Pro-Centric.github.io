String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.4.1

***********************************************************************************************************/

/**
 *
 * Security#registerServerCertificate
 *
 */

function registerServerCertificate() {
    Debug_Log("Status" + "<br>"
            + "Success : registerServerCertificate<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
		"userName : <textarea rows='1' cols = '12' style='font-size:75%' id = 'userName'>testserver</textarea><br>" +
		"password : <textarea rows='1' cols = '12' style='font-size:75%' id = 'password'>passCode1</textarea><br>" +
        "certificate : <textarea rows='20' cols = '17' style='font-size:75%' id = 'certificate'>" +
	   "-----BEGIN CERTIFICATE-----\n" +
	   "MIIDeTCCAmGgAwIBAgIJAPziuikCTox4MA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNV\n" +
	   "BAYTAlVTMRMwEQYDVQQIDApDYWxpZm9ybmlhMRYwFAYDVQQHDA1TYW4gRnJhbmNp\n" +
	   "c2NvMQ8wDQYDVQQKDAZCYWRTU0wxFTATBgNVBAMMDCouYmFkc3NsLmNvbTAeFw0x\n" +
	   "OTEwMDkyMzQxNTJaFw0yMTEwMDgyMzQxNTJaMGIxCzAJBgNVBAYTAlVTMRMwEQYD\n" +
	   "VQQIDApDYWxpZm9ybmlhMRYwFAYDVQQHDA1TYW4gRnJhbmNpc2NvMQ8wDQYDVQQK\n" +
	   "DAZCYWRTU0wxFTATBgNVBAMMDCouYmFkc3NsLmNvbTCCASIwDQYJKoZIhvcNAQEB\n" +
	   "BQADggEPADCCAQoCggEBAMIE7PiM7gTCs9hQ1XBYzJMY61yoaEmwIrX5lZ6xKyx2\n" +
	   "PmzAS2BMTOqytMAPgLaw+XLJhgL5XEFdEyt/ccRLvOmULlA3pmccYYz2QULFRtMW\n" +
	   "hyefdOsKnRFSJiFzbIRMeVXk0WvoBj1IFVKtsyjbqv9u/2CVSndrOfEk0TG23U3A\n" +
	   "xPxTuW1CrbV8/q71FdIzSOciccfCFHpsKOo3St/qbLVytH5aohbcabFXRNsKEqve\n" +
	   "ww9HdFxBIuGa+RuT5q0iBikusbpJHAwnnqP7i/dAcgCskgjZjFeEU4EFy+b+a1SY\n" +
	   "QCeFxxC7c3DvaRhBB0VVfPlkPz0sw6l865MaTIbRyoUCAwEAAaMyMDAwCQYDVR0T\n" +
	   "BAIwADAjBgNVHREEHDAaggwqLmJhZHNzbC5jb22CCmJhZHNzbC5jb20wDQYJKoZI\n" +
	   "hvcNAQELBQADggEBAGlwCdbPxflZfYOaukZGCaxYK6gpincX4Lla4Ui2WdeQxE95\n" +
	   "w7fChXvP3YkE3UYUE7mupZ0eg4ZILr/A0e7JQDsgIu/SRTUE0domCKgPZ8v99k3A\n" +
	   "vka4LpLK51jHJJK7EFgo3ca2nldd97GM0MU41xHFk8qaK1tWJkfrrfcGwDJ4GQPI\n" +
	   "iLlm6i0yHq1Qg1RypAXJy5dTlRXlCLd8ufWhhiwW0W75Va5AEnJuqpQrKwl3KQVe\n" +
	   "wGj67WWRgLfSr+4QG1mNvCZb2CkjZWmxkGPuoP40/y7Yu5OFqxP5tAjj4YixCYTW\n" +
	   "EVA0pmzIzgBg+JIe3PdRy27T0asgQW/F4TY61Yk=\n" +
	   "-----END CERTIFICATE-----" +
		"</textarea><br>" +
        "<button style='font-size:100%' onclick = 'doRegisterServerCertificate()'>RegisterServerCertificate</button>";
}


function doRegisterServerCertificate () {

	var options = {};
	options.userName = document.getElementById('userName').value;
	options.password = document.getElementById('password').value;
    options.certificate = document.getElementById('certificate').value;

    function successCb() {
        Debug_Log("registerServerCertificate Success.<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var security = new Security();
	security.registerServerCertificate(successCb, failureCb, options);
}


/**
 *
 * Security#unregisterServerCertificate
 *
 */

function unregisterServerCertificate() {
    Debug_Log("Status" + "<br>"
            + "Success : unregisterServerCertificate<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
		"userName : <textarea rows='1' cols = '12' style='font-size:75%' id = 'userName'>testserver</textarea><br>" +
		"password : <textarea rows='1' cols = '12' style='font-size:75%' id = 'password'>passCode1</textarea><br>" +
        "<button style='font-size:100%' onclick = 'doUnregisterServerCertificate()'>unregisterServerCertificate</button>";
}


function doUnregisterServerCertificate () {

	var options = {};
	options.userName = document.getElementById('userName').value;
	options.password = document.getElementById('password').value;

    function successCb() {
        Debug_Log("unregisterServerCertificate Success.<br>");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var security = new Security();
	security.unregisterServerCertificate(successCb, failureCb, options);
}


/**
 *
 * Security#existServerCertificate
 *
 */

function existServerCertificate() {
    Debug_Log("Status" + "<br>"
            + "Success : existServerCertificate<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
		"userName : <textarea rows='1' cols = '12' style='font-size:75%' id = 'userName'>testserver</textarea><br>" +
		"password : <textarea rows='1' cols = '12' style='font-size:75%' id = 'password'>passCode1</textarea><br>" +
        "<button style='font-size:100%' onclick = 'doExistServerCertificate()'>existServerCertificate</button>";
}

function doExistServerCertificate () {

	var options = {};
	options.userName = document.getElementById('userName').value;
	options.password = document.getElementById('password').value;

    function successCb(cbObject) {
		var userName = cbObject.userName;
		var exist = cbObject.exist;
		Debug_Log("existServerCertificate Success.<br>" + "return value { userName : " + userName + ", exist : " + exist + " }");
    }

	function failureCb(cbObject) {
		var errorCode = cbObject.errorCode;
		var errorText = cbObject.errorText;
		Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
	}

	var security = new Security();
	security.existServerCertificate(successCb, failureCb, options);
}

