String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}

/***********************************************************************************************************

  SCAP v1.3

***********************************************************************************************************/

// Content Rotation only (not osd)


function setContentRotationOnly() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = 'Degree : <select id="degree" style = "font-size : 100%;">'
                                                   + '<option>off</option>'
                                                   + '<option>90</option>'
                                                   + '<option>270</option>'
                                                   + '</select><br>'
                                                   + 'Aspect Ratio : <select id="aspectRatio" style = "font-size : 100%;">'
                                                   + '<option>Full</option>'
                                                   + '<option>Original</option>'
                                                   + '</select><br>'
                                                   + "<button style='font-size:100%' onclick = 'doSetContentRotationOnly()'>Set Content Rotatio Only</button>"; 
}

function doSetContentRotationOnly () {
    var options = {
        degree : document.getElementById('degree').value,
        aspectRatio : document.getElementById('aspectRatio').value.toLowerCase()
    };

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    function successCb() {
        var options = {
            portraitMode: 'off'
        };

        var OSDsuccessCb = function (){
            Debug_Log("Success. No Callback return value.<br>");
        };

        var signage = new Signage();
        signage.setPortraitMode(OSDsuccessCb, failureCb, options);
    }

    var video = new Video();
    video.setContentRotation(successCb, failureCb, options);
}

function setVideoViewTransform() {
    Debug_Log("Status" + "<br>"
            + "Success : Set video size and position in video tag<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "x : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'x'></textarea><br>" +
        "y : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'y'></textarea><br>" +
        "Width : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'w'></textarea><br>" +
        "Height: <textarea rows='1' cols = '10' style='font-size:75%'  id = 'h'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetVideoViewTransform()'>Set Video View Transform</button>";
}

function doSetVideoViewTransform() {
    var options = {};

    if (document.getElementById('x').value !== "")
        options.x      = parseInt(document.getElementById('x').value);
    if (document.getElementById('y').value !== "")
        options.y      = parseInt(document.getElementById('y').value);
    if (document.getElementById('w').value !== "")
        options.width  = parseInt(document.getElementById('w').value);
    if (document.getElementById('h').value !== "")
        options.height = parseInt(document.getElementById('h').value);

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var video = new Video();
    video.setVideoViewTransform(successCb, failureCb, options);
}


function setRotatedVideoTransform() {
    Debug_Log("Status" + "<br>"
            + "Success : Set rotated video size and position in video tag<br>"
            + "Failure : ErrorCode and ErrorText message<br>"
            + "Note : Must applied Content Rotation first.");

    document.getElementById("inputForm").innerHTML =
        "x : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'x'></textarea><br>" +
        "y : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'y'></textarea><br>" +
        "Width : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'w'></textarea><br>" +
        "Height: <textarea rows='1' cols = '10' style='font-size:75%'  id = 'h'></textarea><br>" +
        "<button style='font-size:100%' onclick = 'doSetRotatedVideoTransform()'>Set Portrait Video Transform</button>";
}

function doSetRotatedVideoTransform() {
    var options = {};

    if (document.getElementById('x').value !== "")
        options.x      = parseInt(document.getElementById('x').value);
    if (document.getElementById('y').value !== "")
        options.y      = parseInt(document.getElementById('y').value);
    if (document.getElementById('w').value !== "")
        options.width  = parseInt(document.getElementById('w').value);
    if (document.getElementById('h').value !== "")
        options.height = parseInt(document.getElementById('h').value);

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var video = new Video();
    video.setRotatedVideoTransform(successCb, failureCb, options);
}

/**
 *
 * Video#setContentRotation
 *
 */

function setContentRotation() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = 'Degree : <select id="degree" style = "font-size : 100%;">'
                                                   + '<option>off</option>'
                                                   + '<option>90</option>'
                                                   + '<option>270</option>'
                                                   + '</select><br>'
                                                   + 'Aspect Ratio : <select id="aspectRatio" style = "font-size : 100%;">'
                                                   + '<option>Full</option>'
                                                   + '<option>Original</option>'
                                                   + '</select><br>'
                                                   + "<button style='font-size:100%' onclick = 'doSetContentRotation()'>Set Content Rotation</button>"; 
}

function doSetContentRotation () {
    var options = {
        degree : document.getElementById('degree').value,
        aspectRatio : document.getElementById('aspectRatio').value.toLowerCase()
    };

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var video = new Video();
    video.setContentRotation(successCb, failureCb, options);
}

/**
 *
 * Video#getContentRotation
 *
 */

function getContentRotation () {
  function successCb(cbObject) {
      Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
                + "Degree : " + cbObject.degree + "<br>"
                + "Aspect Ratio : " + cbObject.aspectRatio);
  }

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
     Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var video = new Video();
  video.getContentRotation(successCb, failureCb);
}

/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/

/*******************************************************************************
 *
 * Video#getVideoStatus
 *
 */

function getVideoStatus () {
  function successCb(cbObject) {
      Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>"
              + "X : " + cbObject.source.x + "<br>"
              + "Y : " + cbObject.source.y + "<br>"
              + "Width  : " + cbObject.source.width + "<br>"
              + "Height : " + cbObject.source.height);
  }

  function failureCb(cbObject) {
     var errorCode = cbObject.errorCode;
     var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
  }

  var video = new Video();
  video.getVideoStatus(successCb, failureCb);
}

/*******************************************************************************
 *
 * Video#setVideoSize
 *
 *
 */
function setVideoSize() {
	Debug_Log("Status" + "<br>"
		    + "Success : Zoom in/out video (Emulator cannot support)<br>"
		    + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "" +
    "x : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'x'></textarea><br>"+
    "y : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'y'></textarea><br>"+
    "Width : <textarea rows='1' cols = '10' style='font-size:75%'  id = 'w'></textarea><br>"+
    "Height: <textarea rows='1' cols = '10' style='font-size:75%'  id = 'h'></textarea><br>"+
    "<button style='font-size:100%' onclick = 'doSetVideoSize()'>Set Video Size</button>";

}

function doSetVideoSize() {
    var options = {
        source : {}
    };

    if (document.getElementById('x').value !== "")
    	options.source.x      = parseInt(document.getElementById('x').value);
    if (document.getElementById('y').value !== "")
    	options.source.y      = parseInt(document.getElementById('y').value);
    if (document.getElementById('w').value !== "")
    	options.source.width  = parseInt(document.getElementById('w').value);
    if (document.getElementById('h').value !== "")
    	options.source.height = parseInt(document.getElementById('h').value);

    function successCb() {
        Debug_Log("Success. No Return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var video = new Video();
    video.setVideoSize(successCb, failureCb, options);
}

