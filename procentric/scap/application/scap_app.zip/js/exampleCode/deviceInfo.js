String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}

function Debug_Log(str, isErr) {
    if (isErr) {
        console.error(str.replaceAll('<br>', '\n'));
        str = '<font color=#FF0000>' + str + '</font>';
    }
    else
        console.log(str.replaceAll('<br>', '\n'));
    document.getElementById("status").innerHTML = str;
}


/***********************************************************************************************************

  SCAP v1.4

***********************************************************************************************************/

/**
 *
 * deviceInfo#setProxyInfo
 *
 */

function setProxyInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set proxy settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled' checked>Enable proxy<br>"  +
                                                     "ipAddress : <textarea rows='1' cols = '18' style='font-size:75%' id = 'ipAddress'>10.186.122.45</textarea><br>" +
                                                     "port : <textarea rows='1' cols = '9' style='font-size:75%' id = 'port'>3128</textarea><br>" +
                                                     "userName : <textarea rows='1' cols = '18' style='font-size:75%' id = 'userName'>junyoung</textarea><br>" +
                                                     "password : <input type='password' rows='1' cols = '18' style='font-size:75%' id = 'password' value='junyoung'></form><br>" +
                                                     "<button style='font-size:100%' onclick = 'doSetProxyInfo()'>Set Proxy</button>";
}


function doSetProxyInfo() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        enabled : document.getElementById('enabled').checked,
        ipAddress : document.getElementById('ipAddress').value,
        port : parseInt(document.getElementById('port').value),
        userName : document.getElementById('userName').value,
        password : document.getElementById('password').value
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.setProxyInfo(successCb, failureCb, options);
}

/**
 *
 * deviceInfo#getProxyInfo
 *
 */


function getProxyInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getProxyInfo()";

    function successCb(cbObject) {
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 5) + "<br>" +
                  "Enabled : " + cbObject.enabled + '<br>' +
                  "ipAddress : " + cbObject.ipAddress + '<br>' +
                  "port : " + cbObject.port + '<br>');
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getProxyInfo(successCb, failureCb);
}

/**
 *
 * deviceInfo#getBeaconInfo
 *
 */

function getBeaconInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getBeaconInfo()";

    function successCb(cbObject) {
        var formattedUUID = cbObject.uuid.substr(0,8) + '-' + cbObject.uuid.substr(8,8) + '-' + cbObject.uuid.substr(16,8) + '-' + cbObject.uuid.substr(24,8);
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 4) + "<br>" +
                  "Enabled : " + cbObject.enabled + '<br>' +
                  "Formatted UUID : " + formattedUUID + '<br>' +
                  "UUID : " + cbObject.uuid + '<br>' +
                  "Major : " + cbObject.major + '<br>' +
                  "Minor : " + cbObject.minor);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getBeaconInfo(successCb, failureCb);
}


/**
 *
 * deviceInfo#setiBeaconInfo
 *
 */

function setiBeaconInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled'>Enable iBeacon</form><br>"  +
                                                     "UUID : <textarea rows='1' cols = '18' style='font-size:75%' id = 'uuid'></textarea><br>" +
                                                     "Major (0~65535) : <textarea rows='1' cols = '9' style='font-size:75%'  id = 'major'></textarea><br>" +
                                                     "Minor (0~65535) : <textarea rows='1' cols = '9' style='font-size:75%'  id = 'minor'></textarea><br><br>" +
                                                     "<button style='font-size:100%' onclick = 'doSetiBeaconInfo()'>Set Beacon</button>";
}

function doSetiBeaconInfo() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        enabled : document.getElementById('enabled').checked,
        uuid : document.getElementById('uuid').value,
        major : parseInt(document.getElementById('major').value),
        minor : parseInt(document.getElementById('minor').value),
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.setiBeaconInfo(successCb, failureCb, options);
}


/**
 *
 * deviceInfo#getiBeaconInfo
 *
 */

function getiBeaconInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getiBeaconInfo()";

    function successCb(cbObject) {
        var formattedUUID = cbObject.uuid.substr(0,8) + '-' + cbObject.uuid.substr(8,8) + '-' + cbObject.uuid.substr(16,8) + '-' + cbObject.uuid.substr(24,8);
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 4) + "<br>" +
                  "Enabled : " + cbObject.enabled + '<br>' +
                  "Formatted UUID : " + formattedUUID + '<br>' +
                  "UUID : " + cbObject.uuid + '<br>' +
                  "Major : " + cbObject.major + '<br>' +
                  "Minor : " + cbObject.minor);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getiBeaconInfo(successCb, failureCb);
}


/**
 *
 * deviceInfo#setEddystoneInfo
 *
 */


function setEddystoneInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled'>Enable Eddystone</form><br>"  +
                                                     'frame : <select id="frame"  style = "font-size : 50%;">' +
					                                          '<option>DeviceInfo.EddystoneFrame.UUID</option>' +
					                                          '<option>DeviceInfo.EddystoneFrame.URL</option>' +
					                                          '</select><br>' +
                                                     "frameData : <textarea rows='1' cols = '18' style='font-size:75%' id = 'frameData'></textarea><br>" +
                                                     "<button style='font-size:100%' onclick = 'doSetEddystoneInfo()'>Set Eddystone</button>";
}

function doSetEddystoneInfo() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        enabled : document.getElementById('enabled').checked,
        frame : document.getElementById('frame').value,
        frameData : document.getElementById('frameData').value
    };

    switch (options.frame) {
            case "DeviceInfo.EddystoneFrame.UUID" :
                options.frame = DeviceInfo.EddystoneFrame.UUID;
                break;
            case "DeviceInfo.EddystoneFrame.URL" :
                options.frame = DeviceInfo.EddystoneFrame.URL;
                break;
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.setEddystoneInfo(successCb, failureCb, options);
}


/**
 *
 * deviceInfo#getEddystoneInfo
 *
 */


function getEddystoneInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getEddystoneInfo()";

    function successCb(cbObject) {
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 3) + "<br>" +
                  "Enabled : " + cbObject.enabled + '<br>' +
                  "frame : " + (cbObject.frame==="uid"?"DeviceInfo.EddystoneFrame.UUID":"DeviceInfo.EddystoneFrame.URL") + '<br>' +
                  "frameData : " + cbObject.frameData);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getEddystoneInfo(successCb, failureCb);
}


/***********************************************************************************************************

  SCAP v1.3

***********************************************************************************************************/

/**
 *
 * deviceInfo#setNetworkInfo
 *
 */

function setNetworkInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML =
        "Wired<br>" +
        "<form><input type='checkbox' id='wired_enabled'>Enable Wired</form>"  +
        'Method : <select id="wired_method"  style = "font-size : 100%;">' +
        '<option>DHCP</option>' +
        '<option>Manual</option>' +
        '</select><br>' +
        "IP Address : <textarea rows='1' cols = '18' style='font-size:75%' id = 'wired_ipAddress'></textarea><br>" +
        "Netmask : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wired_netmask'></textarea><br>" +
        "Gateway : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wired_gateway'></textarea><br>" +
        "DNS 1 : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wired_dns1'></textarea><br>" +
        "DNS 2 : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wired_dns2'></textarea><br><br>" +
        "Wireless<br>" +
        "<form><input type='checkbox' id='wireless_enabled'>Enable Wireless</form>"  +
        'Method : <select id="wireless_method"  style = "font-size : 100%;">' +
        '<option>DHCP</option>' +
        '<option>Manual</option>' +
        '</select><br>' +
        "IP Address : <textarea rows='1' cols = '18' style='font-size:75%' id = 'wireless_ipAddress'></textarea><br>" +
        "Netmask : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wireless_netmask'></textarea><br>" +
        "Gateway : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wireless_gateway'></textarea><br>" +
        "DNS 1 : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wireless_dns1'></textarea><br>" +
        "DNS 2 : <textarea rows='1' cols = '18' style='font-size:75%'  id = 'wireless_dns2'></textarea><br><br>" +
        "<button style='font-size:100%' onclick = 'doSetNetworkInfo()'>Set Network Info</button>";
}

function doSetNetworkInfo () {
    var options = {},
        wired = {},
        wifi = {};

        wired.enabled = document.getElementById('wired_enabled').checked;
        wired.method = document.getElementById('wired_method').value.toLowerCase();
        wired.ipAddress = (document.getElementById('wired_ipAddress').value !== '') ? document.getElementById('wired_ipAddress').value : undefined;
        wired.netmask = (document.getElementById('wired_netmask').value !== '') ? document.getElementById('wired_netmask').value : undefined;
        wired.gateway = (document.getElementById('wired_gateway').value !== '') ? document.getElementById('wired_gateway').value : undefined;
        wired.dns1 = (document.getElementById('wired_dns1').value !== '') ? document.getElementById('wired_dns1').value : undefined;
        wired.dns2 = (document.getElementById('wired_dns2').value !== '') ? document.getElementById('wired_dns2').value : undefined;

        wifi.enabled = document.getElementById('wireless_enabled').checked;
        wifi.method = document.getElementById('wireless_method').value.toLowerCase();
        wifi.ipAddress = (document.getElementById('wireless_ipAddress').value !== '') ? document.getElementById('wireless_ipAddress').value : undefined;
        wifi.netmask = (document.getElementById('wireless_netmask').value !== '') ? document.getElementById('wireless_netmask').value : undefined;
        wifi.gateway = (document.getElementById('wireless_gateway').value !== '') ? document.getElementById('wireless_gateway').value : undefined;
        wifi.dns1 = (document.getElementById('wireless_dns1').value !== '') ? document.getElementById('wireless_dns1').value : undefined;
        wifi.dns2 = (document.getElementById('wireless_dns2').value !== '') ? document.getElementById('wireless_dns2').value : undefined;


    options.wired = wired;
    options.wifi = wifi;

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>"
                + "Wired : " + JSON.stringify(wired) + "<br><br>"
                + "Wifi  : " + JSON.stringify(wifi) + "<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.setNetworkInfo(successCb, failureCb, options);
}

/**
 *
 * deviceInfo#getWifiList
 *
 */

function getWifiList() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getWifiList()";

    function successCb(cbObject) {
        var returnStr = '';
        for(var i=0; i < cbObject.networkInfo.length; i++) {
            returnStr += '[' + (i+1) + '] SSID : ' + cbObject.networkInfo[i].ssid + '<br>';
            returnStr += '[' + (i+1) + '] SignalLevel : ' + cbObject.networkInfo[i].signalLevel + '<br>';
        }
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" + returnStr);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getWifiList(successCb, failureCb);
}

/**
 *
 * deviceInfo#connectWifi
 *
 */

function connectWifi() {
    Debug_Log("Status" + "<br>"
            + "Success : Connect wifi<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "SSID     : <textarea rows='1' cols = '18' style='font-size:75%' id = 'ssid'></textarea><br>"
                                                   + "Password : <textarea rows='1' cols = '14' style='font-size:75%' id = 'pass'></textarea><br>"
                                                   + "<form>Hidden   : <input type='checkbox' id='hidden'></form><br>"
                                                   + "<button style='font-size:100%' onclick = 'doConnectWifi()'>Connect to Wifi</button>";
}


function doConnectWifi() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    };

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    };

    var options = {
        ssid : document.getElementById('ssid').value,
        password : document.getElementById('pass').value,
        hidden : document.getElementById('hidden').checked
     };


    var deviceInfo = new DeviceInfo();
    deviceInfo.connectWifi(successCb, failureCb, options);
}

/**
 *
 * deviceInfo#startWps
 *
 */


function startWps() {
    Debug_Log("Status" + "<br>"
            + "Success : Start Wifi Protected Setup<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = 'Method : <select id="method"  style = "font-size : 100%;">'
                                                   + '<option>PBC</option>'
                                                   + '<option>PIN</option>'
                                                   + '</select><br>'
                                                   + "<button style='font-size:100%' onclick = 'doStartWps()'>Start Wifi Protected Setup</button>";
}

function doStartWps() {
    function successCb(cbObject) {
        Debug_Log("Success. If PIN method is used, return value exists.<br>" + JSON.stringify(cbObject));
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
      method : document.getElementById('method').value
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.startWps(successCb, failureCb, options);
}

/**
 *
 * deviceInfo#stopWps
 *
 */

function stopWps() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>stopWps()";

    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.stopWps(successCb, failureCb);
}

/**
 *
 * deviceInfo#getBeaconInfo
 *
 */

function getBeaconInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getBeaconInfo()";

    function successCb(cbObject) {
        var formattedUUID = cbObject.uuid.substr(0,8) + '-' + cbObject.uuid.substr(8,8) + '-' + cbObject.uuid.substr(16,8) + '-' + cbObject.uuid.substr(24,8);
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 4) + "<br>" +
                  "Enabled : " + cbObject.enabled + '<br>' +
                  "Formatted UUID : " + formattedUUID + '<br>' +
                  "UUID : " + cbObject.uuid + '<br>' +
                  "Major : " + cbObject.major + '<br>' +
                  "Minor : " + cbObject.minor);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getBeaconInfo(successCb, failureCb);
}

/**
 *
 * deviceInfo#setBeaconInfo
 *
 */

function setBeaconInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled'>Enable Beacon</form><br>"  +
                                                     "UUID : <textarea rows='1' cols = '18' style='font-size:75%' id = 'uuid'></textarea><br>" +
                                                     "Major (0~65535) : <textarea rows='1' cols = '9' style='font-size:75%'  id = 'major'></textarea><br>" +
                                                     "Minor (0~65535) : <textarea rows='1' cols = '9' style='font-size:75%'  id = 'minor'></textarea><br><br>" +
                                                     "<button style='font-size:100%' onclick = 'doSetBeaconInfo()'>Set Beacon</button>";
}

function doSetBeaconInfo() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        enabled : document.getElementById('enabled').checked,
        uuid : document.getElementById('uuid').value,
        major : parseInt(document.getElementById('major').value),
        minor : parseInt(document.getElementById('minor').value),
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.setBeaconInfo(successCb, failureCb, options);
}

/**
 *
 * deviceInfo#getSoftApInfo
 *
 */

function getSoftApInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getSoftApInfo()";

    function successCb(cbObject) {
        Debug_Log("Success. " + JSON.stringify(cbObject, null, 4) + '<br>'
                + "Enabled : " + cbObject.enabled + '<br>'
                + "SSID : " + cbObject.ssid + '<br>'
                + "Security Key : " + cbObject.securityKey);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getSoftApInfo(successCb, failureCb);
}

/**
 *
 * deviceInfo#setSoftApInfo
 *
 */

function setSoftApInfo() {
    Debug_Log("Status" + "<br>"
            + "Success : Set network settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled'>Enable SoftAP</form><br>"
                                                   + "SSID : <textarea rows='1' cols = '18' style='font-size:75%' id = 'ssid'></textarea><br>"
                                                   + "Security Key (LG######)<br>(Input 6 Character) : <textarea rows='1' cols = '9' style='font-size:75%'  id = 'securityKey'></textarea><br>"
                                                   + "<button style='font-size:100%' onclick = 'doSetSoftApInfo()'>Set SoftAP</button>";
}

function doSetSoftApInfo() {
    function successCb() {
        Debug_Log("Success. No Callback return value.<br>");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
      enabled : document.getElementById('enabled').checked,
      ssid : document.getElementById('ssid').value,
      securityKey : document.getElementById('securityKey').value
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.setSoftApInfo(successCb, failureCb, options);
}

/***********************************************************************************************************

  SCAP v1.2 and below version

***********************************************************************************************************/


/**
 *
 * deviceInfo#getNetworkInfo
 *
 */

function getNetworkInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getNetworkInfo()";

    function successCb(cbObject) {
        var successMessage = "Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
                  "isInternetConnectionAvailable : " + cbObject.isInternetConnectionAvailable + "<br>" +
                  "wired.state : " + cbObject.wired.state + "<br>" +
                  "wired.method : " + cbObject.wired.method + "<br>" +
                  "wired.ipAddress : " + cbObject.wired.ipAddress + "<br>" +
                  "wired.netmask : " + cbObject.wired.netmask + "<br>" +
                  "wired.dns1 : " + cbObject.wired.dns1 + "<br>" +
                  "wired.dns2 : " + cbObject.wired.dns2 + "<br>" +
                  "wifi.state : " + cbObject.wifi.state + "<br>" +
                  "wifi.method : " + cbObject.wifi.method + "<br>" +
                  "wifi.ipAddress : " + cbObject.wifi.ipAddress + "<br>" +
                  "wifi.netmask : " + cbObject.wifi.netmask + "<br>" +
                  "wifi.dns1 : " + cbObject.wifi.dns1 + "<br>" +
                  "wifi.dns2 : " + cbObject.wifi.dns2 + "<br>";

        if(cbObject.wired.hasOwnProperty("dns3") === true)
            successMessage += "wired.dns3 : " + cbObject.wired.dns3 + "<br>";
        if(cbObject.wired.hasOwnProperty("dns4") === true)
            successMessage += "wired.dns4 : " + cbObject.wired.dns4 + "<br>";
        if(cbObject.wired.hasOwnProperty("dns5") === true)
            successMessage += "wired.dns5 : " + cbObject.wired.dns5 + "<br>";
        if(cbObject.wired.hasOwnProperty("ipv6") === true) {
            successMessage += "wired.ipv6.gateway : " + cbObject.wired.ipv6.gateway + "<br>";
            successMessage += "wired.ipv6.ipAddress : " + cbObject.wired.ipv6.ipAddress + "<br>";
            successMessage += "wired.ipv6.prefixLength : " + cbObject.wired.ipv6.prefixLength + "<br>";
            successMessage += "wired.ipv6.method : " + cbObject.wired.ipv6.method + "<br>";
        }

        Debug_Log(successMessage);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getNetworkInfo(successCb, failureCb);

}

/**
 *
 * deviceInfo#getNetworkMacInfo
 *
 */

function getNetworkMacInfo () {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getNetworkMacInfo()";
      function successCb(cbObject) {
          Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>");

          if (cbObject.wiredInfo)
              document.getElementById("status").innerHTML += "wiredInfo.macAddress : " + cbObject.wiredInfo.macAddress + "<br>";
          if (cbObject.wifiInfo)
              document.getElementById("status").innerHTML += "wifiInfo.macAddress : " + cbObject.wifiInfo.macAddress + "<br>";
      }

      function failureCb(cbObject) {
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
            Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
      }

      var deviceInfo = new DeviceInfo();
      deviceInfo.getNetworkMacInfo(successCb, failureCb);
}

/**
 *
 * deviceInfo#getPlatformInfo
 *
 */

function getPlatformInfo () {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getPlatformInfo()";
      function successCb(cbObject) {

            Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
                      "hardwareVersion : " + cbObject.hardwareVersion + "<br>" +
                      "modelName: " + cbObject.modelName + "<br>" +
                      "sdkVersion : " + cbObject.sdkVersion + "<br>" +
                      "serialNumber : " + cbObject.serialNumber + "<br>" +
                      "firmwareVersion : " + cbObject.firmwareVersion + "<br>" +
                      "manufacturer : " + cbObject.manufacturer);
      }

      function failureCb(cbObject) {
         var errorCode = cbObject.errorCode;
         var errorText = cbObject.errorText;
            Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
      }

      var deviceInfo = new DeviceInfo();
      deviceInfo.getPlatformInfo(successCb, failureCb);
}


/**
 *
 * deviceInfo#getSystemUsageInfo
 *
 */

function getSystemUsageInfo () {
    Debug_Log("");
    document.getElementById("inputForm").innerHTML = "" +
                            "CPU : <input type='checkbox' id = 'cpu'><br>" +
                            "Memory: <input type='checkbox' id = 'mem'><br>" +
                            "<button style='font-size:100%' onclick = 'doGetSystemUsageInfo()'>Get System Usage Infomation</button>";
}

function doGetSystemUsageInfo() {

    function successCb(cbObject) {
        var returnStr = '';
        returnStr += "Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>";

        if (cbObject.memory) {
            returnStr += "memory.total : " + cbObject.memory.total + "<br>" + "memory.free : " + cbObject.memory.free + "<br><br>";
        }
        if (cbObject.cpus) {
            document.getElementById("status").innerHTML += "<div id = 'cpus' style='font-size:75%;'></div>";
            for (var i in cbObject.cpus) {
                returnStr += "cpu.model " +  cbObject.cpus[i].model + "<br>" +
                             "cpu.times.user " + cbObject.cpus[i].times.user + "<br>" +
                             "cpu.times.nice " + cbObject.cpus[i].times.nice + "<br>" +
                             "cpu.times.sys " + cbObject.cpus[i].times.sys + "<br>" +
                             "cpu.times.idle " + cbObject.cpus[i].times.idle + "<br>" +
                             "cpu.times.irq " + cbObject.cpus[i].times.irq+ "<br>";
                document.getElementById("cpus").innerHTML += "cpu.model " + cbObject.cpus[i].model + "<br>" +
                                                             "cpu.times.user " + cbObject.cpus[i].times.user + "<br>" +
                                                             "cpu.times.nice " + cbObject.cpus[i].times.nice + "<br>" +
                                                             "cpu.times.sys " + cbObject.cpus[i].times.sys + "<br>" +
                                                             "cpu.times.idle " + cbObject.cpus[i].times.idle + "<br>" +
                                                             "cpu.times.irq " + cbObject.cpus[i].times.irq+ "<br>";
            }
        }
        Debug_Log(returnStr);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    var options = {
        cpus   : document.getElementById('cpu').checked,
        memory : document.getElementById('mem').checked
    };
    deviceInfo.getSystemUsageInfo(successCb, failureCb, options);
}

/***********************************************************************************************************

  SCAP v1.5

***********************************************************************************************************/

/**
 *
 * deviceInfo#getStationInfo
 *
 */

function getStationInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getStationInfo()";

    function successCb(cbObject) {
        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
            "stationMacAddress : " + cbObject.stationMacAddress + "<br>" +
            "softapEnabled: " + cbObject.softapEnabled + "<br>" +
            "stationCount : " + cbObject.stationCount);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getStationInfo(successCb, failureCb);
}

/**
 *
 * getExternalInputInfo
 *
 */

function getExternalInputInfo() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getExternalInputInfo()";

    function successCb(cbObject) {

        var returnStr = '';
        for(var i=0; i < cbObject.deviceList.length; i++) {
            returnStr += '[' + (i+1) + '] deviceID : ' + cbObject.deviceList[i].deviceID + '<br>';
            returnStr += '[' + (i+1) + '] signalDetection : ' + cbObject.deviceList[i].signalDetection + '<br>';
            returnStr += '[' + (i+1) + '] deviceName : ' + cbObject.deviceList[i].deviceName + '<br>';
        }

        Debug_Log("Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
            "deviceList : " + returnStr + "<br>" +
            "subscribed : " + cbObject.subscribed + "<br>" +
            "totalDeviceNumber: " + cbObject.totalDeviceNumber + "<br>" +
            "mainInputSourceId : " + cbObject.mainInputSourceId);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = { subscribe : true };
    var deviceInfo = new DeviceInfo();
    deviceInfo.getExternalInputInfo(successCb, failureCb. options);
}

/**
 *
 * getSensorValues
 *
 */

function getSensorValues() {
    document.getElementById("inputForm").innerHTML = "No Input form : <br>getSensorValues()";

    function successCb(cbObject) {

        var successMessage = "Success : " + JSON.stringify(cbObject, null, ' ') + "<br><br>" +
                    "Only Supported Sensors will have its Value" + "<br><br>" +
                  "Backlight : " + cbObject.backlight + "<br>" +
                  "Fan : " + JSON.stringify(cbObject.fan) + "<br>" +
                  "Humidity : " + cbObject.humidity + "<br>" +
                  "Door : " + cbObject.door + "<br>" +
                  "Illuminance : " + cbObject.illuminance + "<br>" +
                  "Temperature : " + cbObject.temperature + "<br>" +
                  "checkscreen : " + JSON.stringify(cbObject.checkscreen) + "<br>" +
                  "rotation : " + cbObject.rotation + "<br>";
        Debug_Log(successMessage);
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var deviceInfo = new DeviceInfo();
    deviceInfo.getSensorValues(successCb, failureCb);
}



/**
 *
 * setSensorValues
 *
 */

function setSensorValues() {
    Debug_Log("Status" + "<br>"
            + "Success : Set proxy settings<br>"
            + "Failure : ErrorCode and ErrorText message");
    document.getElementById("inputForm").innerHTML = "<form><input type='checkbox' id='enabled' checked> Door Reset Enable <br>"  +
                                                     "backlight (0-100): <textarea rows='1' cols = '5' style='font-size:75%' id = 'backlight'>1</textarea></form><br>" +
                                                     "<button style='font-size:100%' onclick = 'dosetSensorValues()'>set SensorValues</button>";
}

function dosetSensorValues() {
    function successCb() {
        Debug_Log("Success. No Callback return value.");
    }

    function failureCb(cbObject) {
        var errorCode = cbObject.errorCode;
        var errorText = cbObject.errorText;
        Debug_Log("Failure : " + "Error Code [" + errorCode + "]: " + errorText, true);
    }

    var options = {
        doorReset : document.getElementById('enabled').checked,
        backlight : parseInt(document.getElementById('backlight').value)
    };

    var deviceInfo = new DeviceInfo();
    deviceInfo.setSensorValues(successCb, failureCb, options);
}