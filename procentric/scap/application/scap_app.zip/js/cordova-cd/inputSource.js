/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the InputSource API itself, and provides a global namespace for operating InputSource service.
 * @class
 */

cordova.define("cordova/plugin/broadcast", function (require, exports, module) {
    var service = require("cordova/plugin/webos/service"),
        utils = require("cordova/utils"),
        argscheck = require("cordova/argscheck"),
        broadcast = function (e) {
            this.isATSC = false;
            this.tokenChannelChange = 0;
            this.tokenSignalState = 0;
            this.broadcastDivId = null;
            this.broadcastElement = null;
            this.currentInput = null;
            this.currentSource = null;
            this.isLastInput = true;
            this.isLastChannel = true;
            var that = this;
            service.Request("luna://com.webos.service.tv.systemproperty", {
                method: "getSystemInfo",
                parameters: {
                    keys: ["atsc"]
                },
                onSuccess: function (cbObject) {
                    that.isATSC = cbObject.atsc
                },
                onFailure: function (errorObject) { }
            });
        };
    broadcast.prototype.onchannelchange = function (e) { },
    broadcast.prototype.onsignalstatuschange = function (e) { },
    broadcast.prototype.initialize = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.initialize", arguments);
        var clone_options = utils.clone(options);
        this.broadcastDivId = document.getElementById(clone_options.divId);
        clone_options.broadcastPlugin = this;
        if (1 != clone_options.isLastInput && clone_options.src) {
            this.isLastInput = false
            if (-1 != clone_options.src.indexOf("tv://")) {
                if (1 == clone_options.isLastChannel) {
                    this.isLastChannel = true;
                    clone_options.type = "service/webos-broadcast";
                }
                else {
                    this.isLastChannel = false;
                    clone_options.type = "service/webos-broadcast-standalone"
                }
                this.currentInput = "tv";
                this.currentSource = clone_options.src.substr(5);
            }
            else {
                clone_options.type = "service/webos-external";
                var source_split = clone_options.src.split(":");
                this.currentInput = source_split[1].substr(2).toLowerCase();
                this.currentSource = source_split[2]
            }
            createNewExternalSignalVideoArea(clone_options);
            successCallback && successCallback()
        } else {
            this.isLastInput = true;
            getCurrentInput(successCallback, failureCallback, clone_options)
        }
    },
    broadcast.prototype.channelUp = function (successCallback, failureCallback) {
        argscheck.checkArgs("fF", "broadcastCordova.channelUp", arguments);
        var param = {
            broadcastId: this.broadcastElement.mediaId
        };
        service.Request("luna://com.webos.service.tv.broadcast", {
            method: "changeChannelUp",
            parameters: param,
            onSuccess: function (cbObject) {
                successCallback && successCallback()
            },
            onFailure: function (errorObject) {
                delete errorObject.returnValue;
                failureCallback && failureCallback(errorObject);
            }
        })
    },

    broadcast.prototype.channelDown = function (successCallback, failureCallback) {
        argscheck.checkArgs("fF", "broadcastCordova.channelDown", arguments);
        var param = {
            broadcastId: this.broadcastElement.mediaId
        };
        service.Request("luna://com.webos.service.tv.broadcast", {
            method: "changeChannelDown",
            parameters: param,
            onSuccess: function (cbObject) {
                successCallback && successCallback()
            },
            onFailure: function (errorObject) {
                delete errorObject.returnValue;
                failureCallback && failureCallback(errorObject)
            }
        })
    },

    broadcast.prototype.setChannel = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.setChannel", arguments);
        var param = {
            broadcastId: this.broadcastElement.mediaId,
            channelId: options.id
        };
        service.Request("luna://com.webos.service.tv.broadcast", {
            method: "changeChannel",
            parameters: param,
            onSuccess: function (cbObject) {
                successCallback && successCallback()
            },
            onFailure: function (errorObject) {
                delete errorObject.returnValue;
                failureCallback && failureCallback(errorObject)
            }
        })
    },

    broadcast.prototype.getCurrentChannel = function (successCallback, failureCallback) {
        argscheck.checkArgs("fF", "broadcastCordova.getCurrentChannel", arguments);
        var param = {
            broadcastId: this.broadcastElement.mediaId,
            subscribe: false
        };
        service.Request("luna://com.webos.service.tv.broadcast", {
            method: "getCurrentChannel",
            parameters: param,
            onSuccess: function (cbObject) {
                var returnObject = {};
                returnObject = S(cbObject.channel, "api");
                successCallback && successCallback(returnObject);
            },
            onFailure: function (errorObject) {
                delete errorObject.returnValue;
                failureCallback && failureCallback(errorObject);
            }
        })
    },

    broadcast.prototype.getSignalStatus = function (successCallback, failureCallback) {
        argscheck.checkArgs("fF", "broadcastCordova.getSignalStatus", arguments);
        var param;
        if ("tv" == this.currentInput) {
            param = {
                broadcastId: this.broadcastElement.mediaId,
                subscribe: false
            };
            service.Request("luna://com.webos.service.tv.broadcast", {
                method: "getChannelState",
                parameters: param,
                onSuccess: function (cbObject) {
                    var returnObject = cbObject.channelState;
                    returnObject.screensaverType = returnObject.channelScreensaverType;
                    delete returnObject.channelScreensaverType;
                    successCallback && successCallback(returnObject)
                },
                onFailure: function (errorObject) {
                    delete errorObject.returnValue;
                    failureCallback && failureCallback(errorObject)
                }
            })
        }
        else {
            param = {
                externalInputId: this.broadcastElement.mediaId,
                subscribe: false
            };
            service.Request("luna://com.webos.service.tv.externaldevice/input/", {
                method: "getSignalState",
                parameters: param,
                onSuccess: function (cbObject) {
                    successCallback && successCallback(cbObject.signalState)
                },
                onFailure: function (errorObject) {
                    delete errorObject.returnValue;
                    failureCallback && failureCallback(errorObject)
                }
            })
        }
    },

    broadcast.prototype.getCurrentProgram = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getCurrentProgram", arguments), service.Request("luna://com.palm.systemservice/time", {
            method: "getEffectiveBroadcastTime",
            parameters: {},
            onSuccess: function (cbObject) {
                var returnObject = {};
                returnObject.id = options.id;
                returnObject.startTime = cbObject.localtime;
                returnObject.endTime = cbObject.localtime;
                returnObject.request = "nowInfo";
                getSignalChannelId(successCallback, failureCallback, returnObject)
            },
            onFailure: function (e) {
                delete e.returnValue, failureCallback && failureCallback(e)
            }
        })
    },

    broadcast.prototype.getNextProgram = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getNextProgram", arguments), service.Request("luna://com.palm.systemservice/time", {
            method: "getEffectiveBroadcastTime",
            parameters: {},
            onSuccess: function (r) {
                var a = {};
                a.id = options.id, a.startTime = r.localtime, a.endTime = r.localtime, a.request = "nextInfo", getSignalChannelId(successCallback, failureCallback, a)
            },
            onFailure: function (e) {
                delete e.returnValue, failureCallback && failureCallback(e)
            }
        })
    },

    broadcast.prototype.getProgramCount = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getProgramCount", arguments);
        var r = utils.clone(options);
        r.request = "count";
        getSignalChannelId(successCallback, failureCallback, r)
    },

    broadcast.prototype.getProgramList = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getProgramList", arguments);
        var r = utils.clone(options);
        r.request = "list";
        getSignalChannelId(successCallback, failureCallback, r)
    },

    broadcast.prototype.getChannelCount = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getChannelCount", arguments);
        var param = {
            from: "com.webos.service.tv.channel.dblist:1",
            select: [""],
            where: [{
                prop: "channelType",
                op: "=",
                val: options.type
            }],
            filter: [{
                prop: "Invisible",
                op: "=",
                val: !1
            }]
        };
        service.Request("luna://com.palm.db/", {
            method: "search",
            parameters: {
                query: param
            },
            onSuccess: function (cbObject) {
                var returnObject = {};
                returnObject.count = cbObject.results.length;
                successCallback && successCallback(returnObject)
            },
            onFailure: function (error) {
                delete error.returnValue, failureCallback && failureCallback(error)
            }
        })
    }, broadcast.prototype.getChannelList = function (successCallback, failureCallback, options) {
        argscheck.checkArgs("fFo", "broadcastCordova.getChannelList", arguments);
        var a = options.startIndex - 1;
        if (0 > a)
            a = 0;
        var c = a + options.count,
            param = {
                from: "com.webos.service.tv.channel.dblist:1",
                select: ["channelId", "channelName", "channelMode", "channelNumber", "channelType", "skipped", "locked", "descrambled", "scrambled"],
                where: [{
                    prop: "channelType",
                    op: "=",
                    val: options.type
                }],
                filter: [{
                    prop: "Invisible",
                    op: "=",
                    val: !1
                }],
                limit: c
            };
        service.Request("luna://com.palm.db/", {
            method: "search",
            parameters: {
                query: param
            },
            onSuccess: function (cbObject) {
                var returnObject = {};
                returnObject.channel = [];
                var r = cbObject.results.length - a;
                if (r > 0) {
                    for (var o = 0; r > o; o++)
                        returnObject.channel[o] = S(cbObject.results[o + a], "db8");
                }
                successCallback && successCallback(returnObject)
            },
            onFailure: function (error) {
                delete error.returnValue;
                failureCallback && failureCallback(error)
            }
        })
    }, broadcast.prototype.getChannelListByName = function (successCallback, failureCallback, optioins) {
        argscheck.checkArgs("fFo", "broadcastCordova.getChannelListByName", arguments);
        var param = {
            from: "com.webos.service.tv.channel.dblist:1",
            select: ["channelId", "channelName", "channelMode", "channelNumber", "channelType", "skipped", "locked", "descrambled", "scrambled"],
            where: [{
                prop: "channelName",
                op: "%",
                val: optioins.name
            }],
            filter: [{
                prop: "Invisible",
                op: "=",
                val: false
            }]
        };
        optioins.type && param.filter.push({
            prop: "channelType",
            op: "=",
            val: optioins.type
        }), service.Request("luna://com.palm.db/", {
            method: "search",
            parameters: {
                query: param
            },
            onSuccess: function (cbObject) {
                var returnObject = {};
                if (returnObject.channel = [], cbObject.results.length > 0) {
                    for (var r = 0; r < cbObject.results.length; r++)
                        returnObject.channel[r] = S(cbObject.results[r], "db8");
                }
                successCallback && successCallback(returnObject)
            },
            onFailure: function (errorObject) {
                delete errorObject.returnValue;
                failureCallback && failureCallback(errorObject)
            }
        })
    },

    broadcast.prototype.setInput = function (inputSourceSrc) {
        argscheck.checkArgs("o", "broadcastCordova.setInput", arguments);
        var isSourceIsChanged = false;
        if (-1 != inputSourceSrc.src.indexOf("tv://"))  {
            if (1 == this.isLastChannel)
                inputSourceSrc.type = "service/webos-broadcast"
            else
                inputSourceSrc.type = "service/webos-broadcast-standalone";
            this.currentInput = "tv";
            this.currentSource = inputSourceSrc.src.substr(5);
        }
        else {
            inputSourceSrc.type = "service/webos-external";
            var inputSourceSrcSplit = inputSourceSrc.src.split(":");
            this.currentInput = inputSourceSrcSplit[1].substr(2).toLowerCase();
            this.currentSource = inputSourceSrcSplit[2]
        }
        for (var childNodesCount = 0; childNodesCount < this.broadcastElement.childNodes.length; childNodesCount++) {
            if ("SOURCE" == this.broadcastElement.childNodes[childNodesCount].nodeName) {
                this.broadcastElement.childNodes[childNodesCount].src = inputSourceSrc.src;
                this.broadcastElement.childNodes[childNodesCount].type = inputSourceSrc.type;
                this.broadcastElement.load();
                isSourceIsChanged = true;
            }
        }
        return isSourceIsChanged;
    },

    broadcast.prototype.addEventListener = function (eventListenerName, callback, options) {
        if ("channelchange" == eventListenerName) {
            this.tokenChannelChange = service.Request("luna://com.webos.service.tv.broadcast", {
                method: "getCurrentChannel",
                parameters: {
                    broadcastId: this.broadcastElement.mediaId,
                    subscribe: false
                },
                onSuccess: function (cbObject) {
                    var returnValue = cbObject.channel;
                    callback && callback(returnValue)
                },
                onFailure: function (errorObject) { }
            })
        }
        else if ("signalstatus" == eventListenerName) {
            if ("tv" == this.currentInput) {
                this.tokenSignalState = service.Request("luna://com.webos.service.tv.broadcast", {
                    method: "getChannelState",
                    parameters: {
                        broadcastId: this.broadcastElement.mediaId,
                        subscribe: false
                    },
                    onSuccess: function (cbObject) {
                        var returnObject = cbObject.channelState;
                        returnObject.screensaverType = returnObject.channelScreensaverType;
                        delete returnObject.channelScreensaverType;
                        callback && callback(returnObject);
                    },
                    onFailure: function (errorObject) { }
                });
            }
            else {
                this.tokenSignalState = service.Request("luna://com.webos.service.tv.externaldevice/input/", {
                    method: "getSignalState",
                    parameters: {
                        externalInputId: this.broadcastElement.mediaId,
                        subscribe: true
                    },
                    onSuccess: function (cbObject) {
                        var returnObject = cbObject.signalState;
                        callback && callback(returnObject);
                    },
                    onFailure: function (errorObject) { }
                });
            }
        }
    };
    var loadedmetadataEventHandler = function (broadcastPlugin, callback) {
            h(broadcastPlugin);
            if ("tv" == broadcastPlugin.currentInput) {
                getCurrentChannel(broadcastPlugin);
                getChannelState(broadcastPlugin);
            }
            else {
                getSignalState(broadcastPlugin);
                callback();
            }
        },
        createNewExternalSignalVideoArea = function (options) {
            var newVideoElement = document.createElement("VIDEO");
            newVideoElement.setAttribute("id", options.videoId);
            newVideoElement.setAttribute("width", "100%");
            newVideoElement.setAttribute("height", "100%");
            newVideoElement.setAttribute("autoplay", "");
            newVideoElement.addEventListener("loadedmetadata", function () {
                loadedmetadataEventHandler(options.broadcastPlugin, options.callback)
            }, false);
            var newSourceElement = document.createElement("SOURCE");
            newSourceElement.setAttribute("src", options.src);
            newSourceElement.setAttribute("type", options.type);
            newVideoElement.appendChild(newSourceElement);
            options.broadcastPlugin.broadcastDivId.appendChild(newVideoElement);
            options.broadcastPlugin.broadcastElement = newVideoElement;
        },
        getCurrentInput = function (successCallback, errorCallback, options) {
            service.Request("luna://com.webos.service.eim", {
                method: "getCurrentInput",
                parameters: {},
                onSuccess: function (cbObject) {
                    if ("ATV" == cbObject.mainInputSourceId || "DTV" == cbObject.mainInputSourceId) {
                        options.broadcastPlugin.currentInput = "tv";
                        l(successCallback, errorCallback, options);
                    }
                    else {
                        var mainInputSourceId_SplitArr = cbObject.mainInputSourceId.split("_");
                        options.broadcastPlugin.currentInput = mainInputSourceId_SplitArr[0].toLowerCase();
                        options.broadcastPlugin.currentSource = mainInputSourceId_SplitArr[1];
                        options.src = "ext://" + options.broadcastPlugin.currentInput + ":" + options.broadcastPlugin.currentSource;
                        options.type = "service/webos-external";
                        createNewExternalSignalVideoArea(options);
                        successCallback && successCallback();
                    }
                },
                onFailure: function (errorObject) {
                    delete errorObject.returnValue;
                    errorCallback && errorCallback(errorObject);
                }
            })
        },
        l = function (e, t, n) { },
        getCurrentChannel = function (e) {
            e.tokenChannelChange = service.Request("luna://com.webos.service.tv.broadcast", {
                method: "getCurrentChannel",
                parameters: {
                    broadcastId: e.broadcastElement.mediaId,
                    subscribe: true
                },
                onSuccess: function (t) {
                    e.currentSource = t.channel.channelId;
                    var n = {};
                    n = S(t.channel, "api"), e.onchannelchange(n)
                },
                onFailure: function (e) { }
            })
        },
        getChannelState = function (e) {
            e.tokenSignalState = service.Request("luna://com.webos.service.tv.broadcast", {
                method: "getChannelState",
                parameters: {
                    broadcastId: e.broadcastElement.mediaId,
                    subscribe: true
                },
                onSuccess: function (cbObject) {
                    var returnObject = cbObject.channelState;
                    returnObject.screensaverType = returnObject.channelScreensaverType;
                    delete returnObject.channelScreensaverType;
                    e.onsignalstatuschange(returnObject);
                },
                onFailure: function (errorObject) { }
            })
        },
        getSignalState = function (e) {
            e.tokenSignalState = service.Request("luna://com.webos.service.tv.externaldevice/input/", {
                method: "getSignalState",
                parameters: {
                    externalInputId: e.broadcastElement.mediaId,
                    subscribe: true
                },
                onSuccess: function (cbObject) {
                    var n = cbObject.signalState;
                    e.onsignalstatuschange(n)
                },
                onFailure: function (errorObject) { }
            })
        },
        h = function (e) {
            if (e.tokenChannelChange)
                e.tokenChannelChange.cancel();
            if (e.tokenSignalState)
                e.tokenSignalState.cancel()
        },
        v = function (successCallback, failureCallback, options) {
            var startTime = getFormattedDate(options.startTime),
                endTime = getFormattedDate(options.endTime),
                o = {};
            if ("count" == options.request) {
                o = {
                    from: "com.webos.service.tv.programSCH:4",
                    select: [""],
                    where: [{
                        prop: "signalChannelId",
                        op: "=",
                        val: options.signalChannelId
                    }],
                    filter: [{
                        prop: "localStartTime",
                        op: "<=",
                        val: endTime
                    }, {
                            prop: "localEndTime",
                            op: ">=",
                            val: startTime
                        }]
                 }
            }
            else if ("nextInfo" == options.request) {
                o = {
                    from: "com.webos.service.tv.programSCH:4",
                    select: ["programId", "eventId", "localStartTime", "localEndTime", "duration", "programName", "description"],
                    where: [{
                        prop: "channelId",
                        op: "=",
                        val: options.signalChannelId
                    }],
                    filter: [{
                        prop: "localStartTime",
                        op: ">",
                        val: startTime
                    }],
                    orderBy: "localStartTime",
                    limit: 1
                }
            }
            else if ("list" == options.request || "nowInfo" == options.request) {
                o = {
                    from: "com.webos.service.tv.programSCH:4",
                    select: ["programId", "eventId", "localStartTime", "localEndTime", "duration", "programName", "description"],
                    where: [{
                        prop: "channelId",
                        op: "=",
                        val: options.signalChannelId
                    }],
                    filter: [
                        {
                            prop: "localStartTime",
                            op: "<=",
                            val: endTime
                        },
                        {
                            prop: "localEndTime",
                            op: ">=",
                            val: startTime
                        }
                    ]
                }
            }
        },
        getSignalChannelId = function (successCallback, errorCallback, options) {
            var DBQuery = {
                from: "com.webos.service.tv.channel.dblist:1",
                select: ["signalChannelId"],
                where: [{
                    prop: "channelId",
                    op: "=",
                    val: options.id
                }]
            };
            service.Request("luna://com.palm.db/", {
                method: "find",
                parameters: {
                    query: DBQuery
                },
                onSuccess: function (cbObject) {
                    options.signalChannelId = cbObject.results[0].signalChannelId;
                    v(successCallback, errorCallback, options);
                },
                onFailure: function (errorObject) {
                    delete errorObject.returnValue;
                    errorCallback && errorCallback(errorObject);
                }
            })
        },
        S = function (e, t) {
            var returnObject = {};
            returnObject.id = e.channelId;
            returnObject.number = e.channelNumber;
            returnObject.name = e.channelName;
            if ("api" == t) {
                returnObject.mode = e.channelModeName;
                returnObject.type = e.channelTypeName;
                returnObject.isSkipped = e.isSkipped;
                returnObject.isLocked = e.isLocked;
                returnObject.isDescrambled = e.isDescrambled;
                returnObject.isScrambled = e.isScrambled;
            }
            else {
                returnObject.mode = e.channelMode;
                returnObject.type = e.channelType;
                returnObject.isSkipped = e.skipped;
                returnObject.isLocked = e.locked;
                returnObject.isDescrambled = e.descrambled;
                returnObject.isScrambled = e.scrambled
            }
            return returnObject;
        },
        getFormattedDate = function (dateValue) {
            var formattedDate = dateValue.year + ",";
            formattedDate += (dateValue.month < 10 ? "0" : "") + dateValue.month + ",";
            formattedDate += (dateValue.day < 10 ? "0" : "") + dateValue.day + ",";
            formattedDate += (dateValue.hour < 10 ? "0" : "") + dateValue.hour + ",";
            formattedDate += (dateValue.minute < 10 ? "0" : "") + dateValue.minute + ",";
            formattedDate += (dateValue.second < 10 ? "0" : "") + dateValue.second;
            return formattedDate;
        };
    module.exports = broadcast
});
var Broadcast = cordova.require("cordova/plugin/broadcast");
/**
 * End of add cordova broadcast
 */

cordova.define('cordova/plugin/inputSource', function (require, exports, module) { // jshint ignore:line

    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }

    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");

                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    /**
     * inputSource interface
     */
    var InputSource = function () {
    };

    var isInitialized = false;
    var inputSourceVideoID = '';

    var broadcast = null;

    function checkErrorCodeNText(result, errorCode, errorText) {

        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    /**
     * Imports video tag to show the input source dynamically. This is used to embed input source in an html page.
     *
     * @class InputSource
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>divId</th><th>String</th><th>Div tag ID with the video tag in it. </th><th>required</th></tr>
     *       <tr class="odd"><th>videoId</th><th>String</th><th>The ID of the video tag to be dynamically created. </th><th>required</th></tr>
     *       <tr><th>callback</th><th>Function</th><th>An event handler (onloadedmetadata) that is called when the video tag is created. </th><th>required</th></tr>
     *       <tr class="odd"><th>src</th><th>String</th><th>The src attribute of the video tag. ext://[externalInput]:[portNum]. (eg: "ext://hdmi:1") </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * @return <p>None.</p>
     * @example
     * // HTML code
     *  < body onload="onLoad()" >
     *     < div id = "videoDiv" style="width:640px; height:380px" >
     *     < /div >
     *  < /body >
     *
     * // Javascript code
     * function init () {
     * }
     *
     * function onLoad() {
     *   var options = {
     *      divId : "videoDiv", // It should be matched to div tag name in an html page.
     *      videoId : "broadcastvideo",
     *      callback : init,
     *      src : "ext://hdmi:1"
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var inputSource = new InputSource();
     *   inputSource.initialize(successCb, failureCb, options);
     * }
     * @since 1.0
     * @since 1.1 options.isLastChannel removed
     */
    InputSource.prototype.initialize = function (successCallback, errorCallback, options) {

        log("initialize: " + JSON.stringify(options));

        // bound check
        if (options.divId === undefined || typeof options.divId !== 'string' || options.divId === null || options.divId.length <= 0 ||
            options.videoId === undefined || typeof options.videoId !== 'string' || options.videoId === null || options.videoId.length <= 0 ||
            options.callback === undefined || typeof options.callback !== 'function' ||
            options.src === undefined || typeof options.src !== 'string' || options.src === null || options.src.length <= 0 ) {

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "II", "InputSource.initialize returns failure. invalid parameters.");
                errorCallback(result);
            }

            return;
        }

        if (document.getElementById(options.divId) === null || document.getElementById(options.divId) === undefined) {
            if (typeof errorCallback === 'function') {
                errorCallback({
                    errorCode : "II",
                    errorText : "options.divId:[" + options.divId + "] element not exists or cannot approach"
                });
            }
            return;
        }
        else if (document.getElementById(options.videoId)) {
            if (typeof errorCallback === 'function') {
                errorCallback({
                    errorCode : "II",
                    errorText : "options.videoId:[" + options.videoId + "] element already exists."
                });
            }
            return;
        }
        /**
         * End of add exceptions
         */

        convertInputSource(options.src,
            function success(inputSource) {
                // success callback
                var tmpOpts        = {};
                tmpOpts.divId      = options.divId;
                tmpOpts.videoId    = options.videoId;
                tmpOpts.callback   = options.callback;
                tmpOpts.src        = inputSource;
                broadcast          = new Broadcast(); // jshint ignore:line
                broadcast.initialize(successCallback, errorCallback, tmpOpts);
                isInitialized      = true;
                inputSourceVideoID = options.videoId;
            },
            function failure(cbObj) {
                // failure callback
                log("initialize: failure " + JSON.stringify(cbObj));

                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "II", "InputSource.initialize returns failure. invalid parameters.");
                    errorCallback(result);
                }
            }
        );

        log("initialize: Done");
    };

    /**
     * Changes the input source that viewer is currently watching. This method is used to change to other input source after initializing the inputSource object (creating video tag. etc.) using InputSource.initialize() method.
     * Available input types and number of input sources for each input types may differ model by model. <br>
     * For example, LS55A model has the following inputs : (HDMI1, HDMI2, DP, DVI) or SM5B model has the following inputs : (HDMI1, DP, DVI, RGB, OPS)
     * @class InputSource
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>src</th><th>String</th><th>Define the src attribute of video tag. "ext://[externalinput]:[portNum]" (eg, "ext://dp:1")</a> </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function changeInputSource () {
     *   var options = {
     *      src : "ext://hdmi:1"
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var inputSource = new InputSource();
     *   inputSource.changeInputSource(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see <a href="InputSource%23getInputSourceStatus.html">InputSource.getInputSourceStatus()</a><br>
     */
    InputSource.prototype.changeInputSource = function (successCallback, errorCallback, options) {

        // bound check
        if ( options.src === undefined || typeof options.src !== 'string' || options.src === null || options.src.length <= 0) {

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "ICIS", "InputSource.changeInputSource returns failure. invalid argument.");
                errorCallback(result);
            }
            return;
        }

        if ((isInitialized === false) || (document.getElementById(inputSourceVideoID) === null || document.getElementById(inputSourceVideoID) === undefined)) {
            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "ICIS", "InputSource.changeInputSource returns failure. Call initialize() first.");
                errorCallback(result);
            }
            return;
        }

        //TODO; deprecated changeInput in broadcast.js

        log("changeInputSource: " + JSON.stringify(options));

        convertInputSource(options.src, function success (inputSource) {
            // success callback
            var tmpOpts      = {};
            tmpOpts.divId    = options.divId;
            tmpOpts.videoId  = options.videoId;
            tmpOpts.callback = options.callback;
            tmpOpts.src      = inputSource;

            if (broadcast.setInput(tmpOpts)) {
                log("changeInputSource: On Success");
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            } else {
                if (typeof errorCallback === 'function') {
                    var result = {};
                    log("changeInputSource: On Failure");
                    checkErrorCodeNText(result, "ICIS", "InputSource.changeInputSource returns failure.");
                    errorCallback(result);
                }
            }

        }, function failure(cbObj) {
            // failure callback
            log("changeInputSource: failure " + JSON.stringify(cbObj));

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "ICIS", "InputSource.changeInputSource returns failure. invalid argument. ");
                errorCallback(result);
            }
        });

        log("changeInputSource: Done");
    };

    /**
     * Gets current input source status.
     * @class InputSource
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object} array of inputSource object, signal state and current input source.
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>inputSourceList[]</th><th>Array</th><th>An array with input source object.</th></tr>
     *       <tr class="odd"><th>inputSourceList[].inputPort</th><th>String</th><th>Input label (ext://hdmi:1, ext://hdmi:2, ext://dp:1, ext://dvi:1 etc) </th></tr>
     *       <tr><th>currentSignalState</th><th>String</th><th>Status and change information of the input that is currently selected.<br>"good" : good signal, "bad" : poor signal, "unknown" : can't indicate a signal status </th></tr>
     *       <tr class="odd"><th>currentInputSource</th><th>String</th><th>Input source that the viewer is currently watching.<br>input label </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getInputSourceStatus () {
     *   function successCb(cbObject) {
     *      var inputSourceList = cbObject.inputSourceList;
     *      for ( var i = 0; i < inputSourceList.length; i++) {
     *         console.log("inputSourceList[" + i + "] : " + JSON.stringify(inputSourceList[i]));
     *         console.log("inputSourceList[" + i + "].inputPort : " + inputSourceList[i].inputPort);
     *      }
     *      console.log("currentInputSource : " + cbObject.currentInputSource);
     *      console.log("currentSignalState : " + cbObject.currentSignalState);
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var inputSource = new InputSource();
     *   inputSource.getInputSourceStatus(successCb, failureCb);
     * }
     * @since 1.0
     * @see <a href="InputSource%23changeInputSource.html">InputSource.changeInputSource()</a><br>
     */
    InputSource.prototype.getInputSourceStatus = function (successCallback, errorCallback) {

        log("getInputSourceStatus: ");

        service.Request("luna://com.webos.service.eim/", {
            method : "getAllInputStatus",
            onSuccess : function(result) {
                log("getInputSourceStatus: On Success");

                if (result.returnValue === true) {
                    checkPlatformVersion(function(platformInfo){

                        var ver = platformInfo.webOSVer;

                        log("convertInputSource: " + JSON.stringify(result.totalCount));
                        log("convertInputSource: " + JSON.stringify(result.devices));
                        log("version: " + ver);

                        var cbObj = {};
                        var inputList = new Array(result.totalCount);
                        var convertList = new Array(result.totalCount);

                        for (var i=0; i<inputList.length; i++) {
                            inputList[i] = {};
                            inputList[i].inputPort = parseInputSource(result.devices[i].label);

                            var tempInputSource = null;
                            switch (ver) {
                                case 1 :
                                    // fixed input for hdmi:3, hdmi:4. requested by youngjun.lee
                                    tempInputSource = result.devices[i].id.split("_");
                                    inputList[i].inputPort = 'ext://' + tempInputSource[0].toLowerCase() + ':' + tempInputSource[1];
                                    if (inputList[i].inputPort === 'ext://hdmi:3') {
                                        inputList[i].inputPort = 'ext://dp:1';
                                    } else if (inputList[i].inputPort === 'ext://hdmi:4') {
                                        inputList[i].inputPort = 'ext://dvi:1';
                                    }
                                    // end
                                    break;
                                case 2 :
                                    tempInputSource = result.devices[i].id.split("_");
                                    inputList[i].inputPort = 'ext://' + tempInputSource[0].toLowerCase() + ':' + tempInputSource[1];
                                    if (platformInfo.chipset === 'H15') {
                                        if (inputList[i].inputPort === 'ext://dvi:4') {
                                            inputList[i].inputPort = 'ext://hdmi:3';
                                        }
                                        if (inputList[i].inputPort === 'ext://ops:1') {
                                            inputList[i].inputPort = 'ext://hdmi:3';
                                        }
                                        if (inputList[i].inputPort === 'ext://hdmi:4') {
                                            inputList[i].inputPort = 'ext://dp:1';
                                        }
                                    }
                                    else {
                                        if (inputList[i].inputPort === 'ext://hdmi:3') {
                                            inputList[i].inputPort = 'ext://dp:1';
                                        } else if (inputList[i].inputPort === 'ext://hdmi:2') {
                                            inputList[i].inputPort = 'ext://dvi:1';
                                        } else if (inputList[i].inputPort === 'ext://hdmi:4') {
                                            inputList[i].inputPort = 'ext://ops:1';
                                        }
                                    }

                                    break;
                                case 3 :
                                default :
                                    var deviceName = result.devices[i].deviceName.toLowerCase();
                                    var port = 1;
                                    if (isNaN(deviceName.substring(deviceName.length - 1, deviceName.length)) === false) //number
                                    {
                                        deviceName = deviceName.substring(0, deviceName.length - 1);
                                        port = result.devices[i].id.split("_")[1];
                                    }

                                    if(deviceName.toLowerCase() === "displayport")
                                        deviceName = "dp";
                                    else if(deviceName.toLowerCase() === "ops/dvi")
                                        deviceName = "ops";

                                    inputList[i].inputPort = 'ext://' + deviceName.toLowerCase() + ':' + port;

                                    break;
                            }

                            convertList[i] = {};
                            convertList[i].inputPort = inputList[i].inputPort;
                            convertList[i].id = result.devices[i].id;
                        }

                        cbObj.inputSourceList = inputList;

                        service.Request("luna://com.webos.service.eim/", {
                            method : "getCurrentInput",
                            parameters : {},
                            onSuccess : function(result) {
                                log("InputSource.getInputSourceStatus: On Success 3");

                                if (result.returnValue === true) {

                                    if (typeof successCallback === 'function') {

                                        cbObj.currentInputSource = {};

                                        for (var i=0; i<convertList.length; i++) {
                                            if (convertList[i].id === result.mainInputSourceId) {
                                                cbObj.currentInputSource = convertList[i].inputPort;
                                                break;
                                            }
                                        }

                                        cbObj.currentSignalState = "unknown";

                                        if (broadcast !== null) {
                                            log("InputSource.getInputSourceStatus : broadcast is not null");

                                            broadcast.getSignalStatus(function successCb(cbObject) {

                                                cbObj.currentSignalState = cbObject.videoSignalState;
                                                log("InputSource.getInputSourceStatus: On Success 2");

                                                if (typeof successCallback === 'function') {
                                                    log("getInputSourceStatus: On Success" + JSON.stringify(cbObj));
                                                    successCallback(cbObj);
                                                    return;
                                                }

                                            }, function failureCb() {

                                                log("InputSource.getInputSourceStatus : signal state is fail.");
                                                if (typeof successCallback === 'function') {
                                                    log("getInputSourceStatus: On Success" + JSON.stringify(cbObj));
                                                    successCallback(cbObj);
                                                    return;
                                                }
                                            });

                                        } else {

                                            log("InputSource.getInputSourceStatus : it does not initialize.");
                                            if (typeof successCallback === 'function') {
                                                log("getInputSourceStatus: On Success" + JSON.stringify(cbObj));
                                                successCallback(cbObj);
                                                return;
                                            }
                                        }
                                    }
                                }
                            },
                            onFailure : function(result) {
                                log("InputSource.getInputSourceStatus: On Failure 2");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "IGISS", "InputSource.getInputSourceStatus returns failure.");
                                    errorCallback(result);
                                    return;
                                }
                            }
                        });
                    }); // check version
                } // if (result.returnValue === true) {
            },
            onFailure : function(result) {
                log("getInputSourceStatus: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "IGISS", "InputSource.changeInputSource returns failure on gathering input list.");
                    errorCallback(result);
                }
            }
        });

    log("InputSource.getInputSourceStatus Done");

    };

    function parseInputSource(str) {

        var index = 1;
        var length = str.length;

        if (!isNaN(parseInt(str.charAt(length-1), 10))) {
            // has number
            index = str.charAt(length-1);
            length--;
        }

        str = str.substring(0, length) +":"+ index;
        str = "ext://" + str.toLowerCase();

        return str;
    }

    var version = null;
    var platformInfoObj = {};
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }

    function convertInputSource(inputSource, successCallback, errorCallback) {

        var convertedDeviceName = inputSource.toUpperCase().substring(6).split(":")[0];

        if(convertedDeviceName === "DP")
            convertedDeviceName = "DISPLAYPORT";

        service.Request("luna://com.webos.service.eim/", {
            method : "getAllInputStatus",
            onSuccess : function(result) {
                log("convertInputSource: On Success " + inputSource);

                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
						var inputList = new Array(result.totalCount);
                        checkPlatformVersion(function(platformInfo){
                            var ver = platformInfo.webOSVer;
                            log("convertInputSource: " + JSON.stringify(result.devices));
                            log("version: " + ver);

                            if(ver >= 3) //webos3.0
                            {
                                for (var i = 0; i < result.devices.length; i++) {
                                    var inputSourceParam = inputSource.substring(6).split(":"); //hdmi:1
                                    var deviceName = result.devices[i].deviceName;
                                    var port = '1';

                                    //1. removed number
                                    if (isNaN(deviceName.substring(deviceName.length - 1, deviceName.length)) === false) //if devicename's last char is number
                                    {
                                        port = deviceName.substring(deviceName.length - 1, deviceName.length);
                                        deviceName = deviceName.substring(0, deviceName.length - 1); //removed port
                                    }

                                    //2. converted "display"  to "dp"
                                    if (deviceName.toLowerCase() === 'displayport')
                                        deviceName = 'dp';

                                    //3. check devicename and port are same
                                    if (deviceName.toLowerCase().indexOf(inputSourceParam[0].toLowerCase()) >= 0 && port === inputSourceParam[1]) {
                                        var tempInputSource = result.devices[i].id.split("_");
                                        convertedInput      = "ext://" + tempInputSource[0].toLowerCase() + ":" + tempInputSource[1];

                                        successCallback(convertedInput);
                                        return;
                                    }
                                }

                                log("convertInputSource: On Failure " + inputSource);
                                var errResult = {};
                                checkErrorCodeNText(errResult, "IGISS", "convertInputSource. It does not support inputsource type.");
                                errorCallback(errResult);
                            }
                            else //webos2.0, 1.0
                            {

                                switch (ver) {
                                    case 1:
                                        // fixed input for hdmi:3, hdmi:4. requested by youngjun.lee
                                        if (inputSource === 'ext://dp:1') {
                                            inputSource = 'ext://hdmi:3';
                                        } else if (inputSource === 'ext://dvi:1') {
                                            inputSource = 'ext://hdmi:4';
                                        }
                                        // end
                                        break;
                                    case 2:
                                        if (platformInfoObj.chipset === 'H15') {
                                            if (inputSource === 'ext://dvi:1') {
                                                inputSource = 'ext://hdmi:3';
                                            } else if (inputSource === 'ext://ops:1') {
                                                inputSource = 'ext://hdmi:3';
                                            }
                                            else if (inputSource === 'ext://dp:1') {
                                                inputSource = 'ext://hdmi:3';
                                            } else if (inputSource === 'ext://hdmi:4') {
                                                inputSource = 'ext://dp:1';
                                            }
                                        } else {
                                            if (inputSource === 'ext://dp:1') {
                                                inputSource = 'ext://hdmi:3';
                                            } else if (inputSource === 'ext://dvi:1') {
                                                inputSource = 'ext://hdmi:2';
                                            } else if (inputSource === 'ext://ops:1') {
                                                inputSource = 'ext://hdmi:4';
                                            }
                                        }
                                        break;
                                    case 3:
                                        if (inputSource === 'ext://dp:1') {
                                            inputSource = 'ext://hdmi:3';
                                        } else if (inputSource === 'ext://dvi:1') {
                                            inputSource = 'ext://hdmi:2';
                                        } else if (inputSource === 'ext://ops:1') {
                                            inputSource = 'ext://hdmi:4';
                                        }

                                        break;
                                    default:
                                        break;
                                }

                                for (var i=0; i<inputList.length; i++) {
                                    inputList[i] = {};

                                    if (platformInfoObj.chipset === 'H15')
                                        inputList[i].inputPort = parseInputSource(result.devices[i].deviceName);
                                    else
                                        inputList[i].inputPort = parseInputSource(result.devices[i].label);
                                    var tempInputSource = result.devices[i].id.split("_");
                                    inputList[i].id = 'ext://' + tempInputSource[0].toLowerCase() + ':' + tempInputSource[1];

                                    if (inputSource === inputList[i].id) {
                                        // ok
                                        log("convertInputSource: On Success ok " + inputSource);
                                        successCallback(inputSource);
                                        return;
                                    }
                                }

                                for (var j=0; j<inputList.length; j++) {
                                    if (inputSource === inputList[j].inputPort) {
                                        // convert source
                                        inputSource = inputList[j].id;
                                        log("convertInputSource: On Success converted " + inputSource);
                                        successCallback(inputSource);
                                        return;
                                    }
                                }

                                log("convertInputSource: On Failure " + inputSource);
                                var errResult = {};
                                checkErrorCodeNText(errResult, "IGISS", "convertInputSource. It does not support inputsource type.");
                                errorCallback(errResult);
                            }
                        });
                    }
                }
            },
            onFailure : function(result) {
                log("convertInputSource: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "IGISS", "convertInputSource returns failure on gathering input list.");
                    errorCallback(result);
                }
            }
        });


    }

    module.exports = InputSource;
});

InputSource = cordova.require('cordova/plugin/inputSource'); // jshint ignore:line