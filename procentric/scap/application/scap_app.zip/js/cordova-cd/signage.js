/*
 * This is signage cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the signage API itself, and provides a global namespace for operating signage service.
 * @class
 */
cordova.define('cordova/plugin/signage', function (require, exports, module) { // jshint ignore:line
    var service;
    function log(msg) {
        //	console.log(msg);//will be removed // jshint ignore:line
    }


    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    }
    else {
        log("Window.PalmSystem is NOT Available");
        service = {
            Request: function (uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");
                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue: false, errorCode: "CORDOVA_ERR",
                        errorText: "PalmSystem Not Available. Cordova is not installed?"
                    });
                }
            }
        };
    }

    var version = null;
    var platformInfoObj = {};
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }


    var removeSignageEventListener = function (event) {
        var monitorObj = _gSystemMonitoringSetup[event];
        log(JSON.stringify(monitorObj, null, 3));
        if (monitorObj && monitorObj.getEvent === true) {
            if (_gSystemMonitoringSetup[event].listenerObj) {
                _gSystemMonitoringSetup[event].listenerObj.cancel();
                _gSystemMonitoringSetup[event].getEvent = false;
                _gSystemMonitoringSetup[event].listenerObj = null;
            }
        }
    };
    var addSignageEventListener = function (key, callbackfunction) {
		/*	fan : {
			getEvent:false,
			listenerObj : null,
			createListenr : monitorFan
		},
		 */
        var monitorSetup = _gSystemMonitoringSetup[key];
        if (monitorSetup && typeof monitorSetup.createListener === 'function') {
            monitorSetup.listenerObj = monitorSetup.createListener(callbackfunction);
            monitorSetup.getEvent = true;
        }
    };

    function getInputValue(inputUri) {
        if (inputUri.substring(0, "ext://".length) !== "ext://") {
            log("Bad prefix: " + inputUri);
            return false;
        }

        var body = inputUri.substring("ext://".length);
        log("body is: " + body);

        var splited = body.split(":");

        if (splited.length === 2) {
            return splited[0] + splited[1];
        }

        else if (splited.length === 1) {
            return splited[0];
        }

        else {
            log("Bad Syntax: " + inputUri);
            return false;
        }
    }

    function isValidEnum(arr, value) {
        for (var key in arr) {
            if (arr[key] === value) {
                return true;
            }
        }

        return false;
    }


    var SETTINGS_KEY = {
        FAILOVER_MODE: "failover",
        FAILOVER_PRIORITY: "failoverPriority",
        IR_OPERATION_MODE: "enableIrRemote",
        LOCALKEY_OPERATION_MODE: "enableLocalKey",
        OSD_PORTRAIT_MODE: "osdPortraitMode",
        TILE_MODE: "tileMode",
        TILE_ID: "tileId",
        TILE_ROW: "tileRow",
        TILE_COLUME: "tileCol",
        TILE_NATURALMODE: "naturalMode",
        DPM_MODE: "dpmMode",
        AUTOMATIC_STANDBY_MODE: "autoSB",
        ISM_METHOD: "ismmethod",
        SES_MODE: "smartEnergy",
        DO_15OFF_MODE: "15off",
        MONITOR_FAN: "monitorFan",
        MONITOR_SIGNAL: "monitorSignal",
        MONITOR_LAMP: "monitorLamp",
        MONITOR_SCREEN: "monitorScreen",
        MONITOR_AUDIO: "monitorAudio",
        AUDIO_SOURCE_HDMI1: "audioSourceHdmi1",
        AUDIO_SOURCE_HDMI2: "audioSourceHdmi2",
        AUDIO_SOURCE_DP: "audioSourceDp"
    };

    var monitorTemperature = function (callbackfunction) {
        log("Create Listener for monitorTemperature");
        var subscribed = service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/getTemperature",
            parameters: {
                subscribe: true
            },
            onSuccess: function (result) {
                log("temperature : " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var returnData = {
                        source: Signage.MonitoringSource.THERMOMETER,
                        type: Signage.EventType.CURRENT_TEMPERATURE,
                        data: {
                            temperature: result.temperature
                        }
                    };
                    if (typeof callbackfunction === 'function') {
                        callbackfunction(returnData);
                    }
                }
            },
            onFailure: function (result) {
                log("monitor_temperature : FAIL " + JSON.stringify(result, null, 3));

            }
        });
        return subscribed;
    };

    var monitorFan = function (callbackfunction) {
        log("Create Listener for monitorFan");

        var subscribed = service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/getFanEvent",
            parameters: {
                subscribe: true
            },
            onSuccess: function (result) {
                log("monitor_fan : " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var returnData = {
                        source: Signage.MonitoringSource.FAN,
                        type: Signage.EventType.FAN_STATUS,
                        data: {
                            status: result.fanFault
                        }
                    };
                    if (typeof callbackfunction === 'function') {
                        callbackfunction(returnData);
                    }
                }
            },
            onFailure: function (result) {
                log("monitor_fan : FAIL " + JSON.stringify(result, null, 3));

            }
        });
        return subscribed;
    };

    var monitorLamp = function (callbackfunction) {
        log("Create Listener for monitorLamp");

        var subscribed = service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/getLampEvent",
            parameters: {
                subscribe: true
            },
            onSuccess: function (result) {
                log("monitor_lamp : " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var returnData = {
                        source: Signage.MonitoringSource.LAMP,
                        type: Signage.EventType.LAMP_STATUS,
                        data: {
                            status: result.lampFault
                        }
                    };
                    if (typeof callbackfunction === 'function') {
                        callbackfunction(returnData);
                    }
                }
            },
            onFailure: function (result) {
                log("monitor_lamp : FAIL " + JSON.stringify(result, null, 3));

            }
        });
        return subscribed;
    };

    var monitorSignal = function (callbackfunction) {
        log("Create Listener for monitorSignal");

        var subscribed = service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/getSignalEvent",
            parameters: {
                subscribe: true
            },
            onSuccess: function (result) {
                log("monitor_signal : " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var returnData = {
                        type: Signage.EventType.SIGNAL_STATUS,
                        source: Signage.MonitoringSource.SIGNAL,

                        data: {}
                    };
                    if (result.noSignal === true) {
                        returnData.data.status = "no_signal";
                    }
                    else {
                        returnData.data.status = "signal_available";
                    }

                    if (typeof callbackfunction === 'function') {
                        callbackfunction(returnData);
                    }
                }
            },
            onFailure: function (result) {
                log("monitor_signal : FAIL " + JSON.stringify(result, null, 3));
            }
        });

        return subscribed;
    };

    var monitorScreen = function (callbackfunction) {
        log("Create Listener for monitorScreen");

        var subscribed = service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/getScreenEvent",
            parameters: {
                subscribe: true
            },
            onSuccess: function (result) {
                log("monitor_screen : " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var returnData = {
                        source: Signage.MonitoringSource.SCREEN,
                        type: Signage.EventType.SCREEN_STATUS,
                        data: {
                            status: result.screen
                        }
                    };

                    if (typeof callbackfunction === 'function') {
                        callbackfunction(returnData);
                    }
                }
            },
            onFailure: function (result) {
                log("monitor_screen FAIL : " + JSON.stringify(result, null, 3));
            }
        });

        return subscribed;
    };



    var _gSystemMonitoringSetup = {
        fan: {
            getEvent: false,
            listenerObj: null,
            createListener: monitorFan
        },
        screen: {
            getEvent: false,
            listenerObj: null,
            createListener: monitorScreen
        },
        temperature: {
            getEvent: false,
            listenerObj: null,
            createListener: monitorTemperature
        },
        signal: {
            getEvent: false,
            listenerObj: null,
            createListener: monitorSignal
        },
        lamp: {
            getEvent: false,
            listenerObj: null,
            createListener: monitorLamp
        }
    };

    var _gTileInfo = {
        row: 0,
        col: 0
    };

	/**
	 * signage interface
	 */
    var Signage = function () {
    };

	/**
	 * This value is returned when requested data is not defined.
	 */
    Signage.UNDEFINED = '___undefined___';


	/**
	 * @namespace Signage.FailoverMode
	 */
    Signage.OsdPortraitMode = {
        /**
         * Rotate 90 or 270 degree. It depends on the model specific.
         * @since 1.0
         * @constant
         */
        ON: "90",
        /**
         * Do not use portrait mode.
         * @since 1.0
         * @constant
         */
        OFF: "off"
    };

    /**
     * @namespace Signage.ImgResolution
     */
    Signage.ImgResolution = {
        /**
         * HD Resolution
         * @since 1.4.1
         * @constant
         */
        HD: "HD",
        /**
         * FHD Resolution
         * @since 1.4.1
         * @constant
         */
        FHD: "FHD",
    };

	/**
	 * @namespace Signage.AutomaticStandbyMode
	 */
    Signage.AutomaticStandbyMode = {
        /**
         * Do not use automatic standby mode.
         * @since 1.0
         * @constant
         */
        OFF: "off",
        /**
         * automatic standby in 4 hours.
         * @since 1.0
         * @constant
         */
        STANDBY_4HOURS: "4hours"
    };

	/**
	 * @namespace Signage.ISMMethod
	 */
    Signage.IsmMethod = {
        /**
         * ISM Method Normal
         * @since 1.0
         * @constant
         */
        NORMAL: "NORMAL",
        /**
         * ISM Method Orbiter
         * @since 1.0
         * @constant
         */
        ORBITER: "ORBITER",
        /**
         * ISM Method Inversion
         * @since 1.0
         * @constant
         */
        INVERSION: "INVERSION",
        /**
         * ISM Method Color Wash
         * @since 1.0
         * @constant
         */
        COLORWASH: "COLORWASH",
        /**
         * ISM Method White Wash
         * @since 1.0
         * @constant
         */
        WHITEWASH: "WHITEWASH",
        /**
         * Washing Bar
         * @since 1.2
         * @constant
         */
        WASHING_BAR: "WASHINGBAR",
        /**
         * User Image
         * @since 1.2
         * @constant
         */
        USER_IMAGE: "USERIMAGE",
        /**
         * User Image
         * @since 1.2
         * @constant
         */
        USER_VIDEO: "USERVIDEO"
    };

	/**
	 * @namespace Signage.FailoverMode
	 */
    Signage.FailoverMode = {
        /**
         * Do not use failover mode.
         * @since 1.0
         * @constant
         */
        OFF: "off",
        /**
         * Use machine default setting. It differs model by model. <br>
         * For LS55A, it is (HDMI1 > HDMI2 > DP > DVI > Internal Memory)
         * @since 1.0
         * @constant
         */
        AUTO: "auto",
        /**
         * Use priority set by the user.
         * @since 1.0
         * @constant
         */
        MANUAL: "manual"
    };

	/**
	 * @namespace Signage.DigitalAudioInput
	 */
    Signage.DigitalAudioInput = {
        /**
         * HDMI or display port
         * @since 1.0
         * @constant
         */
        HDMI_DP: "hdmi",
        /**
         * AUDIO_IN
         * @since 1.0
         * @constant
         */
        AUDIO_IN: "audioIn"
    };

	/**
	 * @namespace Signage.DpmMode
	 */
    Signage.DpmMode = {
        /**
         * Do not use DPM
         * @since 1.0
         * @constant
         */
        OFF: "off",
        /**
         * POWER_OFF_5SECONDS
         * @since 1.0
         * @constant
         */
        POWER_OFF_5SECOND: "5sec",
        /**
         * POWER_OFF_10SECONDS
         * @since 1.0
         * @constant
         */
        POWER_OFF_10SECOND: "10sec",
        /**
         * POWER_OFF_15SECONDS
         * @since 1.0
         * @constant
         */
        POWER_OFF_15SECOND: "15sec",
        /**
         * POWER_OFF_1MINUTE
         * @since 1.0
         * @constant
         */
        POWER_OFF_1MINUTE: "1min",
        /**
         * POWER_OFF_3MINUTE
         * @since 1.0
         * @constant
         */
        POWER_OFF_3MINUTE: "3min",
        /**
         * POWER_OFF_5MINUTE
         * @since 1.0
         * @constant
         */
        POWER_OFF_5MINUTE: "5min",

        /**
         * POWER_OFF_10MINUTE
         * @since 1.0
         * @constant
         */
        POWER_OFF_10MINUTE: "10min"
    };

	/**
	 * @namespace Signage.KeyOperationMode
	 */
    Signage.KeyOperationMode = {
        /**
         * ALLOW_ALL
         * @since 1.0
         * @constant
         */
        ALLOW_ALL: "normal",
        /**
         * POWER_ONLY
         * @since 1.0
         * @constant
         */
        POWER_ONLY: "usePwrOnly",
        /**
         * BLOCK_ALL
         * @since 1.0
         * @constant
         */
        BLOCK_ALL: "blockAll"
    };

	/**
	 * @namespace Signage.EventType
	 */
    Signage.EventType = {
        /**
         * Temperature Event.
         * Corresponding data includes:
         * <div align=left>
         * <table class="hcap_spec" width=400>
         *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
         *   <tbody>
         *       <tr><th>temperature</th><th>Number</th><th>Current Temperature</th><th>required</th></tr>
         *   </tbody>
         * </table>
         * </div>
         * @since 1.0
         * @constant
         */
        CURRENT_TEMPERATURE: "CURRENT_TEMPERATURE",

        /**
         * Current fan status.
         * Corresponding data includes:
         * <div align=left>
         * <table class="hcap_spec" width=400>
         *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
         *   <tbody>
         *       <tr><th>status</th><th>String</th><th>Fan status. ('ok'|'fault'|'na')</th><th>required</th></tr>
         *   </tbody>
         * </table>
         * </div>
         * @since 1.0
         * @constant
         */
        FAN_STATUS: "FAN_STATUS",

        /**
         * Current lamp status.
         * Corresponding data includes:
         * <div align=left>
         * <table class="hcap_spec" width=400>
         *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
         *   <tbody>
         *       <tr><th>status</th><th>String</th><th>Lamp status. ('ok'|'fault'|'na')</th><th>required</th></tr>
         *   </tbody>
         * </table>
         * </div>
         * @since 1.0
         * @constant
         */
        LAMP_STATUS: "LAMP_STATUS",

        /**
         * Current screen status.
         * Corresponding data includes:
         * <div align=left>
         * <table class="hcap_spec" width=400>
         *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
         *   <tbody>
         *       <tr><th>status</th><th>String</th><th>screen status. ('ok'|'ng')</th><th>required</th></tr>
         *   </tbody>
         * </table>
         * </div>
         * @since 1.0
         * @constant
         */
        SCREEN_STATUS: "SCREEN_STATUS",

        /**
         * Current signal status.
         * Corresponding data includes:
         * <div align=left>
         * <table class="hcap_spec" width=400>
         *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
         *   <tbody>
         *       <tr><th>status</th><th>String</th><th>signal status. ('no_signal'|'signal_available')</th><th>required</th></tr>
         *   </tbody>
         * </table>
         * </div>
         *
         * @since 1.0
         * @constant
         */
        SIGNAL_STATUS: "SIGNAL_STATUS"

    };

	/**
	 * @namespace Signage.MonitoringSource
	 */
    Signage.MonitoringSource = {
        /**
         * FAN
         * @since 1.0
         * @constant
         */
        FAN: "FAN",
        /**
         * LAMP
         * @since 1.0
         * @constant
         */
        LAMP: "LAMP",
        /**
         * SIGNAL
         * @since 1.0
         * @constant
         */
        SIGNAL: "SIGNAL",
        /**
         * SCREEN
         * @since 1.0
         * @constant
         */
        SCREEN: "SCREEN",
        /**
         * THERMOMETER
         * @since 1.0
         * @constant
         */
        THERMOMETER: "THERMOMETER"

    };

    function checkErrorCodeNText(result, errorCode, errorText) {

        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText === undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    function getSystemSettings(category, keys, cbObjectGetter, successCallback, errorCallback) {
        var params = {
            category: category,
            keys: keys
        };

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: params,
            onSuccess: function (result) {
                log("On Success");
                if (result.returnValue === true) {
                    var cbObj = cbObjectGetter(result.settings);
                    if (cbObj === false) {
                        if (typeof errorCallback === 'function') {
                            errorCallback({
                                errorText: "Invalid DB value",
                                errorCode: "DB_ERROR"
                            });
                        }
                    }
                    else {
                        if (typeof successCallback === 'function') {
                            log("successCallback");
                            successCallback(cbObj);
                        }
                        else {
                            log("successCallback not registered or is not a function: " + successCallback);
                        }
                    }
                }
                else {
                    log("Settings Failed:  " + JSON.stringify(result, null, 3));

                    if (typeof errorCallback === 'function') {
                        errorCallback({
                            errorText: "Invalid DB value : " + result.errorText,
                            errorCode: "DB_ERROR"
                        });
                    }

                }
            },
            onFailure: function (result) {
                log("On Failure");
                delete result.returnValue;
                // See if any salvagable data
                if (result.settings) {
                    log("settings = " + JSON.stringify(result.settings, null, 3));

                    var cbObject = cbObjectGetter(result.settings);

                    log("errorKey = " + JSON.stringify(result.errorKey, null, 3));

                    for (var i = 0; i < result.errorKey.length; ++i) {
                        cbObject[result.errorKey[i]] = Signage.UNDEFINED;
                    }

                    log("cbObj = " + JSON.stringify(cbObject, null, 3));
                    if (typeof successCallback === 'function') {
                        log("successCallback");
                        successCallback(cbObject);
                    }
                }
                else {
                    if (typeof errorCallback === 'function') {
                        errorCallback({
                            errorText: ((typeof result.errorText === 'undefined') ? "DB Failure" : result.errorText),
                            errorCode: "DB_ERROR"
                        });
                    }
                }
            }
        });

        log("Requested Service: " + "luna://com.webos.service.commercial.signage.storageservice/settings/");
        log("params : " + JSON.stringify(params));
    }

    function setSystemSettings(category, settings, successCallback, errorCallback) {
        var params = {
            category: category,
            settings: settings
        };

        log("settings : " + JSON.stringify(settings, null, 3));
        var hasKey = false;
        for (var key in settings) {
            if (key) {
                log("has key : " + key);
                hasKey = true;
                break;
            }
        }
        if (hasKey === false) {
            log("Nothing to set");
            successCallback();
            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "set",
            parameters: params,
            onSuccess: function () {
                log("On Success");
                if (typeof successCallback === 'function') {
                    log("SUCCEES CALLBACK");
                    successCallback();
                }
            },
            onFailure: function (result) {
                log("On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    log("ERROR CALLBACK");
                    errorCallback(result);
                }
            }
        });

        log("Requested Service: " + "luna://com.webos.service.commercial.signage.storageservice/settings/");
        log("params : " + JSON.stringify(params));
    }




	/**
	 * <p>
	 * Sets Portrait Mode.
	 * </p>
	 *
	 * @example
	 *
	 * function setPortraitMode() {
	 *
	 *    var options = {
	 *      portraitMode: Signage.OsdPortraitMode.ON
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log("Portrait Mode successfully Set");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setPortraitMode(successCb, failureCb, options);
	 * }
	 *
	 * @class Signage
	 * @param {Function}
	 *            successCallback success callback function.
	 * @param {Function}
	 *            errorCallback failure callback function.
	 * @param {Object}
	 *            options Input Parameters
	 * @param {Signage.OsdPortraitMode}
	 *            options.portraitMode Portrait mode.
	 * @returns
	 *            <p>
	 *            After the method is successfully executed, successCallback is called without any parameter.</br>
	 *            If an error occurs, errorCallback is called with errorCode and errorText.
	 *            </p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setPortraitMode = function (successCallback, errorCallback, options) {
        var settings = {};

        var errorMessage;
        function checkOptions(options) {
            if (options.portraitMode) {
                for (var key in Signage.OsdPortraitMode) {
                    if (options.portraitMode === Signage.OsdPortraitMode[key]) {
                        return true;
                    }
                }

                errorMessage = "Signage.setPortraitMode: Unrecognized OsdPortraintMode : " + options.portraitMode;
                return false;
            }
            else {
                errorMessage = "Signage.setPortraitMode: portraitMode does not exist.";
                return false;
            }
        }
        if (checkOptions(options)) {
            var portraintModeStr = options.portraitMode;
            settings[SETTINGS_KEY.OSD_PORTRAIT_MODE] = portraintModeStr;


            service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                method: "setOsdPortraitMode",
                parameters: {
                    osdPortraitMode: options.portraitMode
                },
                onSuccess: function (result) {
                    successCallback();
                },
                onFailure: function (error) {
                    // If setOsdPortraitMode is not exists in storageservice (old firmware), call previous function
                    if (error.errorText.indexOf('Unknown method') !== -1) {
                        setSystemSettings("commercial", settings, successCallback, errorCallback);
                    }
                    // Else other error is occured. Call errorCallback.
                    else {
                        errorCallback({
                            errorCode: error.errorCode,
                            errorText: error.errorText
                        });
                    }
                }
            });

            //setSystemSettings("commercial", settings, successCallback, errorCallback);

            log("setPortraitMode Done");
        }
        else {
            errorCallback({
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            });
        }
    };


	/**
	 * <p>Sets Failover mode.
	 *  When Failover Mode is set, monitor will automatically switch to the input source when the input signal fails, according to the predefined priorities set in the menu. </p>
	 *
	 * <p>IMPORTANT NOTE!!!!</p>
	 *
	 * <p>
	 * When failover is triggered due to lost signal, the signage application will
	 * yield to the next priority input source set in the failover mode and run in the background.
	 * </p>
	 * <p>
	 * If the signage application should always be running in the foreground, failover mode should be set to OFF.
	 * </p>
	 *
	 * @example
	 *
	 * function setFailoverMode() {
	 *
	 *    //Available input types and number of input ports for each input types may differ model by model.
	 *    var options = {
	 *      failoverMode : {
	 *         mode: Signage.FailoverMode.MANUAL,
	 *         priority : [
	 *            'ext://hdmi:1',
	 *            'ext://hdmi:2',
	 *            'ext://dvi:1',
	 *            'ext://internal_memory',
	 *            'ext://dp:1'
	 *         ]
	 *      }
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log('Successfully set Failover Mode');
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setFailoverMode(successCallback, errorCallback, options);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options Input Parameters
	 * @param {Object} options.failoverMode Failover mode. Only attributes that exist will be set.
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>mode</th><th><a href="Signage.FailoverMode.html#constructor">Signage.FailoverMode</a></th><th>Failover mode</th><th>required</th></tr>
	 *       <tr class="odd"><th>priority</th><th>Array</th><th>Input priority that will be used when mode is MANUAL.<br>
	 *       This parameter should be present only when mode is set to MANUAL(error is returned otherwise).</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * Input source can be one of the following. Some of the input type may not be supported for a specific model.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>ext://hdmi:[index]</th><th>HDMI Input</th></tr>
	 *       <tr class="odd"><th>ext://dvi:[index]</th><th>DVI Input</th></tr>
	 *       <tr><th>ext://rgb:[index]</th><th>RGB input</th></tr>
	 *       <tr class="odd"><th>ext://dp:[index]</th><th>Display port Input</th></tr>
	 *       <tr><th>ext://ops:[index]</th><th>OPS input</th></tr>
	 *       <tr class="odd"><th>ext://internal_memory</th><th>Internal Storage</th></tr>
	 *       <tr><th>ext://usb:[index]</th><th>External USB storage at usb port [index]</th></tr>
	 *       <tr class="odd"><th>ext://sdCard:[index]</th><th>External sd card Storage at sd card port [index]</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns  <p>After the method is successfully executed, successCallback is called without any parameter.</p>
	 *  <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setFailoverMode = function (successCallback, errorCallback, options) {
        var settings = {};

        var errorMessage;
        function checkOptions(options) {
            log("options:" + JSON.stringify(options, null, 3));
            var failoverMode = options.failoverMode;
            if (failoverMode) {

                if (failoverMode.mode) {
                    // If manual, see if priority is defined.
                    if (failoverMode.mode === Signage.FailoverMode.MANUAL) {
                        if (failoverMode.priority) {
                            if (failoverMode.priority.length === 0 || typeof failoverMode.priority.length === 'undefined') {
                                return false;
                            }
                            else {
                                return true;
                            }
                        }
                        else {
                            errorMessage = "priority should be present when mode is MANUAL.";
                            return false;
                        }
                    }
                    else {
                        // if not manual, return error if priority is defined.
                        if (failoverMode.priority) {
                            errorMessage = "This priority is available only if mode is : Signage.FailoverMode.MANUAL";
                            return false;
                        }
                        else {
                            var found = false;
                            // Should be one of the FailoverMode
                            log("Mode is: " + failoverMode.mode);
                            for (var key in Signage.FailoverMode) {
                                if (failoverMode.mode === Signage.FailoverMode[key]) {
                                    log("Matched with: " + Signage.FailoverMode[key]);
                                    found = true;
                                }
                            }

                            if (!found) {
                                log("Unrecognized failoverMode : " + failoverMode.mode);
                                errorMessage = "Unrecognized failoverMode : " + failoverMode.mode;
                                return false;
                            }
                            else {
                                return true;
                            }

                        }
                    }
                }
                else {
                    if (!failoverMode.priority) {
                        return true;
                    }
                    else {
                        log("Unrecognized failoverMode : " + failoverMode.mode);
                        errorMessage = "Unrecognized failoverMode : " + failoverMode.mode;
                        return false;
                    }
                }
            }
            else {
                errorMessage = "Fail over mode not set : ";
                return false;
            }

        }

        if (checkOptions(options)) {
            var failoverMode = options.failoverMode;
            if (!failoverMode.mode && !failoverMode.priority) {
                successCallback();
            }
            else if (failoverMode.mode === Signage.FailoverMode.MANUAL) {
                /*
				var priority = failoverMode.priority;
				log("priority: " + failoverMode.priority);
				for(var i=0;i<5; ++i){
                    var attrName = SETTINGS_KEY.FAILOVER_PRIORITY + (i+1);
                    log("attrName: " + attrName);
                    var inputValue = "";
                    if(i<priority.length) {
                        var inputUri = priority[i];
                        log("input: " + inputUri);
                        inputValue = getInputValue(inputUri);
                        if(inputValue === false){
                            var cbObj = {
                                errorCode : 'API_ERROR',
                                errorText : inputUri + " is not valid"
                            };
                            errorCallback(cbObj);
                            return;
                        }
				    }
				    else {
				        log("No more input URI");
				    }
				    log("inputValue: " + inputValue);
				    settings[attrName] = inputValue;
				}

				settings[SETTINGS_KEY.FAILOVER_MODE] = failoverMode.mode;
                */
                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "setManualFailoverPrioirty",
                    parameters: {
                        priority: failoverMode.priority
                    },
                    onSuccess: function (result) {
                        log("onSuccess");
                        if (result.returnValue) {
                            successCallback();
                        }
                        else {
                            log("FAILED: " + result.errorText);
                            errorCallback({
                                errorCode: result.errorCode,
                                errorText: result.errorText
                            });
                        }
                    },
                    onFailure: function (result) {
                        log("onFailure");
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                });

            }
            else if (failoverMode.mode) {
                var modeStr = failoverMode.mode;
                log("mode: " + failoverMode.mode);
                settings[SETTINGS_KEY.FAILOVER_MODE] = modeStr;
                log("Set: " + JSON.stringify(settings, null, 3));

                setSystemSettings("commercial", settings, successCallback, errorCallback);

                log("setFailoverMode Done");
            }
            else {
                var errorObj = {
                    errorCode: "BAD_PARAMETER",
                    errorText: "Mode should be set."
                };
                errorCallback(errorObj);
            }
        }
        else {
            var errorObj2 = {
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            };
            errorCallback(errorObj2);
        }
    };

	/**
	 * <p>Gets Failover mode.
	 *  When Failover Mode is set, monitor will automatically switch to the input source when the input signal fails, according to the predefined priorities set in the menu. </p>
	 *
	 * <p>IMPORTANT NOTE!!!!</p>
	 * <br>
	 * When failover is triggered due to lost signal, the signage application will not
	 * yield to the next priority input source set in the failover mode. When the signage application is destroyed, failover mode will be triggered.
	 *
	 * @example
	 * function getFailoverMode() {
	 *
	 *    var successCb = function (cbObject){
	 *      var mode = cbObject.mode;
	 *      var priority = cbObject.priority
	 *
	 *      console.log('Failover Mode : ' + mode);
	 *      console.log('Priority : ' + priority);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getFailoverMode(successCb, failureCb);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following parameters</p>
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>mode</th><th><a href="Signage.FailoverMode.html#constructor">Signage.FailoverMode</a> | Signage.UNDEFINED</th><th>Failover mode. Signage.UNDEFINED is returned when this item is not set.</th></tr>
	 *       <tr class="odd"><th>priority</th><th>Array</th><th>Input priority, as an ordered array of input source URI. Only valid when mode is set to MANUAL.</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * Input source can be :
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Name</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>ext://hdmi:[index]</th><th>HDMI Input</th></tr>
	 *       <tr class="odd"><th>ext://dvi:[index]</th><th>DVI Input</th></tr>
	 *       <tr><th>ext://internal_memory</th><th>Internal Storage</th></tr>
	 *       <tr class="odd"><th>ext://dp:[index]</th><th>Display Port</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *  <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.getFailoverMode = function (successCallback, errorCallback) {
        try {
            service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                method: "getFailoverPrioirty",
                parameters: {},
                onSuccess: function (result) {
                    log("onSuccess");
                    if (result.returnValue) {
                        var returnPriority = [];
                        for (var i=0; i<result.priority.length; i++)
                        {
                            var splitedPriority = result.priority[i].split("/");
                            var port = "";
                            if(typeof splitedPriority[3] === 'undefined')
                                returnPriority.push("ext://" + splitedPriority[2].toLowerCase());
                            else //complex label such as OPS/DVI
                                returnPriority.push("ext://" + splitedPriority[2].toLowerCase() + ":1");
                        }

                        successCallback({
                            priority: returnPriority,
                            mode: result.mode
                        });
                    }
                    else {
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                },
                onFailure: function (result) {
                    log("onFailure");
                    log("FAILED: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            });
        } catch (err) {
            log("EXCEPTION" + err);
            errorCallback({
                errorCode: "SGFO", // Temperatory error code
                errorText: "Signage.getFailoverMode occur error during operaation."
            });
        }
    };


    function getByType(val, type) {
        var mytype = typeof val;
        log("mytype: " + mytype);
        log("type: " + type);

        if (mytype === 'undefined') {
            return true;
        }
        else if (mytype === type) {
            return val;
        }
        else {
            return false;
        }
    }


	/**
	 * <p>Sets tile mode. Tile mode is used for multi-monitor display.</p>
	 * @example
	 *
	 * function setTileInfo() {
	 *    var options = {
	 *      tileInfo: {
	 *         enabled: true,
	 *         row : 2,
	 *         column : 2,
	 *         tileId: 2,
	 *         naturalMode : true
	 *      }
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log("Tile Info successfully Set");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setTileInfo(successCb, failureCb, options);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Object} options.tileInfo  TileInfo Object for setting.
	 * Only attributes that exist will be set.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>enabled</th><th>Boolean</th><th>Enable/disable Tile Mode</th><th>optional</th></tr>
	 *       <tr class="odd"><th>row</th><th>Number</th><th>Number of rows (1~15)</th><th>optional</th></tr>
	 *       <tr><th>column</th><th>Number</th><th>Number of columns (1~15)</th><th>optional</th></tr>
	 *       <tr class="odd"><th>tileId</th><th>Number</th><th>The ID for this monitor. It will start to count from 1, left to right and top to bottom (1~Rows x Columns)</th><th>optional</th></tr>
	 *       <tr><th>naturalMode</th><th>Boolean</th><th>Enable/disable Natural mode, which will adjust image based on the bezel size</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setTileInfo = function (successCallback, errorCallback, options) {
        var errorMessage;
        var checkOptions = function (options, tileRowMax, tileColMax) {
            var enabledType = typeof options.tileInfo.enabled;
            log("enabledType:" + enabledType);
            if (enabledType !== 'undefined' && enabledType !== 'boolean') {
                errorMessage = "enabled should be a boolean";
                return false;
            }

            var isNotANaturalNumber = function (isNum) {
                var ret = new RegExp(/^[0-9]+$/g).exec(isNum);
                if (ret) {
                    return false;
                }
                else {
                    return true;
                }
            };

            if (options.tileInfo) {
                var row = options.tileInfo.row;
                if (typeof row !== 'undefined') {
                    if (isNotANaturalNumber(row)) {
                        errorMessage = "row should be a natural number :" + row;
                        return false;
                    }
                    else if (row > tileRowMax || row < 1) {
                        errorMessage = "row should be 0<n<" + (tileRowMax+1) + " but :" + row;
                        return false;
                    }
                }
                else {
                    return true;
                }

                var column = options.tileInfo.column;
                if (typeof column !== 'undefined') {
                    if (isNotANaturalNumber(column)) {
                        errorMessage = "column should be a natural number :" + column;
                        return false;
                    }
                    else if (column > tileColMax || column < 1) {
                        errorMessage = "column should be 0<n<" + (tileColMax+1) + " but :" + column;
                        return false;
                    }
                }
                else {
                    return true;
                }

                var id = options.tileInfo.tileId;
                if (typeof id !== 'undefined') {
                    if (isNotANaturalNumber(id)) {
                        errorMessage = "id should be a natural number :" + id;
                        return false;
                    }
                    else if (id < 1) {
                        errorMessage = "id should be bigger than 0 but :" + id;
                        return false;
                    }
                    else {
                        var curRow = _gTileInfo.row;
                        if (row) { curRow = row; }

                        var curCol = _gTileInfo.column;
                        if (column) { curCol = column; }

                        log("curRow : " + curRow);
                        log("curCol : " + curCol);
                        log("id : " + id);


                        if (id > curCol * curRow) {
                            errorMessage = "ID should be less than curRow*curCol";
                            return false;
                        }
                    }
                }
                else {
                    return true;
                }
            } else {
                errorMessage = "Tile info is mandatory";
                return false;
            }
            return true;
        };

        var rowMax = 15;
        var colMax = 15;

        service.Request("luna://com.webos.service.config", {
            method: "getConfigs",
            parameters: {
                configNames: ["commercial.video.tileRowMax","commercial.video.tileColMax"]
            },
            onSuccess: function(result) {
                log("onSuccess");
                if (result.returnValue) {
                    rowMax = result.configs["commercial.video.tileRowMax"];
                    colMax = result.configs["commercial.video.tileColMax"];

                    if (checkOptions(options, rowMax, colMax) === true) {
                        var tileInfo = options.tileInfo;
                        var settings = {};

                        if (typeof tileInfo.enabled === 'boolean') {
                            if (tileInfo.enabled) {
                                settings[SETTINGS_KEY.TILE_MODE] = 'on';
                            } else {
                                settings[SETTINGS_KEY.TILE_MODE] = 'off';
                            }
                        }

                        if (tileInfo.row) {
                            settings[SETTINGS_KEY.TILE_ROW] = tileInfo.row.toString();
                        }

                        if (tileInfo.column) {
                            settings[SETTINGS_KEY.TILE_COLUME] = tileInfo.column.toString();
                        }

                        if (tileInfo.tileId) {
                            settings[SETTINGS_KEY.TILE_ID] = tileInfo.tileId.toString();
                        }

                        if (typeof tileInfo.naturalMode === 'boolean') {
                            if (tileInfo.naturalMode) {
                                settings[SETTINGS_KEY.TILE_NATURALMODE] = 'on';
                            } else {
                                settings[SETTINGS_KEY.TILE_NATURALMODE] = 'off';
                            }
                        }

                        log("Set: " + JSON.stringify(settings, null, 3));


                        var newCallBack = function() {
                            log("Do callback");

                            if (tileInfo.row) {
                                _gTileInfo.row = tileInfo.row;
                            }

                            if (tileInfo.column) {
                                _gTileInfo.column = tileInfo.column;
                            }

                            if (typeof successCallback === 'function') {
                                log("Invoke successCallback");
                                successCallback();
                                log("Invoked successCallback");
                            }
                        };
                        setSystemSettings("commercial", settings, newCallBack, errorCallback);

                        log("setTileInfo Done");
                    } else {
                        var cbObj = {
                            errorCode: "BAD_PARAM",
                            errorText: errorMessage
                        };
                        errorCallback(cbObj);
                    }
                } else {
                    log("FAILED: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function(result) {
                log("onFailure");
                log("FAILED: " + result.errorText);
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });

    };

    function getBooleanValue(value) {
        if (value === 'on') {
            return true;
        }
        else {
            return false;
        }
    }

	/**
	 * <p>Gets current tile mode.</p>
	 * @example
	 * function getTileInfo() {
	 *
	 *    var successCb = function (cbObject){
	 *
	 *      var enabled = cbObject.enabled;
	 *      var row = cbObject.row;
	 *      var column = cbObject.column;
	 *      var tileId = cbObject.tileId;
	 *      var naturalMode = cbObject.naturalMode;
	 *
	 *      console.log("enable: " + enabled);
	 *      console.log("row: " + row);
	 *      console.log("column: " + column);
	 *      console.log("tileId: " + tileId);
	 *      console.log("naturalMode: " + naturalMode);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getTileInfo(successCb, failureCb);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called with following data.</p>
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>enabled</th><th>Boolean</th><th>Enable/disable Tile Mode</th></tr>
	 *       <tr class="odd"><th>row</th><th>Number</th><th>Number of rows (1~15)</th></tr>
	 *       <tr><th>column</th><th>Number</th><th>Number of columns (1~15)</th></tr>
	 *       <tr class="odd"><th>tileId</th><th>Number</th><th>The ID for this monitor. It will start to count from 1, left to right and top to bottom (1~Rows x Columns)</th></tr>
	 *       <tr><th>naturalMode</th><th>Boolean</th><th>Enable/disable Natural mode, which will adjust image based on the bezel size</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 *
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.getTileInfo = function (successCallback, errorCallback) {
        var cbgetter = function (settings) {
            var cbObj = {};
            log("settings Value: " + JSON.stringify(settings, null, 3));
            cbObj.enabled = getBooleanValue(settings[SETTINGS_KEY.TILE_MODE]);
            cbObj.row = parseInt(settings[SETTINGS_KEY.TILE_ROW], 10);
            cbObj.column = parseInt(settings[SETTINGS_KEY.TILE_COLUME], 10);
            cbObj.tileId = parseInt(settings[SETTINGS_KEY.TILE_ID], 10);
            cbObj.naturalMode = getBooleanValue(settings[SETTINGS_KEY.TILE_NATURALMODE]);

            log("Return Value: " + JSON.stringify(cbObj, null, 3));
            return cbObj;
        };

        var keys = [SETTINGS_KEY.TILE_MODE, SETTINGS_KEY.TILE_ROW, SETTINGS_KEY.TILE_COLUME, SETTINGS_KEY.TILE_ID, SETTINGS_KEY.TILE_NATURALMODE];
        getSystemSettings("commercial", keys, cbgetter, successCallback, errorCallback);
    };

	/**
	 * <p>Gets signage information</p>
	 *
	 * @example
	 *
	 * function getSignageInfo() {
	 *
	 *    var successCb = function (cbObject){
	 *      var portraitMode= cbObject.portraitMode;
	 *      var ismMethod= cbObject.ismMethod;
	 *      var digitalAudioInputMode= cbObject.digitalAudioInputMode;
	 *
	 *      console.log("portraitMode: " + portraitMode);
	 *      console.log("ismMethod: " + ismMethod);
	 *
	 *      for(var input in digitalAudioInputMode){
	 *         var audioInput = digitalAudioInputMode[input];
	 *         console.log("digitalAudioInputMode for " + input +" = " + audioInput);
	 *      }
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getSignageInfo(successCb, failureCb);
	 *
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following parameters.</p>
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>portraitMode</th><th>Signage.OsdPortraitMode | Signage.UNDEFINED</th><th>Portrait mode.<br>If the value for this item is not set or defined, Signage.UNDEFINED will be returned. </th></tr>
	 *       <tr class="odd"><th>ismMethod</th><th>Signage.IsmMethod | Signage.UNDEFINED</th><th>ISM(Image Sticking Minimization) Method.<br>If the value for this item is not set or defined, Signage.UNDEFINED will be returned. </th></tr>
	 *       <tr><th>digitalAudioInputMode</th><th>Array</th><th>Digital audio input mode.<br>Array of {input_uri : Signage.DigitalAudioInput or Signage.UNDEFINED } pair. </th></tr>
	 *       <tr class="odd"><th>checkScreen</th><th>Boolean</th><th>Pixel sensor is enabled. true: enabled, false: disabled <br>If it is enabled, Signage.EventType.SCREEN_STATUS event is available. </th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 * @since 1.3 checkScreen
	 */
    Signage.prototype.getSignageInfo = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["commercial.unsupportedFeatures"]
            },
            onSuccess: function(result) {
                if (typeof successCallback === 'function' && result.returnValue === true) {
                    var unsupportISM = false;
                    var unsupportedFeatures = result.configs["commercial.unsupportedFeatures"];
                    for (var j = 0; j < unsupportedFeatures.length; j++) {
                        if (unsupportedFeatures[j].toLowerCase() === "ismmethod") {
                            unsupportISM = true;
                            break;
                        }
                    }

                    service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
                        method: "getSignageInformation",
                        parameters: {},
                        onSuccess: function (res) {
                            if (typeof successCallback === 'function') {
                                log(res.signageInfo);

                                if(typeof res.signageInfo.digitalAudioInputMode !== 'undefined')
                                {
                                    var digitalAudioInputMode = {};
                                    for(key in res.signageInfo.digitalAudioInputMode)
                                        digitalAudioInputMode[key.toLowerCase()] = res.signageInfo.digitalAudioInputMode[key].toLowerCase();

                                    res.signageInfo.digitalAudioInputMode = digitalAudioInputMode;
                                }

                                if (unsupportISM === true) {
                                    delete res.signageInfo.ismMethod;
                                }

                                successCallback(res.signageInfo);
                            }
                        },
                        onFailure: function (result) {
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                errorCallback(result);
                            }
                        }
                    });

                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });
    };

	/**
     * <p>Enables pixel sensor.</p>
     *
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>checkScreen</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     *
     * @example
     * function enableCheckScreen() {
     *
     *    var successCb = function (){
     *      console.log("Successfully enabled checkScreen");
     *    };
     *
     *    var failureCb = function(cbObject){
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log( " Error Code [" + errorCode + "]: " + errorText);
     *    };
     *
     *    var options = {
     *      checkScreen : true
     *    };
     *
     *    var signage = new Signage();
     *    signage.enableCheckScreen(successCb, failureCb, options);
     * }
     *
     * @since 1.3
     *
     * @see
     * <a href="Signage%23getSignageInfo.html">Signage.getSignageInfo()</a><br>
     */
    Signage.prototype.enableCheckScreen = function (successCallback, errorCallback, options) {

        var errorMessage;

        var checkOptions = function (options) {
            if (typeof options.checkScreen !== "undefined" || options.checkScreen !== null) {
                return true;
            } else {
                errorMessage = "need options.checkScreen.";
                return false;
            }
        };

        if (checkOptions(options)) {

            var settings = {
                checkScreen: (options.checkScreen === true ? "on" : "off")
            };

            log("Set: " + JSON.stringify(settings, null, 3));

            setSystemSettings("commercial", settings, successCallback, errorCallback);

            log("enableCheckScreen Done");
        } else {
            var cbObj = {
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            };
            errorCallback(cbObj);
        }
    };

	/**
	 * <p>Sets ISM(Image Sticking Minimization) Method.</p>
	 *
	 * @example
	 *
	 * function setIsmMethod() {
	 *    var options = {
	 *      ismMethod : Signage.IsmMethod.NORMAL
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log("Successfully set ISM Method");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setIsmMethod (successCb, failureCb, options);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Signage.IsmMethod} options.ismMethod ISM Method.
	 * @returns
	 * <p>
	 * After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setIsmMethod = function (successCallback, errorCallback, options) {
        var settings = {};
        var errorMessage;
        function checkOptions(options, hasUserImage, hasUserVideo) {
            if (options.ismMethod) {

                if((hasUserImage === false && options.ismMethod === Signage.IsmMethod.USER_IMAGE) ||
                    (hasUserVideo === false && (options.ismMethod === Signage.IsmMethod.USER_IMAGE || options.ismMethod === Signage.IsmMethod.USER_VIDEO)))
                {
                    errorMessage = "no supported ismMethod  : " + options.ismMethod;
                    return false;
                }

                for (var key in Signage.IsmMethod) {
                    if (options.ismMethod === Signage.IsmMethod[key]) {
                        return true;
                    }
                }

                errorMessage = "Unrecognized ismMethod  : " + options.ismMethod;
                return false;
            }
            else {
                errorMessage = "ismMethod  does not exist.";
                return false;
            }
        }

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["commercial.applist.disablePhoto","commercial.unsupportedFeatures"]
            },
            onSuccess: function(result) {
                if (typeof successCallback === 'function' && result.returnValue === true) {
                    //successCallback();

                    var hasUserImage = true;
                    var hasUserVideo = true;
                    var support      = true;
                    var disablePhoto = result.configs["commercial.applist.disablePhoto"];
                    for (var i = 0; i < disablePhoto.length; i++) {
                        if (disablePhoto[i].toLowerCase() === "com.webos.app.ism") {
                            hasUserImage = false;

                            break;
                        }
                    }

                    var unsupportedFeatures = result.configs["commercial.unsupportedFeatures"];
                    for (var j = 0; j < unsupportedFeatures.length; j++) {
                        if (unsupportedFeatures[j].toLowerCase() === "usb") {
                            hasUserImage = false;
                            hasUserVideo = false;
                        } else if (unsupportedFeatures[j].toLowerCase() === "ismmethod") {
                            support = false;
                        }
                    }

                    if (support === false) {
                        var cbObj = {};
                        checkErrorCodeNText(cbObj, "SSIM", "unsupported feature");
                        errorCallback(cbObj);
                        return;
                    }

                    if (checkOptions(options, hasUserImage, hasUserVideo)) {
                        if (options.ismMethod) {
                            var ismMethod = options.ismMethod;
                            log("ismMethod : " + ismMethod);
                            settings[SETTINGS_KEY.ISM_METHOD] = ismMethod;
                        }

                        log("Set: " + JSON.stringify(settings, null, 3));

                        setSystemSettings("commercial", settings, successCallback, errorCallback);

                        log("setIsmMethod Done");
                    } else {
                        var cbObj = {
                            errorCode: "BAD_PARAMETER",
                            errorText: errorMessage
                        };
                        errorCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });
    };



	/**
	 * <p>Sets digital audio input mode. </p> <br>
	 * Audio from different source can be mixed with a video from HDMI or DP using this method.
	 * @example
	 * function setDigitalAudioInputMode() {
	 *
	 *    var options = {
	 *      digitalAudioInputList:{
	 *         'ext://hdmi:1' : Signage.DigitalAudioInput.HDMI_DP,
	 *         'ext://hdmi:2' : Signage.DigitalAudioInput.HDMI_DP,
	 *         'ext://dp:1' : Signage.DigitalAudioInput.AUDIO_IN
	 *      }
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log("Successfully Done");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setDigitalAudioInputMode (successCb, failureCb, options);
	 *
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Object} options.digitalAudioInputList List of digital audio input mode.
	 * In HDMI_DP mode, same audio from HDMI or DP is used. In AUDIO_IN mode, HDMI or DP video input can be used with external analog audio input.
	 * @returns
	 * <p>
	 * After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setDigitalAudioInputMode = function (successCallback, errorCallback, options) {

        var errorMessage;
        function checkOptions(options) {
            if (options.digitalAudioInputList) {
                for (var key in options.digitalAudioInputList) {
                    if (key) {
                        var value = options.digitalAudioInputList[key];
                        var found = false;
                        for (var type in Signage.DigitalAudioInput) {
                            if (value === Signage.DigitalAudioInput[type]) {
                                found = true;
                            }
                        }
                        if (!found) {
                            errorMessage = "Invalid Audio Input  : " + value;
                            return false;
                        }
                    }
                }
                return true;
            } else {
                errorMessage = "digitalAudioInputList  does not exist.";
                return false;
            }
        }



        if (checkOptions(options)) {
            /*for(var input in options.digitalAudioInputList){
                if(input === 'ext://hdmi:1'){
                    settings[SETTINGS_KEY.AUDIO_SOURCE_HDMI1] = options.digitalAudioInputList[input];
                }
                else if(input === 'ext://hdmi:2'){
                    settings[SETTINGS_KEY.AUDIO_SOURCE_HDMI2] = options.digitalAudioInputList[input];
                }
                else if(input === 'ext://dp:1'){
                    settings[SETTINGS_KEY.AUDIO_SOURCE_DP] = options.digitalAudioInputList[input];
                }
            }*/

            service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
                method: "setDigitalAudioInputList",
                parameters: {
                    digitalAudioInputList: options.digitalAudioInputList
                },
                onSuccess: function() {
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                },
                onFailure: function(result) {
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        errorCallback(result);
                    }
                }
            });
        } else {
            var cbObj = {
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            };
            errorCallback(cbObj);
        }

    };


    var _gDoBlock = false;
	/**
	 * <p>
	 * Registers system monitoring setting. If one of the attributes is set to true, corresponding sensor events will be received.
	 * When this method is called, all the previously registered monitoring event setup will be reset.
	 * </p>
	 * @example
	 *
	 * function registerSystemMonitor() {
	 *    var eventHandler = function(event){
	 *      console.log("Received Event from : " + event.source);
	 *      console.log("Event Type is : " + event.type);
	 *      console.log("Additional Info : " + JSON.stringify(event.data));
	 *    };
	 *
	 *    var options = {
	 *      monitorConfiguration: {
	 *         fan: true,
	 *         signal : true,
	 *         lamp : true,
	 *         screen : true,
	 *      },
	 *      eventHandler : eventHandler
	 *    };
	 *
	 *    var successCb = function (){
	 *      console.log("successfully Set");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.registerSystemMonitor(successCb, failureCb, options);
	 *
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Object} options.monitorConfiguration  monitorConfiguration object for setting.
	 * Only attributes that exist will be set.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>fan</th><th>Boolean</th><th>Receive events from the sensor that monitors the fan </th><th>optional</th></tr>
	 *       <tr class="odd"><th>signal</th><th>Boolean</th><th>Receive events from the signal receiver</th><th>optional</th></tr>
	 *       <tr><th>lamp</th><th>Boolean</th><th>Receive events from the sensor that monitors the lamp</th><th>optional</th></tr>
	 *       <tr class="odd"><th>screen</th><th>Boolean</th><th>Receive events from the sensor that monitors the screen</th><th>optional</th></tr>
	 *       <tr><th>temperature</th><th>Boolean</th><th>Receive events from the sensor that monitors the audio</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @param {Function} options.eventHandler The function for handling system monitor events.
	 * This function has an event object as a parameter, which contains following properties.
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>source</th><th>Signage.MonitoringSource</th><th>The source of this event</th><th>required</th></tr>
	 *       <tr class="odd"><th>type</th><th>Signage.EventType</th><th>Event Type</th><th>required</th></tr>
	 *       <tr><th>data</th><th>Object</th><th>Additional Data. Format may vary for event type</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * @returns
	 * <p>
	 * After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.registerSystemMonitor = function (successCallback, errorCallback, options) {
        var keys = ['fan', 'signal', 'lamp', 'screen', 'temperature'];
        var errorMessage;
        var errorCode = "BAD_PARAMETER";

        log("Listeners are: " + JSON.stringify(_gSystemMonitoringSetup, null, 3));

        function checkOptions(options) {
            if (_gDoBlock === true) {
                errorMessage = "Not ready to register monitor now.";
                errorCode = "SYSTEM_ERROR";
                return false;
            }

            log("options are: " + JSON.stringify(options, null, 3));

            if (typeof options.eventHandler !== 'function') {
                errorMessage = "No event handler was given or event hadnler is not a function";
                return false;
            }

            if (options.monitorConfiguration) {
                for (var key in options.monitorConfiguration) {
                    if (key) {
                        var found = false;
                        for (var i = 0; i < keys.length; ++i) {
                            if (key === keys[i]) {
                                log("Found key: " + keys[i]);
                                found = true;
                            }
                        }

                        if (!found) {
                            errorMessage = "Invalid Monitoring source  : " + key;
                            return false;
                        }

                        var value = options.monitorConfiguration[key];
                        log("value: " + value);

                        if (typeof value !== 'boolean') {
                            errorMessage = "Invalid value  : " + value;
                            return false;
                        }
                    }
                }
                return true;
            }
            else {
                errorMessage = "monitorConfiguration  does not exist.";
                return false;
            }
        }

        if (checkOptions(options)) {

            var cancelSuccess = function () {
                log("Canceled all previous message subscriptions");

                var handler = options.eventHandler;
                for (var key in options.monitorConfiguration) {
                    if (key) {
                        var value = options.monitorConfiguration[key];
                        if (value === true) {
                            log("Add listener for : " + key);
                            addSignageEventListener(key, handler);
                        }
                    }
                }
                log("Monitoring Setup : " + JSON.stringify(_gSystemMonitoringSetup, null, 3));

                // Start Polling
                log("Start Polling : ");

                service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                    method: "systemMonitor/startMonitor",
                    parameters: {},
                    onSuccess: function (result) {
                        log("On Success");
                        if (result.returnValue === true) {
                            if (typeof successCallback === 'function') {
                                successCallback();
                            }
                        }
                        else {
                            if (typeof errorCallback === 'function') {
                                errorCallback(result);
                            }
                        }
                        _gDoBlock = false;
                    },
                    onFailure: function (result) {
                        log("On Failure");
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            errorCallback(result);
                        }
                        _gDoBlock = false;
                    }
                });
            };

            var cancelError = function (result) {
                errorCallback(result);
            };

            // Cancel all previous message subscriptions
            log("Cancel all previous message subscriptions");
            _gDoBlock = true;
            cancelAllSubscription(cancelSuccess, cancelError);
        }
        else {
            var cbObj = {
                errorCode: errorCode,
                errorText: errorMessage
            };
            errorCallback(cbObj);
        }
    };

	/**
	 * <p>
	 * Unregisters all the system monitoring handlers. No more monitoring events will be received.
	 * </p>
	 * @example
	 *
	 * function unregisterSystemMonitor() {
	 *    var successCb = function (){
	 *      console.log("successfully canceled");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.unregisterSystemMonitor(successCb, failureCb);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */

    Signage.prototype.unregisterSystemMonitor = function (successCallback, errorCallback) {
        cancelAllSubscription(successCallback, errorCallback);
        log("After unregister, _gSystemMonitoringSetup are: " + JSON.stringify(_gSystemMonitoringSetup, null, 3));
    };

    function cancelAllSubscription(successCallback, errorCallback) {
        log("cancelAllSubscription> setup are: " + JSON.stringify(_gSystemMonitoringSetup, null, 3));

        for (var key in _gSystemMonitoringSetup) {
            if (key) {
                removeSignageEventListener(key);
            }
        }

		/*
		if(_gSystemMonitoringSetup.fan === true){
			log("Remove monitor_fan");
			removeEventListener('monitor_fan');
			_gSystemMonitoringSetup.fan = false;
		}

		if(_gSystemMonitoringSetup.screen === true){
			log("Remove monitor_screen");
			removeEventListener('monitor_screen');
			_gSystemMonitoringSetup.screen = false;
		}

		if(_gSystemMonitoringSetup.temperature === true){
			log("Remove monitor_temperature");
			removeEventListener('monitor_temperature');
			_gSystemMonitoringSetup.temperature = false;
		}

		if(_gSystemMonitoringSetup.signal === true){
			log("Remove monitor_signal");
			removeEventListener('monitor_signal');
			_gSystemMonitoringSetup.signal = false;
		}
		if(_gSystemMonitoringSetup.lamp === true){
			log("Remove monitor_lamp");
			removeEventListener('monitor_lamp');
			_gSystemMonitoringSetup.lamp = false;
		}
		 */
        log("Stop Polling");

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "systemMonitor/stopMonitor",
            parameters: {},
            onSuccess: function (result) {
                log("On Success");
                if (result.returnValue === true) {
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                }
                else {
                    if (typeof errorCallback === 'function') {
                        errorCallback(result);
                    }
                }
            },
            onFailure: function (result) {
                log("On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });
    }


	/**
	 * <p>Gets system monitoring setting. If one of the attributes is set to true, corresponding sensor events will be sent.
	 * Use onSignageMonitoringEvent to register handler for those events.
	 * </p>
	 * @example
	 * function getSystemMonitoringInfo() {
	 *    var successCb = function (cbObject){
	 *      var fan =  cbObject.fan;
	 *      var signal =  cbObject.signal;
	 *      var lamp =  cbObject.lamp;
	 *      var screen =  cbObject.screen;
	 *      var temperature =  cbObject.temperature;
	 *
	 *      console.log("Monitor Fan: " + fan);
	 *      console.log("Monitor signal: " + signal);
	 *      console.log("Monitor lamp: " + lamp);
	 *      console.log("Monitor screen: " + screen);
	 *      console.log("Monitor temperature: " + temperature);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getSystemMonitoringInfo(successCb, failureCb);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @returns  <p>After the method is successfully executed, successCallback is called with monitorConfiguration object with following data</p>
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>fan</th><th>Boolean</th><th>Receive events from the sensor that monitors the fan </th></tr>
	 *       <tr class="odd"><th>signal</th><th>Boolean</th><th>Receive events from the signal receiver</th></tr>
	 *       <tr><th>lamp</th><th>Boolean</th><th>Receive events from the sensor that monitors the lamp</th></tr>
	 *       <tr class="odd"><th>screen</th><th>Boolean</th><th>Receive events from the sensor that monitors the screen</th></tr>
	 *       <tr><th>temperature</th><th>Boolean</th><th>Receive events from the sensor that monitors the temperature</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 * */

    Signage.prototype.getSystemMonitoringInfo = function (successCallback, errorCallback) {
        if (_gSystemMonitoringSetup) {
            successCallback({
                fan: _gSystemMonitoringSetup.fan.getEvent,
                signal: _gSystemMonitoringSetup.signal.getEvent,
                lamp: _gSystemMonitoringSetup.lamp.getEvent,
                screen: _gSystemMonitoringSetup.screen.getEvent,
                temperature: _gSystemMonitoringSetup.temperature.getEvent
            });
        }
        else {
            var cbObj = {
                errorCode: "ERROR",
                errorText: "Failed to get system monitoring setup"
            };
            errorCallback(cbObj);
        }
    };

	/**
	 * <p>Sets power saving mode.</p>
	 * @example
	 * function setPowerSaveMode() {
	 *    var options = {
	 *      powerSaveMode: {
	 *         ses: true,
	 *         dpmMode: Signage.DpmMode.OFF,
	 *         automaticStandby: Signage.AutomaticStandbyMode.OFF,
	 *         do15MinOff: true,
	 *      }
	 *   };
	 *
	 *    var successCb = function (){
	 *      console.log("successfully Set");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.setPowerSaveMode(successCb, failureCb, options);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Object} options.powerSaveMode  powerSaveMode object.
	 * Only attributes that exist will be set.
	 * 'automaticStandby' mode is triggered when there are no RCU or local key input for 4 hours.
	 * '15MinOff' mode is triggered when there is no video input for 15 minutes.
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>ses</th><th>Boolean</th><th>Smart Energy Saving mode.</br>This will deduce monitor power usage by manipulating the power usage on the screen backlight etc. </th><th>optional</th></tr>
	 *       <tr class="odd"><th>dpmMode</th><th>Signage.DpmMode</th><th>Display Power Management mode.</br>Sets the monitor power off time while there is no signal/no user inputs/no application on the monitor</th><th>optional</th></tr>
	 *       <tr><th>automaticStandby</th><th>Signage.AutomaticStandbyMode</th><th>Automatic standby mode.</br>Sets the monitor power off time while there is no user inputs on the monitor</th><th>optional</th></tr>
	 *       <tr class="odd"><th>do15MinOff</th><th>Boolean</th><th>15 Minutes off mode.</br>Sets the monitor power off time while there is no signal/no user inputs on the monitor</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * @returns
	 * <p>
	 * After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */

    Signage.prototype.setPowerSaveMode = function (successCallback, errorCallback, options) {
        var errorMessage;
        function checkOptions(options) {
            if (options.powerSaveMode) {
                for (var key in options.powerSaveMode) {
                    if (key) {
                        var value = options.powerSaveMode[key];
                        if (key === 'ses' || key === 'do15MinOff') {
                            if (typeof value !== 'boolean') {
                                errorMessage = "Invalid value  : " + value;
                                return false;
                            }
                        }

                        else if (key === 'automaticStandby') {
                            if (!isValidEnum(Signage.AutomaticStandbyMode, value)) {
                                errorMessage = "Invalid automaticStandby value  : " + value;
                                return false;
                            }
                        }

                        else if (key === 'dpmMode') {
                            if (!isValidEnum(Signage.DpmMode, value)) {
                                errorMessage = "Invalid dpmMode value  : " + value;
                                return false;
                            }
                        }
                        else {
                            errorMessage = "Unknown value  : " + key;
                            return false;
                        }
                    }
                }

                return true;
            }
            else {
                errorMessage = "powerSaveMode  does not exist.";
                return false;
            }
        }

        if (checkOptions(options)) {
            log(options.powerSaveMode);
            service.Request("luna://com.webos.service.commercial.signage.storageservice", {
                method: "setPowerSaveMode",
                parameters: {
                    mode: options.powerSaveMode
                },
                onSuccess: function (result) {
                    log("onSuccess");
                    if (result.returnValue) {
                        successCallback(result.mode);
                    }
                    else {
                        log("FAILED: " + result.errorText);
                        errorCallback({
                            errorCode: result.errorCode,
                            errorText: result.errorText
                        });
                    }
                },
                onFailure: function (result) {
                    log("onFailure");
                    log("FAILED: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            });

        }
        else {
            var cbObj = {
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            };
            errorCallback(cbObj);
        }
    };

	/**
	 * <p>Gets power saving mode.</p>
	 * @example
	 *
	 * function getPowerSaveMode() {
	 *    var successCb = function (cbObject){
	 *      var ses = cbObject.ses;
	 *      var dpmMode = cbObject.dpmMode;
	 *      var automaticStandby = cbObject.automaticStandby;
	 *      var do15MinOff = cbObject.do15MinOff;
	 *
	 *      console.log("Smart Energy Saving: " + ses);
	 *      console.log("Display Power Management: " + dpmMode);
	 *      console.log("Automatic Standby Mode: " + automaticStandby);
	 *      console.log("15 Minutes Off: " + do15MinOff);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 * var signage = new Signage();
	 * signage.getPowerSaveMode(successCb, failureCb);
	 *
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following data.</p>
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>ses</th><th>Boolean</th><th>Smart Energy Saving mode.<br> This will deduce monitor power usage by manipulating the power usage on the screen backlight etc. </th></tr>
	 *       <tr class="odd"><th>dpmMode</th><th>Signage.DpmMode</th><th>Display Power Management mode.<br>Sets the monitor power off time while there is no signal/no user inputs/no application on the monitor</th></tr>
	 *       <tr><th>automaticStandby</th><th>Signage.AutomaticStandbyMode</th><th>Automatic standby mode.<br>Sets the monitor power off time while there is no user inputs on the monitor</th></tr>
	 *       <tr class="odd"><th>do15MinOff</th><th>Boolean</th><th>15 Minutes off mode.<br>Sets the monitor power off time while there is no signal/no user inputs on the monitor</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.getPowerSaveMode = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "getPowerSaveMode",
            parameters: {},
            onSuccess: function (result) {
                log("onSuccess");
                if (result.returnValue) {
                    successCallback(result.mode);
                }
                else {
                    log("FAILED: " + result.errorText);
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("onFailure");
                log("FAILED: " + result.errorText);
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });

    };

	/**
	 * <p>Sets usage policy. It is used to limit monitor functions.</p>
	 * @example
	 *
	 * function setUsagePermission() {
	 *    var options = {
	 *      policy: {
	 *         remoteKeyOperationMode: Signage.KeyOperationMode.POWER_ONLY,
	 *         localKeyOperationMode: Signage.KeyOperationMode.POWER_ONLY,
	 *      }
	 *   };
	 *
	 *    var successCb = function (){
	 *      console.log("successfully Set");
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *         console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *       };
	 *
	 *    var signage = new Signage();
	 *    signage.setUsagePermission(successCb, failureCb, options);
	 *
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options  parameter list.
	 * @param {Object} options.policy  Policy object.
	 *
	 * Only attributes that exist will be set.
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>remoteKeyOperationMode</th><th>KeyOperationMode</th><th>Remote Key operation mode </th><th>optional</th></tr>
	 *       <tr class="odd"><th>localKeyOperationMode</th><th>KeyOperationMode</th><th>Built-in key operation mode</th><th>optional</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called without any parameter.</br>
	 * If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.setUsagePermission = function (successCallback, errorCallback, options) {
        var settings = {};
        var errorMessage;

        function checkOptions(options) {
            if (options.policy) {
                for (var key in options.policy) {
                    if (key) {
                        var value = options.policy[key];
                        if (key === 'remoteKeyOperationMode' || key === 'localKeyOperationMode') {
                            if (!isValidEnum(Signage.KeyOperationMode, value)) {
                                errorMessage = "Invalid  KeyOperationMode value  : " + value;
                                return false;
                            }
                        }
                        else {
                            errorMessage = "Unknown value  : " + key;
                            return false;
                        }
                    }

                }
                return true;
            }
            else {
                errorMessage = "policy  does not exist.";
                return false;
            }
        }

        if (checkOptions(options)) {
            if (options.policy.localKeyOperationMode) {
                var localKeyOperationMode = options.policy.localKeyOperationMode;
                log("portraitMode: " + localKeyOperationMode);
                settings[SETTINGS_KEY.LOCALKEY_OPERATION_MODE] = localKeyOperationMode;
            }

            if (options.policy.remoteKeyOperationMode) {
                var remoteKeyOperationMode = options.policy.remoteKeyOperationMode;
                log("portraitMode: " + remoteKeyOperationMode);
                settings[SETTINGS_KEY.IR_OPERATION_MODE] = remoteKeyOperationMode;
            }

            log("Set: " + JSON.stringify(settings, null, 3));

            setSystemSettings("hotelMode", settings, successCallback, errorCallback);

            log("setPolicy Done");
        }
        else {
            var cbObj = {
                errorCode: "BAD_PARAMETER",
                errorText: errorMessage
            };
            errorCallback(cbObj);
        }

    };

	/**
	 * <p>Gets usage policy. </p>
	 * @example
	 *
	 * function getUsagePermission() {
	 *    var successCb = function (cbObject){
	 *      var remoteKeyOperationMode = cbObject.remoteKeyOperationMode;
	 *      var localKeyOperationMode = cbObject.localKeyOperationMode;
	 *      console.log("remoteKeyOperationMode: " + remoteKeyOperationMode);
	 *      console.log("localKeyOperationMode: " + localKeyOperationMode);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getUsagePermission(successCb, failureCb);
	 * }
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following data.</p>
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>remoteKeyOperationMode</th><th>KeyOperationMode</th><th>Remote Key operation mode </th></tr>
	 *       <tr class="odd"><th>localKeyOperationMode</th><th>KeyOperationMode</th><th>Built-in key operation mode</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.getUsagePermission = function (successCallback, errorCallback) {
        var cbgetter = function (settings) {
            log('settings: ' + JSON.stringify(settings, null, 3));

            var cbObj = {};
            cbObj.remoteKeyOperationMode = settings[SETTINGS_KEY.IR_OPERATION_MODE];
            cbObj.localKeyOperationMode = settings[SETTINGS_KEY.LOCALKEY_OPERATION_MODE];

            log('cbObj: ' + JSON.stringify(cbObj, null, 3));
            return cbObj;
        };

        var keys = [SETTINGS_KEY.IR_OPERATION_MODE, SETTINGS_KEY.LOCALKEY_OPERATION_MODE];
        getSystemSettings("hotelMode", keys, cbgetter, successCallback, errorCallback);
    };

	/**
	 * <p>Gets current usage data information.</p>
	 *
	 * @example
	 *
	 * function getUsageData() {
	 *    var successCb = function (cbObject){
	 *      var uptime= cbObject.uptime;
	 *      var totalUsed= cbObject.totalUsed;
	 *      console.log("Uptime: " + uptime);
	 *      console.log("Total Used: " + totalUsed);
	 *    };
	 *
	 *    var failureCb = function(cbObject){
	 *      var errorCode = cbObject.errorCode;
	 *      var errorText = cbObject.errorText;
	 *      console.log( " Error Code [" + errorCode + "]: " + errorText);
	 *    };
	 *
	 *    var signage = new Signage();
	 *    signage.getUsageData(successCb, failureCb);
	 * }
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following data.</p>
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>uptime</th><th>Number</th><th>Uptime. (Hours after last power on. Showing upto the nearest hundredths. Ex) 1.5 = 1 hour 30 minutes, etc)</th></tr>
	 *       <tr class="odd"><th>totalUsed</th><th>Number</th><th>Total Used. (Total usage hours)</th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 */
    Signage.prototype.getUsageData = function (successCallback, errorCallback) {


        //var powerHistoryKey = "powerOnOffHistory";

        var gotTT = false;
        var gotUT = false;

        var cbObject = {
            uptime: false,
            totalUsed: false
        };

        function accessResult() {
            log("accessResult");

            if (gotTT === true && gotUT === true) {
                log("CB Object: " + JSON.stringify(cbObject, null, 3));
                if (cbObject.uptime === false || cbObject.totalUsed === false) {
                    errorCallback({
                        errorCode: "CORDOVA_FAIL",
                        errorText: "Failed to get usage data"
                    });
                    return;
                }
                else {
                    log("SUCCESS");
                    successCallback(cbObject);
                    return;
                }
            }
            else {
                log("Not Yet");
            }
        }

        service.Request("luna://com.webos.service.tv.signage/", {
            method: "getUTT",
            parameters: {},
            onSuccess: function (result) {
                log("On getUTT Success");
                gotTT = true;
                if (result.returnValue === true) {
                    log("UTT is :" + result.UTT);
                    cbObject.totalUsed = result.UTT;
                }
                accessResult();
            },
            onFailure: function (result) {
                log("On getUTT Failure :" + JSON.stringify(result, null, 3));
                gotTT = true;
                accessResult();
            }
        });

        service.Request("luna://com.webos.service.tv.signage/", {
            method: "dsmp/getElapsedTime",
            parameters: {},
            onSuccess: function (result) {
                log("On getElapsedTime Success");
                gotUT = true;
                log("result: " + JSON.stringify(result, null, 3));

                if (result.returnValue === true) {
                    var elapsedTime = result.elapsedTime;
                    cbObject.uptime = elapsedTime;
                    log("Elapsed!!: " + elapsedTime);
                }
                accessResult();
            },
            onFailure: function (result) {
                log("On getSystemSettings Failure " + JSON.stringify(result, null, 3));
                gotUT = true;
                accessResult();
            }
        });
    };

	/**
	 * <p>Gets screen capture image. Captured screen image will be returned as JPEG image encoded in base64 string. </p>
	 *
	 * @example
	 * function doCapture(){
	 *   var signage = new Signage();
	 *
	 *   var successCB = function(cbobj){
	 *      var data = cbobj.data;
	 *      var size = cbobj.size;
	 *      var encoding = cbobj.encoding;
	 *      console.log("Got Data size:" + size);
	 *      console.log("Got Data encoding :" + encoding);
	 *      console.log("Got Data :" + data);
	 *
	 *      var capturedElement = document.getElementById('captured_img');
	 *      capturedElement.src = 'data:image/jpeg;base64,' + data;
	 *   };
	 *
	 *   var failureCB = function(cbobj){
	 *      console.log(JSON.stringify(cbobj, null, 3));
	 *   }
	 *
	 *   var options = {
	 *      save : true
	 *   };
	 *
	 *   signage.captureScreen(successCB, failureCB, options);
	 * }
	 *
	 *
	 * @class Signage
	 * @param {Function} successCallback success callback function.
	 * @param {Function} errorCallback failure callback function.
	 * @param {Object} options
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>save</th><th>Boolean</th><th>true : saves the captured image file(0_captured_by_scap.jpg) on local storage (content folder and media folder for fail-over mode) <br>and it will be displayed when the fail-over mode is activated, overwriting existing image file which is captured before. false : not save. default value </a></th><th>optional</th></tr>
	 *       <tr class="odd"><th>thumbnail</th><th>Boolean</th><th>true : reduced size version of picutre (128 X 72). <br>false : options.imgResolution size. default value </th><th>optional</th></tr>
	 *       <tr><th>imgResolution</th><th>String</th><th><a href="Signage.ImgResolution.html#constructor">Signage.ImgResolution</a></th><th>optional</th></tr>
     *   </tbody>
	 * </table>
	 * </div>
	 *
	 * @returns  <p>After the method is successfully executed, successCallback is called with the following data.</p>
	 *
	 * <div align=left>
	 * <table class="hcap_spec" width=400>
	 *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
	 *   <tbody>
	 *       <tr><th>cbObject.data</th><th>String</th>
	 *       <th>
	 *       <p>JPEG screen shot image which is encoded in base64 string. </p>
	 *       </th></tr>
	 *       <tr><th>cbObject.size</th><th>number</th>
	 *       <th>
	 *       <p>size of the data. </p>
	 *       </th></tr>
	 *       <tr><th>cbObject.encoding</th><th>string</th>
	 *       <th>
	 *       <p>encoding used for the data (base64) </p>
	 *       </th></tr>
	 *   </tbody>
	 * </table>
	 * </div>
	 *
	 * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
	 *
	 * @since 1.0
	 * @since 1.1 options.save options.thumbnail added
	 * @since 1.2 options.save, saves image also under application's content folder
     * @since 1.4.1 options.imgResolution added
	 *
	 */
    Signage.prototype.captureScreen = function (successCallback, errorCallback, options) {

        var param = {
            save: (options === undefined || options === null || options.save === undefined ? false : options.save)
        };

        if (options !== undefined && options !== null &&
            options.thumbnail !== undefined && options.thumbnail === true) {
            param.width = 128;
            param.height = 72;
        }
        else if (options.imgResolution === Signage.ImgResolution.FHD) {
            param.width = 1920;
            param.height = 1080;
        }
        else //default is HD
        {
            param.width = 1280;
            param.height = 720;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice", {
            method: "captureScreen",
            parameters: param,
            onSuccess: function (result) {
                log("On Success");
                if (result.returnValue === true) {
                    successCallback({
                        data: result.data,
                        size: result.size,
                        encoding: result.encoding
                    });
                }
                else {
                    errorCallback({
                        errorCode: result.errorCode,
                        errorText: result.errorText
                    });
                }
            },
            onFailure: function (result) {
                log("On Failure");
                errorCallback({
                    errorCode: result.errorCode,
                    errorText: result.errorText
                });
            }
        });
    };

	/**
     * set IntelligentAuto enabled/disabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setIntelligentAuto () {
     *   var options = {
     *      enabled : true
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.setIntelligentAuto(successCb, failureCb, options);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23getIntelligentAuto.html">Signage.getIntelligentAuto()</a><br>
     */
    Signage.prototype.setIntelligentAuto = function (successCallback, errorCallback, options) {
        log("setIntelligentAuto: " + options.enabled);

        if (options.enabled === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "SSIA", "Signage.setIntelligentAuto returns failure. command was not defined.");
            errorCallback(result);
            log("Signage.setIntelligentAuto invalid ");
            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "intelligentAuto" : (options.enabled === true ) ? "on" : "off"
                }
            },
            onSuccess : function(result) {
                log("setIntelligentAuto: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setIntelligentAuto: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSIA", "Signage.setIntelligentAuto returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Signage.setIntelligentAuto Done");
    };

		/**
     * Gets IntelligentAuto enabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getIntelligentAuto () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("enabled : " + cbObject.enabled);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.getIntelligentAuto(successCb, failureCb);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23setIntelligentAuto.html">Signage.setIntelligentAuto()</a><br>
     */
    Signage.prototype.getIntelligentAuto = function (successCallback, errorCallback) {

        log("getIntelligentAuto: ");

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "get",
                parameters : {
                    category : "commercial",
                    keys : ["intelligentAuto"]
                },
                onSuccess : function(result) {
                    log("getIntelligentAuto: On Success");

                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.enabled = result.settings.intelligentAuto;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure : function(result) {
                    log("getIntelligentAuto: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SGIA", "Signage.getIntelligentAuto returns failure.");
                        errorCallback(result);
                    }
                }
            });

        log("Signage.getIntelligentAuto Done");
    };

		/**
     * set StudioMode enabled/disabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     *
     * function setStudioMode () {
     *   var options = {
     *      enabled : true
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.setStudioMode(successCb, failureCb, options);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23getStudioMode.html">Signage.getStudioMode()</a><br>
     */
    Signage.prototype.setStudioMode = function (successCallback, errorCallback, options) {
        log("setStudioMode: " + options.enabled);

        if (options.enabled === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "SSSM", "Signage.setStudioMode returns failure. command was not defined.");
            errorCallback(result);
            log("Signage.setStudioMode invalid ");
            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "commercial",
                settings : {
                    "studioMode" : (options.enabled === true ) ? "on" : "off"
                }
            },
            onSuccess : function(result) {
                log("setStudioMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setStudioMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSSM", "Signage.setStudioMode returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Signage.setStudioMode Done");
    };

		/**
     * Gets StudioMode enabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getStudioMode () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("enabled : " + cbObject.enabled);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.getStudioMode(successCb, failureCb);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23setStudioMode.html">Signage.setStudioMode()</a><br>
     */
    Signage.prototype.getStudioMode = function (successCallback, errorCallback) {

        log("getStudioMode: ");

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "get",
                parameters : {
                    category : "commercial",
                    keys : ["studioMode"]
                },
                onSuccess : function(result) {
                    log("getStudioMode: On Success");

                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.enabled = (result.settings.studioMode === "on") ? true : false;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure : function(result) {
                    log("getStudioMode: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SGSM", "Signage.getStudioMode returns failure.");
                        errorCallback(result);
                    }
                }
            });

        log("Signage.getStudioMode Done");
    };

    	/**
     * set LanDaisyChain enabled/disabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     *
     * function setLanDaisyChain () {
     *   var options = {
     *      enabled : true
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.setLanDaisyChain(successCb, failureCb, options);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23getLanDaisyChain.html">Signage.getLanDaisyChain()</a><br>
     */
	Signage.prototype.setLanDaisyChain = function (successCallback, errorCallback, options) {

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["tv.model.supportCommerLanDaisyChain"]
            },
            onSuccess: function(result) {
            	if (result.returnValue === true) {
	                if (result.configs["tv.model.supportCommerLanDaisyChain"] === false) {
	                    checkErrorCodeNText(result, "SSLD", "Signage.setLanDaisyChain returns failure. unsupported feature. ");
	            		errorCallback(result);
	            		log("Signage.setLanDaisyChain invalid ");
	            		return;
	                }
	                else {
	                	if (options.enabled === null && typeof errorCallback === 'function') {
				            var result = {};
				            checkErrorCodeNText(result, "SSLD", "Signage.setLanDaisyChain returns failure. command was not defined.");
				            errorCallback(result);
				            log("Signage.setLanDaisyChain invalid ");
				            return;
				        }

				        log("setLanDaisyChain: " + options.enabled);

				        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
				            method : "set",
				            parameters : {
				                category : "commercial",
				                settings : {
				                    "lanDaisyChain" : (options.enabled === true ) ? "on" : "off"
				                }
				            },
				            onSuccess : function(result) {
				                log("setLanDaisyChain: On Success");

				                if (result.returnValue === true) {
				                    if(typeof successCallback === 'function') {
				                        successCallback();
				                    }
				                }
				            },
				            onFailure : function(result) {
				                log("setLanDaisyChain: On Failure");
				                delete result.returnValue;
				                if (typeof errorCallback === 'function') {
				                    checkErrorCodeNText(result, "SSIA", "Signage.setLanDaisyChain returns failure.");
				                    errorCallback(result);
				                }
				            }
				        });

				        log("Signage.setLanDaisyChain Done");
	                }
                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });


    };

		/**
     * Gets LanDaisyChain enabled
     * @class Signage
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>enabled</th><th>Boolean</th><th>Intelligent auto is enabled. true: enabled, false: disabled</th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getLanDaisyChain () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("enabled : " + cbObject.enabled);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var signage = new Signage();
     *   signage.getLanDaisyChain(successCb, failureCb);
     * }
     * @since 1.4
     * @see
     * <a href="Signage%23setLanDaisyChain.html">Signage.setLanDaisyChain()</a><br>
     */
    Signage.prototype.getLanDaisyChain = function (successCallback, errorCallback) {

        service.Request("luna://com.webos.service.config/", {
            method: "getConfigs",
            parameters: {
                configNames: ["tv.model.supportCommerLanDaisyChain"]
            },
            onSuccess: function(result) {
            	if (result.returnValue === true) {
	                if (result.configs["tv.model.supportCommerLanDaisyChain"] === false) {
	                    checkErrorCodeNText(result, "SSLD", "Signage.getLanDaisyChain returns failure. unsupported feature. ");
	            		errorCallback(result);
	            		log("Signage.getLanDaisyChain invalid ");
	            		return;
	                }
	                else {
	                	log("getLanDaisyChain: ");

				        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
				            method : "get",
				            parameters : {
				                category : "commercial",
				                keys : ["lanDaisyChain"]
				            },
				            onSuccess : function(result) {
				                log("getLanDaisyChain: On Success");

				                if (result.returnValue === true) {
				                    var cbObj = {};
				                    cbObj.enabled = (result.settings.lanDaisyChain === "on") ? true : false;

				                    if (typeof successCallback === 'function') {
				                        successCallback(cbObj);
				                    }
				                }
				            },
				            onFailure : function(result) {
				                log("getLanDaisyChain: On Failure");
				                delete result.returnValue;
				                if (typeof errorCallback === 'function') {
				                    checkErrorCodeNText(result, "SSLD", "Signage.getLanDaisyChain returns failure.");
				                    errorCallback(result);
				                }
				            }
				        });

				        log("Signage.getLanDaisyChain Done");
	                }
                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });


    };


	/**
	* <p>Gets mirrormode status.</p>
	*
	* @example
	* function getMirrorMode() {
    *
    *    var successCb = function (cbObject){
    *      var mirrorMode= cbObject.mode;
    *
    *      console.log("mirrorMode: " + mirrorMode);
    *    };
    *
    *    var failureCb = function(cbObject){
    *      var errorCode = cbObject.errorCode;
    *      var errorText = cbObject.errorText;
    *      console.log( " Error Code [" + errorCode + "]: " + errorText);
    *    };
    *
    *    var signage = new Signage();
    *    signage.getMirrorMode(successCb, failureCb);
    *
    * }
    *
    * @class Signage
    * @param {Function} successCallback success callback function.
    * @param {Function} errorCallback failure callback function.
    *
    * @returns  <p>After the method is successfully executed, successCallback is called with the following parameters.</p>
    *
    * <div align=left>
    * <table class="hcap_spec" width=400>
    *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
    *   <tbody>
    *       <tr><th>mode</th><th>String</th><th>it shows whether current mirror mode status "on" / "off" </th></tr>
    *   </tbody>
    * </table>
    * </div>
    *
    * <p>If an error occurs, errorCallback is called with errorCode and errorText.</p>
    *
    * @since 1.4.5
    * @see
    * <a href="Signage%23setMirrorMode.html">Signage.setMirrorMode()</a><br>
    */
    Signage.prototype.getMirrorMode = function (successCallback, errorCallback) {
        service.Request("luna://com.webos.service.commercial.signage.storageservice/signage", {
            method: "getMirrorMode",
            parameters: {},
            onSuccess: function (res) {
                delete res.returnValue;
                if (typeof successCallback === 'function') {
                    successCallback(res);
                }
            },
            onFailure: function (res) {
                delete res.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(res);
                }
            }
        });
    };


    /**
    * <p>Sets mirrormode status. reboot required to apply change.</p>
    *
    * @class Signage
    * @param {Function} successCallback success callback function.
    * @param {Function} errorCallback failure callback function.
    * @param {Object} options
    * <div align=left>
    * <table class="hcap_spec" width=400>
    *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
    *   <tbody>
    *       <tr><th>mode</th><th>String</th><th>"on" : turn mirror mode on / "off" : turn mirrormode off </th><th>required</th></tr>
    *   </tbody>
    * </table>
    * </div>
    * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
    * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
    *
    * @example
    * function setMirrorMode() {
    *
    *    var successCb = function (){
    *      console.log("Successfully set MirrorMode");
    *    };
    *
    *    var failureCb = function(cbObject){
    *      var errorCode = cbObject.errorCode;
    *      var errorText = cbObject.errorText;
    *      console.log( " Error Code [" + errorCode + "]: " + errorText);
    *    };
    *
    *    var options = {
    *      mode : "on"
    *    };
    *
    *    var signage = new Signage();
    *    signage.setMirrorMode(successCb, failureCb, options);
    * }
    *
    * @since 1.4.5
    *
    * @see
    * <a href="Signage%23getMirrorMode.html">Signage.getMirrorMode()</a><br>
    */
    Signage.prototype.setMirrorMode = function (successCallback, errorCallback, options) {
        service.Request("luna://com.webos.service.commercial.signage.storageservice/signage", {
            method: "setMirrorMode",
            parameters: options,
            onSuccess: function () {
                if (typeof successCallback === 'function') {
                    successCallback();
                }
            },
            onFailure: function (result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    errorCallback(result);
                }
            }
        });
    };

    Signage.prototype.addEventListener = addSignageEventListener;
    Signage.prototype.removeEventListener = removeSignageEventListener;

    module.exports = Signage;
});

Signage = cordova.require('cordova/plugin/signage'); // jshint ignore:line

