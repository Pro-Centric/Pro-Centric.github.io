/*
 * This is sound cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the sound API itself, and provides a global namespace for operating sound service.
 * @class
 */
cordova.define('cordova/plugin/sound', function (require, exports, module) { // jshint ignore:line

    function log(msg) {
    //    console.log(msg);//will be removed // jshint ignore:line
    }

    var service;
    if (window.PalmSystem) { // jshint ignore:line
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");

                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    /**
     * sound interface
     */
    var Sound = function () {
    };

    function checkErrorCodeNText(result, errorCode, errorText) {

        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    var version = null;
    var platformInfoObj = {};
    function checkPlatformVersion(cb) {

        if (version === null) {

            service.Request('luna://com.webos.service.tv.systemproperty', {
                method: 'getSystemInfo',
                parameters: {
                    keys: ["sdkVersion", "boardType"]
                },
                onSuccess: function(result) {
                    log("getPlatformInfo: onSuccess");
                    log("version : " + result.sdkVersion);

                    var temp = result.sdkVersion.split('.');
                    if (temp.length >= 1 && temp[0] === '1') {
                        platformInfoObj = {
                            webOSVer: 1,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '2') {
                        platformInfoObj = {
                            webOSVer: 2,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else if (temp.length >= 1 && temp[0] === '3') {
                        platformInfoObj = {
                            webOSVer: 3,
                            chipset: result.boardType.split("_")[0]
                        };
                    } else {
                        platformInfoObj = {
                            webOSVer: 0,
                            chipset: ""
                        };
                    }
                    version = platformInfoObj.webOSVer;
                    cb(platformInfoObj);
                },
                onFailure: function(error) {
                    log("getPlatformInfo: onFailure");
                    platformInfoObj = {
                        webOSVer: 0,
                        chipset: ""
                    }
                    cb(platformInfoObj);
                }
            });

        } else {
            cb(platformInfoObj);
        }
    }

    /**
     * @namespace Sound.SoundMode
     */
    Sound.SoundMode = {
	/**
     * standard
     * @since 1.4
     * @constant
     */
    Standard : "standard",
    /**
     * movie
     * @since 1.4
     * @constant
     */
    Cinema : "movie",
    /**
     * news
     * @since 1.4
     * @constant
     */
    ClearVoice : "news",
    /**
     * sports
     * @since 1.4
     * @constant
     */
    Sports : "sports",
    /**
     * music
     * @since 1.4
     * @constant
     */
    Music : "music",
    /**
     * game
     * @since 1.4
     * @constant
     */
    Game : "game"
    };

	/**
     * @namespace Sound.SoundMode
     */
    Sound.SpeakerType = {
    /**
     * tv_speaker
     * @since 1.4
     * @constant
     */
    SignageSpeaker : "tv_speaker",
    /**
     * bt_soundbar
     * @since 1.4
     * @constant
     */
    LGSoundSync : "bt_soundbar"
    };

    /**
     * Gets sound information
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>level</th><th>Number</th><th>volume level (0~100)</th></tr>
     *       <tr class="odd"><th>muted</th><th>Boolean</th><th>true: mute on / false: mute off </th></tr>
     *       <tr><th>externalSpeaker</th><th>Boolean</th><th>true : enabled / false : disabled </th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSoundStatus () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *
     *      console.log("level : " + cbObject.level);
     *      console.log("muted : " + cbObject.muted);
     *      console.log("externalSpeaker : " + cbObject.externalSpeaker);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.getSoundStatus(successCb, failureCb);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23setVolumeLevel.html">Sound.setVolumeLevel()</a>,
     * <a href="Sound%23setExternalSpeaker.html">Sound.setExternalSpeaker()</a><br>
     */
    Sound.prototype.getSoundStatus = function(successCallback, errorCallback) {
        log("getSoundStatus: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
            method: "version",
            onSuccess: function(result) {
                if (result.returnValue === true) {

                    var scapVersion = result.version;
                    var key = "";
                    if(scapVersion[0] === "1" && scapVersion[2] === "5") {
                        key = "com.webos.surfacemanager.supportCommerSoundSetting";
                    } else {
                        key = "tv.model.supportCommerSoundSetting";
                    }

                    service.Request("luna://com.webos.service.config/", {
                        method: "getConfigs",
                        parameters: {
                            configNames: [key]
                        },
                        onSuccess: function(result) {
                            log("getConfigs: On Success");

                            if (result.returnValue === true) {
                                var supportCommerSoundSetting = result.configs[key];
                                if (supportCommerSoundSetting === true) {
                                    service.Request("luna://com.webos.audio/", {
                                        method: "getVolume",
                                        onSuccess: function(result) {
                                            log("getSoundStatus: On Success");

                                            if (result.returnValue === true) {
                                                var cbObj = {};
                                                cbObj.level = result.volume;
                                                cbObj.muted = result.muted;

                                                service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                                                    method: "get",
                                                    parameters: {
                                                        category: "commercial",
                                                        keys: ["enableSpeaker"]
                                                    },
                                                    onSuccess: function(result) {
                                                        log("getSoundStatus: On Success 2");

                                                        if (result.returnValue === true) {
                                                            cbObj.externalSpeaker = (result.settings.enableSpeaker === "on" ? true : false);

                                                            if (typeof successCallback === 'function') {
                                                                successCallback(cbObj);
                                                            }
                                                        }
                                                    },
                                                    onFailure: function(result) {
                                                        log("getSoundStatus: On Failure 2");
                                                        delete result.returnValue;
                                                        if (typeof errorCallback === 'function') {
                                                            checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                                                            errorCallback(result);
                                                        }
                                                    }
                                                });
                                            }
                                        },
                                        onFailure: function(result) {
                                            log("getSoundStatus: On Failure");
                                            delete result.returnValue;
                                            if (typeof errorCallback === 'function') {
                                                checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                                                errorCallback(result);
                                            }
                                        }
                                    });
                                } else {
                                    delete result.returnValue;
                                    if (typeof errorCallback === 'function') {
                                        checkErrorCodeNText(result, "SGSS", "unsupported feature");
                                        errorCallback(result);
                                    }

                                    return;
                                }

                                log("Sound.getSoundStatus Done");
                            }
                        },
                        onFailure: function(result) {
                            log("getConfigs: On Failure");
                            delete result.returnValue;
                            if (typeof errorCallback === 'function') {
                                checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                                errorCallback(result);
                            }
                        }
                    });
                }
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SGSS", "Sound.getSoundStatus returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.getSoundStatus Done");

    };

    /**
     * Sets volume level
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>level</th><th>Number</th><th>volume level (0~100)</th><th>required</th></tr>
     *       <tr><th>volOsdEnabled</th><th>Boolean</th><th>true: vol osd is enabled(default), false: vol osd is disabled</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setVolumeLevel () {
     *   var options = {
     *      level : 15,
     *      volOsdEnabled : false
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setVolumeLevel(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setVolumeLevel = function (successCallback, errorCallback, options) {

        log("setVolumeLevel: " + JSON.stringify(options));

        if (typeof options.level !== 'number' || isNaN(options.level) ||
            options.level < 0 || options.level > 100) {

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSVL", "Sound.setVolumeLevel returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }

            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/sound/", {
            method: "setVolumeLevel",
            parameters: options,
            onSuccess: function(result){
                log("setVolumeLevel success");
                successCallback();
            },
            onFailure: function(result){
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSVL", "Sound.setVolumeLevel returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.setVolumeLevel Done");
    };

    /**
     * Enable or disable external speaker.
     * If this method is successfully executed, change the external speaker status.
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <th>externalSpeaker</th><th>Boolean</th><th>true : enabled / false : disabled </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setExternalSpeaker () {
     *   var options = {
     *      externalSpeaker : true
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setExternalSpeaker(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setExternalSpeaker = function (successCallback, errorCallback, options) {

        log("setExternalSpeaker: " + JSON.stringify(options));

        if (typeof options.externalSpeaker !== 'boolean') {

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSVL", "Sound.setExternalSpeaker returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }

            return;
        }

        var enable = null;
        switch (options.externalSpeaker) {
            case true :
                enable = "on";
                break;
            case false :
                enable = "off";
                break;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method : "set",
                parameters : {
                    category : "commercial",
                    settings : {"enableSpeaker":enable}
                },
                onSuccess : function() {
                    log("setExternalSpeaker: On Success");
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                },
                onFailure : function(result) {
                    log("setExternalSpeaker: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SSES", "Sound.setExternalSpeaker returns failure.");
                        errorCallback(result);
                    }
                }
            });

        log("Sound.setExternalSpeaker Done");

    };

    /**
     * mute on/off
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>muted</th><th>Boolean</th><th>true: mute on / false: mute off </th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function setMuted () {
     *   var options = {
     *      muted : true
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setMuted(successCb, failureCb, options);
     * }
     * @since 1.0
     * @see
     * <a href="Sound%23getSoundStatus.html">Sound.getSoundStatus()</a><br>
     */
    Sound.prototype.setMuted = function (successCallback, errorCallback, options) {

        log("setMuted: " + JSON.stringify(options));

        if (typeof options.muted !== 'boolean') {

            if (typeof errorCallback === 'function') {
                var result = {};
                checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure. out of range or invalid parameter type.");
                errorCallback(result);
            }

            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/", {
            method: "version",
            onSuccess: function(result) {
                var scapVersion = result.version;
                var key = "";
                if(scapVersion[0] === "1" && scapVersion[2] === "5") {
                    key = "com.webos.surfacemanager.supportCommerSoundSetting";
                } else {
                    key = "tv.model.supportCommerSoundSetting";
                }

                service.Request("luna://com.webos.service.config/", {
                    method: "getConfigs",
                    parameters: {
                        configNames: [key]
                    },
                    onSuccess: function(result) {
                        log("getConfigs: On Success");

                        if (result.returnValue === true) {
                            var supportCommerSoundSetting = result.configs[key];
                            if (supportCommerSoundSetting === true) {
                                service.Request("luna://com.webos.audio/", {
                                    method: "setMuted",
                                    parameters: {
                                        muted: options.muted
                                    },
                                    onSuccess: function(result) {
                                        log("setMuted: On Success");

                                        if (result.returnValue === true) {
                                            if (typeof successCallback === 'function') {
                                                successCallback();
                                            }
                                        }
                                    },
                                    onFailure: function(result) {
                                        log("setMuted: On Failure");
                                        delete result.returnValue;
                                        if (typeof errorCallback === 'function') {
                                            checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure.");
                                            errorCallback(result);
                                        }
                                    }
                                });
                            } else {
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SSM", "unsupported feature");
                                    errorCallback(result);
                                }

                                return;
                            }
                        }
                    },
                    onFailure: function(result) {
                        log("getConfigs: On Failure");
                        delete result.returnValue;
                        if (typeof errorCallback === 'function') {
                            checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure");
                            errorCallback(result);
                        }
                    }
                });
            },
            onFailure: function(result) {
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSM", "Sound.setMuted returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.setMuted Done");

    };

	/**
     * Sets Sound mode. Each <a href="Sound.SoundMode.html#constructor">SoundMode</a> has a set of predefined sound properties. And each sound modes can be changed with setSoundMode().
     *
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>mode</th><th>String</th><th><a href="Sound.SoundMode.html#constructor">SoundMode</a></th><th>required</th></tr>
     * 		 <tr class="odd"><th>balance</th><th>Number</th><th>-50 ~ +50</th><th>optional</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function setSoundMode () {
     *   var options = {
	 *		 mode : Sound.SoundMode.Standard,
	 *		 balance : 20
	 *	 };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setSoundMode(successCb, failureCb, options);
     * }
     * @since 1.4
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @see
     * <a href="Sound%23getSoundMode.html">Sound.getSoundMode()</a><br>
     */

    Sound.prototype.setSoundMode = function (successCallback, errorCallback, options) {
        var mode = null;

        switch (options.mode) {
            case Sound.SoundMode.Standard :
                mode = "standard";
                break;
            case Sound.SoundMode.Cinema :
                mode = "movie";
                break;
            case Sound.SoundMode.ClearVoice :
                mode = "news";
                break;
            case Sound.SoundMode.Sports :
                mode = "sports";
                break;
            case Sound.SoundMode.Music :
                mode = "music";
                break;
            case Sound.SoundMode.Game :
                mode = "game";
                break;
        }

        if (((options.balance < -50) || (options.balance > 50)) && isNumber(options.balance)) {
            var result = {};
            checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure. Out of range.");
            errorCallback(result);
            log("Sound.setSoundMode invalid range");
        }

        log("setSoundMode: " + mode);

        if (mode === null && typeof errorCallback === 'function') {
            var result = {};
            checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure. command was not defined.");
            errorCallback(result);
            log("Sound.setSoundMode invalid ");
            return;
        }

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method : "set",
            parameters : {
                category : "sound",
                settings : {
                    "soundMode" : mode,
                    "audioBalance" : options.balance
                }
            },
            onSuccess : function(result) {
                log("setSoundMode: On Success");

                if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                        successCallback();
                    }
                }
            },
            onFailure : function(result) {
                log("setSoundMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SSSM", "Sound.setSoundMode returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.setSoundMode Done");
    };

	/**
     * Gets sound mode. Each <a href="Sound.SoundMode.html#constructor">SoundMode</a> has a set of predefined sound properties.
     *
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>mode</th><th>String</th><th><a href="Sound.SoundMode.html#constructor">Sound.SoundMode</a></th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSoundMode () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("mode : " + cbObject.mode);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.getSoundMode(successCb, failureCb);
     * }
     * @since 1.4
     * @see
     * <a href="Sound%23setSoundMode.html">Sound.setSoundMode()</a><br>
     */

    Sound.prototype.getSoundMode = function (successCallback, errorCallback) {

        log("getSoundMode: ");

        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
            method: "get",
            parameters: {
                category: "sound",
                keys: ["soundMode", "audioBalance"]
            },
            onSuccess: function(result) {
                log("getSoundMode: On Success");

                if (result.returnValue === true) {
                    var cbObj = {};
                    cbObj.mode = result.settings.soundMode;
                    cbObj.balance = result.settings.audioBalance;

                    if (typeof successCallback === 'function') {
                        successCallback(cbObj);
                    }
                }
            },
            onFailure: function(result) {
                log("getSoundMode: On Failure");
                delete result.returnValue;
                if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "SGSM", "Sound.getSoundMode returns failure.");
                    errorCallback(result);
                }
            }
        });

        log("Sound.getSoundMode Done");
    };

    /**
     * Sets Sound speakerType. Each <a href="Sound.SoundOut.html#constructor">SoundOut</a> has a set of predefined sound properties. And each sound speakerTypes can be changed with setSoundOut().
     *
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>speakerType</th><th>String</th><th><a href="Sound.SoundOut.html#constructor">SoundOut</a></th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function setSoundOut () {
     *   var options = {
	 *		 speakerType : Sound.SpeakerType.SignageSpeaker
	 *	 };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.setSoundOut(successCb, failureCb, options);
     * }
     * @since 1.4
     * @return <p>If the method is successfully executed, success callback function is called without a parameter.</br>
     * If an error occurs, failure callback function is called with a failure callback object as a parameter.</p>
     * @see
     * <a href="Sound%23getSoundOut.html">Sound.getSoundOut()</a><br>
     */

    Sound.prototype.setSoundOut = function (successCallback, errorCallback, options) {
        checkPlatformVersion(function(platformInfo){
            if (platformInfo.webOSVer !== 3) {
                // only webOS Signage 3.0 support setSoundOut API
                var result = {};
                checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. Only webOS 3.0 support setSoundOut API.");
                errorCallback(result);
                log("not support setSoundOut");
                return;
            }

            service.Request("luna://com.webos.service.config/", {
                method: "getConfigs",
                parameters: {
                    configNames: ["system.supportBluetoothFeatures"]
                },
                onSuccess: function(result) {
                    log("getConfigs: On Success");

                    if (result.returnValue === true) {

                        var bluetoothFeatures = result.configs["system.supportBluetoothFeatures"];
                        if (bluetoothFeatures.indexOf('btsound') === -1) //not supported btsound
                        {
                            if (options.speakerType === Sound.SpeakerType.LGSoundSync) {
                                var result = {};
                                checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. bluetooth soundsync is not supported.");
                                errorCallback(result);
                                return;
                            }
                        }

                        var speakerType = null;

                        switch (options.speakerType) {
                            case Sound.SpeakerType.SignageSpeaker:
                                speakerType = "tv_speaker";
                                break;
                            case Sound.SpeakerType.LGSoundSync:
                                speakerType = "bt_soundbar";
                                break;
                        }

                        log("setSoundOut: " + speakerType);

                        if (speakerType === null && typeof errorCallback === 'function') {
                            var result = {};
                            checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure. command was not defined.");
                            errorCallback(result);
                            log("Sound.setSoundOut invalid ");
                            return;
                        }

                        service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                            method: "set",
                            parameters: {
                                category: "sound",
                                settings: {
                                    "soundOutput": speakerType
                                }
                            },
                            onSuccess: function(result) {
                                log("setSoundOut: On Success");

                                if (result.returnValue === true) {
                                    if (typeof successCallback === 'function') {
                                        successCallback();
                                    }
                                }
                            },
                            onFailure: function(result) {
                                log("setSoundOut: On Failure");
                                delete result.returnValue;
                                if (typeof errorCallback === 'function') {
                                    checkErrorCodeNText(result, "SSSO", "Sound.setSoundOut returns failure.");
                                    errorCallback(result);
                                }
                            }
                        });

                        log("Sound.setSoundOut Done");

                    }
                },
                onFailure: function(result) {
                    log("getConfigs: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SSSO", "unsupported feature");
                        errorCallback(result);
                    }
                }
            });
        });
    };

	/**
     * Gets sound speakerType. Each <a href="Sound.SoundOut.html#constructor">SoundOut</a> has a set of predefined sound properties.
     *
     * @class Sound
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>speakerType</th><th>String</th><th><a href="Sound.SoundOut.html#constructor">Sound.SoundOut</a></th></tr>
     *   </tbody>
     * </table>
     * </div>
     *
     * @example
     * // Javascript code
     * function getSoundOut () {
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *      console.log("speakerType : " + cbObject.speakerType);
     *
     *      // Do something
     *         ...
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var sound = new Sound();
     *   sound.getSoundOut(successCb, failureCb);
     * }
     * @since 1.4
     * @see
     * <a href="Sound%23setSoundOut.html">Sound.setSoundOut()</a><br>
     */

    Sound.prototype.getSoundOut = function(successCallback, errorCallback) {
        checkPlatformVersion(function(platformInfo) {
            if (platformInfo.webOSVer !== 3) {
                // only webOS Signage 3.0 support getSoundOut API
                var result = {};
                checkErrorCodeNText(result, "SGSO", "Sound.getSoundOut returns failure. Only webOS 3.0 support getSoundOut API.");
                errorCallback(result);
                log("not support getSoundOut");
                return;
            }

            log("getSoundOut: ");

            service.Request("luna://com.webos.service.commercial.signage.storageservice/settings/", {
                method: "get",
                parameters: {
                    category: "sound",
                    keys: ["soundOutput"]
                },
                onSuccess: function(result) {
                    log("getSoundOut: On Success");

                    if (result.returnValue === true) {
                        var cbObj = {};
                        cbObj.speakerType = result.settings.soundOutput;

                        if (typeof successCallback === 'function') {
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure: function(result) {
                    log("getSoundOut: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SGSO", "Sound.getSoundOut returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Sound.getSoundOut Done");
        });
    };

    module.exports = Sound;
});

Sound = cordova.require('cordova/plugin/sound'); // jshint ignore:line

