/*
 * This is system cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */


/**
 * This represents the configuration API itself, and provides a global namespace for operating configuration service.
 * @class
 */

 cordova.define('cordova/plugin/led', function (require, exports, module) { // jshint ignore:line

     function log(msg) {
     //    console.log(msg);//will be removed // jshint ignore:line
     }

     var service;
     if (window.PalmSystem) { // jshint ignore:line
         log("Window.PalmSystem Available");
         service = require('cordova/plugin/webos/service');
     } else {
         service = {
             Request : function (uri, params) {
                 log(uri + " invoked. But I am a dummy because PalmSystem is not available");

                if (typeof params.onFailure === 'function') {
                     params.onFailure({
                         returnValue:false,
                         errorText:"PalmSystem Not Available. Cordova is not installed?"
                     });
                 }
         }};
     }

     /**
      * Led interface
      */
     var Led = function () {
     };

     function checkErrorCodeNText(result, errorCode, errorText) {

         if (result.errorCode === undefined || result.errorCode === null ) {
             result.errorCode = errorCode;
         }
         if (result.errorText === undefined || result.errorText === null) {
             result.errorText = errorText;
         }
     }

     /**
     * Gets LED layout information
     *
     * @class Led
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>senderList</th><th>Array</th><th>sender list </th></tr>
     *       <tr><th>senderList[].senderId</th><th>number</th><th> senderId </th></tr>
     *       <tr><th>senderList[].x</th><th>number</th><th> position x </th></tr>
     *       <tr><th>senderList[].y</th><th>number</th><th> position y </th></tr>
     *       <tr><th>senderList[].width</th><th>number</th><th> width </th></tr>
     *       <tr><th>senderList[].height</th><th>number</th><th> height </th></tr>
     *
     *       <tr><th>senderList[].unitList</th><th>Array</th><th> unit list </th></tr>
     *       <tr><th>senderList[].unitList[].unitId</th><th>number</th><th> unitId </th></tr>
     *       <tr><th>senderList[].unitList[].x</th><th>number</th><th> position x </th></tr>
     *       <tr><th>senderList[].unitList[].y</th><th>number</th><th> position y </th></tr>
     *       <tr><th>senderList[].unitList[].width</th><th>number</th><th> width </th></tr>
     *       <tr><th>senderList[].unitList[].height</th><th>number</th><th> height </th></tr>
     *       <tr><th>senderList[].unitList[].portSelection</th><th>number</th><th> portSelection </th></tr>
     *       <tr><th>senderList[].unitList[].rows</th><th>number</th><th> film count attached to unit </th></tr>
     *       <tr><th>senderList[].unitList[].trimming</th><th>Object</th><th> film pixels cut  </th></tr>
     *       <tr><th>senderList[].unitList[].trimming{}.left</th><th>Object</th><th> film pixels cut from left </th></tr>
     *       <tr><th>senderList[].unitList[].trimming{}.right</th><th>Object</th><th> film pixels cut from right </th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function getLayoutInfo () {
     *   function successCb(cbObject) {
     *       console.log("cbObject : " + JSON.stringify(cbObject) );
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var led = new Led();
     *   led.getLayoutInfo(successCb, failureCb);
     * }
     * @since 1.4.6
     * @see
     * <a href="Led%23getUnitStatus.html">Led.getUnitStatus()</a><br>
     */
    Led.prototype.getLayoutInfo = function (successCallback, errorCallback) {

     service.Request("luna://com.webos.service.commercial.signage.storageservice/led/", {
          method : "getLayoutInfo",
          parameters : {},
          onSuccess : function(result) {
               log("getLayoutInfo: On Success");

               if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                         delete result.returnValue;
                         successCallback(result);
                    }
               }
          },
          onFailure : function(result) {
               log("getLayoutInfo: On Failure");
               delete result.returnValue;
               if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "INTERNAL_ERROR", "Led.getLayoutInfo returns failure.");
                    errorCallback(result);
               }
          }
          });

          log("Led.getLayoutInfo Done");
     };


     /**
     * Gets LED unit status.<br>
     * Get senderId, unitId from <a href="Led%23getLayoutInfo.html">Led.getLayoutInfo()</a><br>
     *
     * @class Led
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>senderId</th><th>number</th><th>senderId</th><th>required</th></tr>
     *       <tr><th>unitId</th><th>number</th><th>unitId</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>power</th><th>String</th><th>power status</th></tr>
     *       <tr><th>signal</th><th>String</th><th>signal status</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function getUnitStatus () {
     *    var options = {
     *         senderId : 1,
     *         unitId   : 1
     *    }
     *
     *   function successCb(cbObject) {
     *       console.log("cbObject : " + JSON.stringify(cbObject) );
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var led = new Led();
     *   led.getUnitStatus(successCb, failureCb, options);
     * }
     * @since 1.4.6
     * @see
     * <a href="Led%23getLayoutInfo.html">Led.getLayoutInfo()</a><br>
     */
    Led.prototype.getUnitStatus = function (successCallback, errorCallback, options) {

     service.Request("luna://com.webos.service.commercial.signage.storageservice/led/", {
          method : "getUnitStatus",
          parameters : options,
          onSuccess : function(result) {
               log("getUnitStatus: On Success");

               if (result.returnValue === true) {
                    if(typeof successCallback === 'function') {
                         delete result.returnValue;
                         successCallback(result);
                    }
               }
          },
          onFailure : function(result) {
               log("getUnitStatus: On Failure");
               delete result.returnValue;
               if (typeof errorCallback === 'function') {
                    checkErrorCodeNText(result, "INTERNAL_ERROR", "Led.getUnitStatus returns failure.");
                    errorCallback(result);
               }
          }
          });

          log("Led.getUnitStatus Done");
     };

     /**
     * Gets LED log.<br>
     *
     * @class Led
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
      * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>data</th><th>String</th><th>Reported LED log data in string.<br>
     *         Category, SensorName, Event, Status, StartTime are reported in each row.</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function readLog () {
     *   function successCb(cbObject) {
     *       console.log("cbObject : " + JSON.stringify(cbObject) );
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var led = new Led();
     *   led.readLog(successCb, failureCb);
     * }
     * @since 1.4.6
     * @see
     */
      Led.prototype.readLog = function (successCallback, errorCallback) {

          service.Request("luna://com.webos.service.commercial.signage.storageservice/led/", {
               method : "readLog",
               parameters : {},
               onSuccess : function(result) {
                    log("readLog: On Success");
                    if (result.returnValue === true) {
                         if(typeof successCallback === 'function') {
                              delete result.returnValue;
                              successCallback(result);
                         }
                    }
               },
               onFailure : function(result) {
                    log("readLog: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                         checkErrorCodeNText(result, "INTERNAL_ERROR", "Led.readLog returns failure.");
                         errorCallback(result);
                    }
               }
               });

               log("Led.readLog Done");
          };

     module.exports = Led;
} );

Led = cordova.require('cordova/plugin/led'); // jshint ignore:line


