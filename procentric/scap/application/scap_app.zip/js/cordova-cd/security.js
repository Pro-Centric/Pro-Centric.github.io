/*
 * This is security cordova_plugin (TV specific API).
 * Apache License (2004). See http://www.apache.org/licenses/LICENSE-2.0
 *
 * Copyright (c) 2014, LG Electronics, Inc.
 */

/**
 * This represents the security API itself, and provides a global namespace for operating security service.
 * @class
 */
cordova.define('cordova/plugin/security', function (require, exports, module) {

    function log(msg) {
    //    console.log(msg);
    }

    var service;
    if (window.PalmSystem) {
        log("Window.PalmSystem Available");
        service = require('cordova/plugin/webos/service');
    } else {
        service = {
            Request : function(uri, params) {
                log(uri + " invoked. But I am a dummy because PalmSystem is not available");

                if (typeof params.onFailure === 'function') {
                    params.onFailure({
                        returnValue:false,
                        errorText:"PalmSystem Not Available. Cordova is not installed?"
                    });
               }
        }};
    }

    function checkErrorCodeNText(result, errorCode, errorText) {

        if (result.errorCode === undefined || result.errorCode === null ) {
            result.errorCode = errorCode;
        }
        if (result.errorText ===undefined || result.errorText === null) {
            result.errorText = errorText;
        }
    }

    /**
     * security interface
     */
    var Security = function () {
    };


	/**
     * Registers a server certificate to validate the keys from the SCAP server as part of a PKI (Public Key Infrastructure).
     * Handling (Register/Unregister) server certificates must be done very carefully under the control of installer because it is done in insecure environment.
     * If a server certificate is registered, monitor will validate the public key from the SCAP server when monitor requests resources to the SCAP server in SCAP browser
     * The server certificate to register can be a self-signed certificate or a CA (Certificate Authority) certificate.
     * Only 1 server certificate is permitted in monitor. Therefore to register a server certificate when another server certificate was registered, revoke(unregister) the registered server certificate first, and register the new server certificate. Or the registration for the new server certificate will be failed.
     * After registration, reboot must be needed.
     * @class Security
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>userName</th><th>String</th><th>username for this server certificate as 4 to 10-character string chosen from the set [a-zA-Z0-9].</th><th>required</th></tr>
     *       <tr><th>password</th><th>String</th><th>password as 4 to 10-character string chosen from the set [a-zA-Z0-9] to get whether this certificate is registered or not, or revoke this certificate in the future.</th><th>required</th></tr>
     *       <tr><th>certificate</th><th>String</th><th>certificate string of the full contents in the server certificate file (public root CA of the server certificate file) in the form of PEM (rootCA.crt in above example).</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function registerServerCertificate () {
     *   var options = {
     *      userName : "testserver",
     *      password : "passCode1",
     *      certificate : "\
     *-----BEGIN CERTIFICATE-----\n\
     *MIIDhDCCAmwCCQDY8/8psTWE+DANBgkqhkiG9w0BAQsFADCBgzELMAkGA1UEBhMC\n\
     *S1IxDjAMBgNVBAgMBVNlb3VsMQ4wDAYDVQQHDAVTZW91bDEMMAoGA1UECgwDTEdF\n\
     *MQwwCgYDVQQLDANXTVQxFjAUBgNVBAMMDTEwLjE3Ny4yMjUuNTgxIDAeBgkqhkiG\n\
     *9w0BCQEWEWRvb21zZGF5QGtsZHAub3JnMB4XDTE2MDkyMzEwMzY0MloXDTI2MDky\n\
     *MTEwMzY0MlowgYMxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTZW91bDEOMAwGA1UE\n\
     *BwwFU2VvdWwxDDAKBgNVBAoMA0xHRTEMMAoGA1UECwwDV01UMRYwFAYDVQQDDA0x\n\
     *MC4xNzcuMjI1LjU4MSAwHgYJKoZIhvcNAQkBFhFkb29tc2RheUBrbGRwLm9yZzCC\n\
     *ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANGU2B1m93M1Wtm1Bvz7BF7S\n\
     *ATx7IWB5bE9fteMJmhvb5yYIcwKbBtPBdIyywPe9ROSHiYHubW3GCbw/h/CjC7F6\n\
     *gvKGK+Hg6lF2fXVDbR4+qDPoiVY+dv/ZWbaQ2KDjMHSqfHqlZWIqm4Znp4mx3dL1\n\
     *DAt2I/S5jcKkO9Xf4g5RCW5dEMTpv0aNgm1nd6YMOGmO0F0r/HwlLNr4cdJwRBWv\n\
     *Ce99EZ3H5SY+Iat96sXDQPxfmBtN1H71Hi1+kZ0ugDhLVTEQxq68cXH0QSnWttXx\n\
     *p4P1DBWYJswQrjiWP9SXLCTPBawNRnSkSGpqoconhy8xDnp1jvEEd/zpWAh036MC\n\
     *AwEAATANBgkqhkiG9w0BAQsFAAOCAQEAKzlLlueFKWfo9IGUdQ/RLjBXD+gBtwF9\n\
     *T8qkIA0h8eawK3l4pBjXgyvIybhhnF3q+aBDD6nh0anhnzmlrzyWqWefsVQqDKEG\n\
     *iqb01qo8qOAn84pAliOnsNQEx+D1Rb2+ceRUhEYLxZBDbL9iL8MuNPAW7coFw3nm\n\
     *eTGV1Nx3OUfK9/EcGbEzNkFP8ZMkckbiDrF5rGHClqL+9FeQ03XMIPGqil2Te6Xq\n\
     *vKG3nsUYZymir2Dgl7Z6Vkeo+F8Y6CPD+iIxkgfX+QKRYS/dYoN00o7fsHNJN7WM\n\
     *CXqAtsTiHRfF17xHVjXH3HLqR5sIpQqay2RZE2PDQpc7Gaq+L9U81A==\n\
     *-----END CERTIFICATE-----\n"
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var security = new Security();
     *   security.registerServerCertificate(successCb, failureCb, options);
     * }
     * @since 1.4.1
     */
    Security.prototype.registerServerCertificate = function (successCallback, errorCallback, options) {
            log("registerServerCertificate: " + JSON.stringify(options));

            if (options.userName === undefined || typeof options.userName !== 'string' || options.userName.length < 4 || options.userName.length > 10 ||
                options.password === undefined || typeof options.password !== 'string' || options.password.length < 4 || options.password.length > 10 ||
                options.certificate === undefined || typeof options.certificate !== 'string') {

                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "SRSC", "Security.registerServerCertificate returns failure. invalid parameters or out of range.");
                    errorCallback(result);
                }

                return;
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/security/", {
                method: "registerServerCertificate",
                parameters: {
                    userName : options.userName,
                    password : options.password,
                    certificate : options.certificate
                },
                onSuccess: function(result) {
                    log("registerServerCertificate: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure: function(result) {
                    log("registerServerCertificate: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SRSC", "Security.registerServerCertificate returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Security.registerServerCertificate Done");
    };

    /**
     * Unregisters a server certificate and deactivate the TLS authentication and the host verification.
     * After unregistration, reboot must be needed.
     * @class Security
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>userName</th><th>String</th><th>username for the server certificate to unregister.</th><th>required</th></tr>
     *       <tr><th>password</th><th>String</th><th>password to be used for the registration of the server certificate before</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return <p>If the method is successfully executed, call the success callback function without a parameter.</br>
     * If an error occurs, failure callback function is called with failure callback object as a parameter.</p>
     * @example
     * // Javascript code
     * function unregisterServerCertificate () {
     *   var options = {
     *      userName : "testserver",
     *      password : "passCode1"
     *   };
     *
     *   function successCb() {
     *      // Do something
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var security = new Security();
     *   security.unregisterServerCertificate(successCb, failureCb, options);
     * }
     * @since 1.4.1
     */
    Security.prototype.unregisterServerCertificate = function (successCallback, errorCallback, options) {
            log("unregisterServerCertificate: " + JSON.stringify(options));

            if (options.userName === undefined || typeof options.userName !== 'string' || options.userName.length < 4 || options.userName.length > 10 ||
                options.password === undefined || typeof options.password !== 'string' || options.password.length < 4 || options.password.length > 10) {

                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "SUSC", "Security.unregisterServerCertificate returns failure. invalid parameters or out of range.");
                    errorCallback(result);
                }

                return;
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/security/", {
                method: "unregisterServerCertificate",
                parameters: {
                    userName : options.userName,
                    password : options.password
                },
                onSuccess: function(result) {
                    log("unregisterServerCertificate: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            successCallback();
                        }
                    }
                },
                onFailure: function(result) {
                    log("unregisterServerCertificate: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SUSC", "Security.unregisterServerCertificate returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Security.unregisterServerCertificate Done");
    };


    /**
     * Returns whether a server certificate was registered or not.
     * @class Security
     * @param {Function} successCallback success callback function.
     * @param {Function} errorCallback failure callback function.
     * @param {Object} options
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th><th>Required</th></tr></thead>
     *   <tbody>
     *       <tr><th>userName</th><th>String</th><th>username for the server certificate.</th><th>required</th></tr>
     *       <tr><th>password</th><th>String</th><th>password to be used for the registration of the server certificate before</th><th>required</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @return {Object}
     * <div align=left>
     * <table class="hcap_spec" width=400>
     *   <thead><tr><th>Property</th><th>Type</th><th>Description</th></tr></thead>
     *   <tbody>
     *       <tr><th>userName</th><th>String</th><th>username for the server certificate</th></tr>
     *       <tr><th>exist</th><th>Boolean</th><th>whether a server certificate was registered or not</th></tr>
     *   </tbody>
     * </table>
     * </div>
     * @example
     * // Javascript code
     * function existServerCertificate () {
     *   var options = {
     *      userName : "testserver",
     *      password : "passCode1"
     *   };
     *
     *   function successCb(cbObject) {
     *      console.log("cbObject : " + JSON.stringify(cbObject));
     *   }
     *
     *   function failureCb(cbObject) {
     *      var errorCode = cbObject.errorCode;
     *      var errorText = cbObject.errorText;
     *      console.log ("Error Code [" + errorCode + "]: " + errorText);
     *   }
     *
     *   var security = new Security();
     *   security.existServerCertificate(successCb, failureCb, options);
     * }
     * @since 1.4.1
     */
    Security.prototype.existServerCertificate = function (successCallback, errorCallback, options) {
            log("existServerCertificate: " + JSON.stringify(options));

            if (options.userName === undefined || typeof options.userName !== 'string' || options.userName.length < 4 || options.userName.length > 10 ||
                options.password === undefined || typeof options.password !== 'string' || options.password.length < 4 || options.password.length > 10) {

                if (typeof errorCallback === 'function') {
                    var result = {};
                    checkErrorCodeNText(result, "SESC", "Security.existServerCertificate returns failure. invalid parameters or out of range.");
                    errorCallback(result);
                }

                return;
            }

            service.Request("luna://com.webos.service.commercial.signage.storageservice/security/", {
                method: "existServerCertificate",
                parameters: {
                    userName : options.userName,
                    password : options.password
                },
                onSuccess: function(result) {
                    log("existServerCertificate: On Success");

                    if (result.returnValue === true) {
                        if (typeof successCallback === 'function') {
                            var cbObj      = {};
                            cbObj.userName = result.userName;
                            cbObj.exist    = result.exist;
                            successCallback(cbObj);
                        }
                    }
                },
                onFailure: function(result) {
                    log("existServerCertificate: On Failure");
                    delete result.returnValue;
                    if (typeof errorCallback === 'function') {
                        checkErrorCodeNText(result, "SESC", "Security.existServerCertificate returns failure.");
                        errorCallback(result);
                    }
                }
            });

            log("Security.existServerCertificate Done");
    };

    module.exports = Security;
});

Security = cordova.require('cordova/plugin/security');

